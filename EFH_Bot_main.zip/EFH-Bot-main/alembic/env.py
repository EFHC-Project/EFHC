# -*- coding: utf-8 -*-
# alembic/env.py
# =============================================================================
# Назначение кода:
# Alembic-окружение для EFHC Bot с поддержкой Neon (PostgreSQL, SSL).
# Гарантирует подключение к БД через sync-URL с sslmode=require, выставляет
# search_path на схему канона (DB_SCHEMA_CORE) и безопасно создаёт её при первом
# запуске. Работает как в offline-, так и в online-режимах Alembic.
#
# Канон / инварианты:
# • БД — PostgreSQL (Neon). Все миграции выполняются в схеме DB_SCHEMA_CORE.
# • Автогенерацию миграций (autogenerate) не используем по умолчанию — мы
#   пишем детерминированные миграции вручную.
# • Версионная таблица Alembic находится в той же схеме (version_table_schema).
#
# ИИ-защиты:
# • Если задан только async DATABASE_URL — автоматически конвертируется в sync.
# • Если в URL нет sslmode — автоматически добавляется sslmode=require.
# • Перед запуском миграций создаёт схему (CREATE SCHEMA IF NOT EXISTS ...).
# • Логирует ключевые параметры подключения и целевую схему.
#
# Запреты:
# • Нет «тихих» попыток чинить несовпадения типов колонок — это делает миграция.
# • Нет автопоиска моделей для autogenerate — только явные миграции.
# =============================================================================

from __future__ import annotations

import os
import sys
import logging
from logging.config import fileConfig
from urllib.parse import urlparse, urlunparse, parse_qsl, urlencode

from alembic import context
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import NullPool

# ---------------------------------------------------------------------------
# Конфигурация логирования Alembic (если есть alembic.ini — подхватит формат)
# ---------------------------------------------------------------------------
config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)
logger = logging.getLogger("alembic.env")

# ---------------------------------------------------------------------------
# Импорт настроек приложения (DB_SCHEMA_CORE и пр.) с защитой от ошибок пути
# ---------------------------------------------------------------------------
def _import_settings():
    """
    Пытаемся импортировать get_settings() из приложения.
    Если проект запущен не из корня — добавим корень в sys.path.
    """
    try:
        from backend.app.core.config_core import get_settings  # type: ignore
        return get_settings()
    except Exception as e:
        # Попытка скорректировать sys.path на 2 уровня вверх (…/backend/…)
        proj_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        if proj_root not in sys.path:
            sys.path.append(proj_root)
        try:
            from backend.app.core.config_core import get_settings  # type: ignore
            return get_settings()
        except Exception as e2:
            logger.warning("Не удалось импортировать get_settings(): %s", e2)
            # Минимальный фолбэк на переменные окружения
            class _Fallback:
                DB_SCHEMA_CORE = os.getenv("DB_SCHEMA_CORE", "efhc_core")
                DATABASE_URL = os.getenv("DATABASE_URL")
                SYNC_DATABASE_URL = os.getenv("SYNC_DATABASE_URL")
            return _Fallback()

settings = _import_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core") or "efhc_core"

# ---------------------------------------------------------------------------
# Утилиты URL: привести к sync-формату и потребовать sslmode=require
# ---------------------------------------------------------------------------
def _to_sync_url(url: str | None) -> str | None:
    """
    Преобразует async URL вида postgresql+asyncpg://… в postgresql://…
    Если url уже sync — возвращается как есть.
    """
    if not url:
        return None
    if url.startswith("postgresql+asyncpg://"):
        return "postgresql://" + url[len("postgresql+asyncpg://") :]
    return url

def _with_sslmode(url: str) -> str:
    """
    Добавляет sslmode=require, если он отсутствует. Важно для Neon.
    """
    parsed = urlparse(url)
    q = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if "sslmode" not in q:
        q["sslmode"] = "require"
    new_query = urlencode(q)
    return urlunparse(parsed._replace(query=new_query))

def _resolve_sync_database_url() -> str:
    """
    Предпочитаем SYNC_DATABASE_URL. Если нет — преобразуем DATABASE_URL (async).
    Обязательно добавляем sslmode=require.
    """
    sync_url = getattr(settings, "SYNC_DATABASE_URL", None) or os.getenv("SYNC_DATABASE_URL")
    if not sync_url:
        base = getattr(settings, "DATABASE_URL", None) or os.getenv("DATABASE_URL")
        sync_url = _to_sync_url(base)
        if not sync_url:
            raise RuntimeError("Не задан ни SYNC_DATABASE_URL, ни DATABASE_URL для Alembic.")
    return _with_sslmode(sync_url)

SYNC_DATABASE_URL = _resolve_sync_database_url()
logger.info("Alembic подключается к БД (sync): %s [schema=%s]", SYNC_DATABASE_URL, SCHEMA)

# ---------------------------------------------------------------------------
# Целевая metadata (autogenerate отключён; оставляем None)
# ---------------------------------------------------------------------------
target_metadata = None

# ---------------------------------------------------------------------------
# Общая прелюдия подключения: создать схему и выставить search_path
# ---------------------------------------------------------------------------
def _prepare_schema(conn) -> None:
    """
    Создаёт схему, если её нет, и выставляет search_path на неё (и public).
    """
    conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}"'))
    conn.execute(text(f"SET search_path TO {SCHEMA}, public"))
    logger.info("search_path установлен: %s, public", SCHEMA)

# ---------------------------------------------------------------------------
# OFFLINE: генерируем SQL без подключения (но с указанием схемы для version)
# ---------------------------------------------------------------------------
def run_migrations_offline() -> None:
    url = SYNC_DATABASE_URL
    logger.info("Запуск миграций в offline-режиме для %s", url)
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,        # сравнение типов отключить/включить по надобности
        version_table_schema=SCHEMA,
        include_schemas=True,
    )
    with context.begin_transaction():
        context.run_migrations()

# ---------------------------------------------------------------------------
# ONLINE: реальные миграции с соединением и search_path
# ---------------------------------------------------------------------------
def run_migrations_online() -> None:
    connectable: Engine = create_engine(
        SYNC_DATABASE_URL,
        poolclass=NullPool,  # миграциям не нужен пул
        future=True,
    )

    with connectable.connect() as connection:
        # ВАЖНО: выставить search_path и убедиться, что схема существует
        _prepare_schema(connection)

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            render_as_batch=False,       # на PostgreSQL batch не нужен
            version_table_schema=SCHEMA, # alembic_version хранится в нашей схеме
            include_schemas=True,
        )

        with context.begin_transaction():
            context.run_migrations()

# ---------------------------------------------------------------------------
# Точка входа Alembic
# ---------------------------------------------------------------------------
if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
