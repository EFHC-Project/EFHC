# alembic/versions/0001_init_canon.py
# -*- coding: utf-8 -*-
"""
EFHC Bot — инициализация канонической схемы БД (первая миграция)

Ключевые принципы этой ревизии:
- Данные — первичны. БД допускает наличие исторически отрицательных значений
  у пользовательских балансов (main/bonus/available_kwh), чтобы не «ломать»
  систему и дать пользователю возможность компенсировать долг.
- Запрет «ухода в минус» обеспечивается на уровне бизнес-кода (дебет-операции),
  а не жёсткими CHECK-ограничениями в БД.
- Идемпотентность и статусная обработка — через уникальные ключи и индексы.
"""

from alembic import op
import sqlalchemy as sa
import os

# Идентификаторы миграции
revision = "0001_init_canon"
down_revision = None
branch_labels = None
depends_on = None

# Схема берётся из ENV (alembic запускается отдельным процессом)
SCHEMA = os.environ.get("DB_SCHEMA_CORE", "efhc_core")

# Удобные типы
NUM_30_8 = sa.Numeric(30, 8)


def upgrade():
    # --- Схема
    op.execute(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")

    # --- users
    # ВАЖНО: НЕТ CHECK ограничений >= 0 — БД допускает исторические минусы.
    op.create_table(
        "users",
        sa.Column("id", sa.BigInteger, primary_key=True),
        sa.Column("telegram_id", sa.BigInteger, nullable=False, unique=True, index=True),
        sa.Column("username", sa.Text, nullable=True),
        sa.Column("is_vip", sa.Boolean, nullable=False, server_default=sa.text("FALSE")),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("TRUE")),
        sa.Column("ton_wallet", sa.Text, nullable=True, unique=True),
        sa.Column("main_balance", NUM_30_8, nullable=False, server_default="0"),
        sa.Column("bonus_balance", NUM_30_8, nullable=False, server_default="0"),
        sa.Column("total_generated_kwh", NUM_30_8, nullable=False, server_default="0"),
        sa.Column("available_kwh", NUM_30_8, nullable=False, server_default="0"),
        sa.Column("created_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        schema=SCHEMA,
    )
    # Примечание: запрет «в минус» реализуется в сервисе транзакций, а не CHECK’ами.

    # --- bank_state (банк может быть отрицательным — это допускается каноном)
    op.create_table(
        "bank_state",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("balance", NUM_30_8, nullable=False, server_default="0"),
        schema=SCHEMA,
    )
    op.execute(f"INSERT INTO {SCHEMA}.bank_state(id, balance) VALUES (1, 0) ON CONFLICT DO NOTHING")

    # --- efhc_transfers_log (идемпотентный журнал всех EFHC-операций)
    op.create_table(
        "efhc_transfers_log",
        sa.Column("id", sa.BigInteger, primary_key=True),
        sa.Column("user_id", sa.BigInteger, nullable=False),
        sa.Column("amount", NUM_30_8, nullable=False),
        sa.Column("direction", sa.Text, nullable=False),      # 'credit' | 'debit' | 'exchange'
        sa.Column("balance_type", sa.Text, nullable=False),   # 'main' | 'bonus'
        sa.Column("reason", sa.Text, nullable=False),
        sa.Column("idempotency_key", sa.Text, nullable=False, unique=True),
        sa.Column("meta", sa.JSON, nullable=True),
        sa.Column("created_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], [f"{SCHEMA}.users.id"], ondelete="CASCADE"),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_efhc_transfers_user_created",
        f"{SCHEMA}.efhc_transfers_log",
        ["user_id", "created_at"],
        unique=False,
    )

    # --- ton_inbox_logs (канонический статусный лог входящих TON)
    op.create_table(
        "ton_inbox_logs",
        sa.Column("id", sa.BigInteger, primary_key=True),
        sa.Column("tx_hash", sa.Text, nullable=False, unique=True),
        sa.Column("from_address", sa.Text, nullable=True),
        sa.Column("to_address", sa.Text, nullable=True),
        sa.Column("amount", NUM_30_8, nullable=False, server_default="0"),
        sa.Column("memo", sa.Text, nullable=True),
        sa.Column("status", sa.Text, nullable=False, server_default=sa.text("'new'")),
        sa.Column("next_retry_at", sa.TIMESTAMP(timezone=True), nullable=True),
        sa.Column("retries_count", sa.Integer, nullable=False, server_default="0"),
        sa.Column("last_error", sa.Text, nullable=True),
        sa.Column("processed_at", sa.TIMESTAMP(timezone=True), nullable=True),
        sa.Column("created_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_ton_inbox_status_retry",
        f"{SCHEMA}.ton_inbox_logs",
        ["status", "next_retry_at"],
        unique=False,
    )
    op.create_index(
        "ix_ton_inbox_created",
        f"{SCHEMA}.ton_inbox_logs",
        ["created_at"],
        unique=False,
    )

    # --- ton_tx_logs (legacy путевой лог; оставлен для совместимости)
    op.create_table(
        "ton_tx_logs",
        sa.Column("id", sa.BigInteger, primary_key=True),
        sa.Column("tx_hash", sa.Text, nullable=False, unique=True),
        sa.Column("from_addr", sa.Text, nullable=True),
        sa.Column("to_addr", sa.Text, nullable=True),
        sa.Column("amount", NUM_30_8, nullable=False, server_default="0"),
        sa.Column("memo", sa.Text, nullable=True),
        sa.Column("status", sa.Text, nullable=False),
        sa.Column("note", sa.Text, nullable=True),
        sa.Column("ts", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_ton_tx_logs_ts",
        f"{SCHEMA}.ton_tx_logs",
        ["ts"],
        unique=False,
    )

    # --- shop_orders (EFHC-пакеты — авто; NFT — заявка/ручная модерация)
    op.create_table(
        "shop_orders",
        sa.Column("id", sa.BigInteger, primary_key=True),
        sa.Column("user_id", sa.BigInteger, nullable=False),
        sa.Column("type", sa.Text, nullable=False),  # 'EFHC' | 'NFT'
        sa.Column("status", sa.Text, nullable=False, server_default=sa.text("'PENDING'")),
        sa.Column("tx_hash", sa.Text, nullable=True, unique=True),      # ончейн-транзакция (если есть)
        sa.Column("external_id", sa.Text, nullable=True, unique=True),  # legacy OID из MEMO (если был)
        sa.Column("created_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], [f"{SCHEMA}.users.id"], ondelete="CASCADE"),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_shop_orders_user_status",
        f"{SCHEMA}.shop_orders",
        ["user_id", "status"],
        unique=False,
    )

    # --- admin_bank_config (id=1 — владелец банка)
    op.create_table(
        "admin_bank_config",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("admin_telegram_id", sa.BigInteger, nullable=False),
        sa.Column("created_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.TIMESTAMP(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        schema=SCHEMA,
    )
    admin_id = os.environ.get("ADMIN_TELEGRAM_ID")
    if admin_id and admin_id.isdigit():
        op.execute(
            f"INSERT INTO {SCHEMA}.admin_bank_config(id, admin_telegram_id) "
            f"VALUES (1, {admin_id}) ON CONFLICT DO NOTHING"
        )
    else:
        op.execute(
            f"INSERT INTO {SCHEMA}.admin_bank_config(id, admin_telegram_id) "
            f"VALUES (1, 0) ON CONFLICT DO NOTHING"
        )


def downgrade():
    # Удаляем в обратном порядке зависимости
    op.drop_table("admin_bank_config", schema=SCHEMA)

    op.drop_index("ix_shop_orders_user_status", table_name="shop_orders", schema=SCHEMA)
    op.drop_table("shop_orders", schema=SCHEMA)

    op.drop_index("ix_ton_tx_logs_ts", table_name="ton_tx_logs", schema=SCHEMA)
    op.drop_table("ton_tx_logs", schema=SCHEMA)

    op.drop_index("ix_ton_inbox_created", table_name="ton_inbox_logs", schema=SCHEMA)
    op.drop_index("ix_ton_inbox_status_retry", table_name="ton_inbox_logs", schema=SCHEMA)
    op.drop_table("ton_inbox_logs", schema=SCHEMA)

    op.drop_index("ix_efhc_transfers_user_created", table_name="efhc_transfers_log", schema=SCHEMA)
    op.drop_table("efhc_transfers_log", schema=SCHEMA)

    op.drop_table("bank_state", schema=SCHEMA)

    op.drop_table("users", schema=SCHEMA)
    # Схему не удаляем умышленно.
