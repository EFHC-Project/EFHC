# -*- coding: utf-8 -*-
# backend/migrations/versions/20251113_0002_seed_admin_bank.py
# =============================================================================
# Назначение кода:
# Seed-миграция: зафиксировать текущего держателя «Банка EFHC» по значению
# ADMIN_BANK_TELEGRAM_ID. Если записи нет — создать; если есть, но с другим ID —
# обновить существующую запись. Адаптировано под Neon (PostgreSQL, SSL).
#
# Канон / инварианты:
# • Банк EFHC — единый источник движения EFHC. В БД должен быть явный владелец.
# • Пользователи не могут уходить в минус (правило в сервисах), банк — может.
# • Миграция не создаёт таблицы — они уже есть в 0001_init, схема выставлена env.py.
#
# ИИ-защиты:
# • Берём ADMIN_BANK_TELEGRAM_ID из окружения; если нет — пробуем config_core.
# • Операции idempotent: повторный запуск не дублирует записи.
# • Без деструктивных действий: не удаляем лишние строки (оставляем историю).
#
# Запреты:
# • Никаких DROP/ALTER DROP. Только безопасные INSERT/UPDATE.
# =============================================================================

from __future__ import annotations

import os
import logging
from alembic import op
from sqlalchemy import text

# Идентификаторы Alembic
revision = "20251113_0002"
down_revision = "20251113_0001"
branch_labels = None
depends_on = None

logger = logging.getLogger(__name__)


def _resolve_admin_bank_tg_id() -> int:
    """
    Пытаемся получить ADMIN_BANK_TELEGRAM_ID из ENV.
    Если нет — пробуем импортировать из backend.app.core.config_core.get_settings().
    Возвращаем int > 0 или поднимаем RuntimeError.
    """
    raw = os.getenv("ADMIN_BANK_TELEGRAM_ID")
    if not raw:
        try:
            # Импорт настроек приложения (если путь доступен при миграциях)
            from backend.app.core.config_core import get_settings  # type: ignore
            raw = str(get_settings().ADMIN_BANK_TELEGRAM_ID)  # может быть int
        except Exception as e:
            raise RuntimeError(
                "ADMIN_BANK_TELEGRAM_ID не задан ни в ENV, ни в config_core."
            ) from e

    try:
        value = int(raw)
    except Exception as e:
        raise RuntimeError("ADMIN_BANK_TELEGRAM_ID должен быть целым числом.") from e

    if value <= 0:
        raise RuntimeError("ADMIN_BANK_TELEGRAM_ID должен быть положительным.")
    return value


def upgrade() -> None:
    # Получаем соединение Alembic (search_path уже выставлен в env.py)
    conn = op.get_bind()
    bank_tg_id = _resolve_admin_bank_tg_id()

    # 1) Проверяем, есть ли вообще запись в admin_bank_config.
    row = conn.execute(
        text("SELECT id, bank_telegram_id FROM admin_bank_config ORDER BY id ASC LIMIT 1")
    ).fetchone()

    if row is None:
        # 1а) Записей нет — создаём первую.
        conn.execute(
            text(
                """
                INSERT INTO admin_bank_config (bank_telegram_id)
                VALUES (:tg)
                """
            ),
            {"tg": bank_tg_id},
        )
        logger.info("admin_bank_config: создана запись с bank_telegram_id=%s", bank_tg_id)
        return

    # 1б) Запись есть — при необходимости обновим bank_telegram_id.
    current_id, current_bank_tg = row[0], row[1]
    if current_bank_tg != bank_tg_id:
        conn.execute(
            text(
                """
                UPDATE admin_bank_config
                SET bank_telegram_id = :tg
                WHERE id = :id
                """
            ),
            {"tg": bank_tg_id, "id": current_id},
        )
        logger.info(
            "admin_bank_config: обновлён bank_telegram_id %s → %s (id=%s)",
            current_bank_tg,
            bank_tg_id,
            current_id,
        )
    else:
        logger.info("admin_bank_config: актуален bank_telegram_id=%s — изменений не требуется", bank_tg_id)

    # Примечание:
    # В таблице может быть больше одной строки исторически. Мы сознательно НЕ удаляем
    # «лишние» строки, чтобы не нарушать принцип «без деструктива в миграциях».
    # Для строгого синглтона можно будет добавить отдельную сервисную процедуру/скрипт
    # в админке (не миграцией).


def downgrade() -> None:
    # Канон: деструктивные откаты не применяем автоматически.
    # Если потребуется изменить владельца — выполняется новая миграция/операция.
    pass
