# -*- coding: utf-8 -*-
# backend/migrations/versions/20251113_0003_bank_state_and_admin_nft_whitelist.py
# =============================================================================
# Назначение кода:
# Добавить ядро банка EFHC в БД:
#   • bank_state — агрегированное состояние Банка EFHC;
#   • admin_nft_whitelist — расширенная анкета whitelisted-админов по Telegram ID.
#
# Канон / инварианты:
# • Все денежные величины — NUMERIC(30, 8), знак не ограничиваем (банк может быть < 0).
# • Пользователи не могут уходить в минус — это правило сервисов, не CHECK в БД.
# • Банк может уходить в минус — это норма (владелец печатного станка).
# • admin_nft_whitelist используется ТОЛЬКО для доступа к админ-панели
#   (require_admin_or_nft_or_key), не для геймификации.
#
# ИИ-защиты:
# • Таблицы создаются через ensure_table_with_basics, повторный запуск миграции
#   не ломает уже существующую схему.
# • Никаких DROP/ALTER — только «добавить, если нет».
# =============================================================================

from __future__ import annotations

from alembic import op
import sqlalchemy as sa

from backend.migrations.lib.safe import (
    ensure_table_with_basics,
)

# Идентификаторы Alembic
revision = "20251113_0003"
down_revision = "20251113_0002"
branch_labels = None
depends_on = None

# Общие типы
NUM = sa.Numeric(30, 8)
TZ = sa.DateTime(timezone=True)


def upgrade() -> None:
    """
    Основной апгрейд:
      1) Создание bank_state — агрегированного состояния Банка EFHC.
      2) Создание admin_nft_whitelist — расширенного списка whitelisted-админов.
    """

    # -------------------------------------------------------------------------
    # bank_state — агрегированное состояние Банка EFHC
    # -------------------------------------------------------------------------
    #
    # Смысл:
    #   • одна запись (id=1) описывает текущее состояние Банка EFHC;
    #   • balance_total     — общий баланс Банка (main+bonus+прочие слои, если появятся);
    #   • balance_main      — суммарный баланс «обычных» EFHC, находящихся у Банка;
    #   • balance_bonus     — суммарный баланс бонусных EFHC у Банка;
    #   • emitted_total     — сколько EFHC всего эмитировано Банком;
    #   • burned_total      — сколько EFHC всего безвозвратно сожжено Банком;
    #   • last_recalc_at    — момент последней консистентной пересборки агрегатов;
    #   • updated_at        — момент последнего изменения записи;
    #   • extra_info        — текстовое поле для будущих расширений (JSON/diagnostics).
    #
    # Инварианты:
    #   • Знак balance_* и *_total НЕ ограничиваем: банк может быть в дефиците.
    #   • Вся фактическая логика изменения значений живёт в bank_service/transactions_service.
    #
    ensure_table_with_basics(
        "bank_state",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            # Общий баланс Банка EFHC (main+bonus+служебные слои — если появятся).
            sa.Column(
                "balance_total",
                NUM,
                nullable=False,
                server_default="0",
            ),
            # Агрегированный баланс «обычных» EFHC у Банка.
            sa.Column(
                "balance_main",
                NUM,
                nullable=False,
                server_default="0",
            ),
            # Агрегированный баланс бонусных EFHC у Банка.
            sa.Column(
                "balance_bonus",
                NUM,
                nullable=False,
                server_default="0",
            ),
            # Сколько EFHC всего эмитировано Банком за всё время (main+bonus в номинале).
            sa.Column(
                "emitted_total",
                NUM,
                nullable=False,
                server_default="0",
            ),
            # Сколько EFHC всего безвозвратно сожжено Банком (burn).
            sa.Column(
                "burned_total",
                NUM,
                nullable=False,
                server_default="0",
            ),
            # Время последнего консистентного пересчёта агрегатов (по логам).
            sa.Column(
                "last_recalc_at",
                TZ,
                nullable=True,
            ),
            # Время последнего обновления записи bank_state (любое изменение полей).
            sa.Column(
                "updated_at",
                TZ,
                nullable=False,
                server_default=sa.text("now()"),
            ),
            # Текстовое поле для расширений: JSON, диагностические сводки и т.п.
            sa.Column(
                "extra_info",
                sa.Text,
                nullable=True,
            ),
        ],
        # Один индекс для удобства отчётности/health-check'ов.
        indexes=[
            ("ix_bank_state_updated_id", ["updated_at", "id"], False),
        ],
    )

    # -------------------------------------------------------------------------
    # admin_nft_whitelist — расширенный whitelist админ-доступа по Telegram ID
    # -------------------------------------------------------------------------
    #
    # Смысл:
    #   • используется только для входа в админ-панель (require_admin_or_nft_or_key);
    #   • позволяет гибко расширять круг админов/модераторов без хардкода в коде;
    #   • хранит максимально расширенную «анкету» (по канону — расширяем до разумного).
    #
    # Основные поля:
    #   • telegram_id   — уникальный Telegram ID пользователя (обязателен);
    #   • full_name     — ФИО/ник, как отображать в админке;
    #   • username      — @username, если есть;
    #   • source        — откуда появился доступ: 'manual' | 'nft' | 'promo' | ...;
    #   • note          — свободный комментарий админа;
    #   • created_by    — Telegram ID того, кто выдал доступ (если известен);
    #   • is_active     — активен ли доступ сейчас;
    #   • created_at    — когда запись создана;
    #   • updated_at    — когда в последний раз менялась;
    #   • revoked_at    — когда доступ был отозван (если отозван);
    #   • extra_info    — любые дополнительные сведения (строкой, при необходимости JSON).
    #
    ensure_table_with_basics(
        "admin_nft_whitelist",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("telegram_id", sa.BigInteger, nullable=False),
            sa.Column("full_name", sa.String(255)),
            sa.Column("username", sa.String(64)),
            sa.Column("source", sa.String(32)),   # 'manual' | 'nft' | 'promo' | ...
            sa.Column("note", sa.Text),
            sa.Column("created_by", sa.BigInteger),
            sa.Column(
                "is_active",
                sa.Boolean,
                nullable=False,
                server_default=sa.text("true"),
            ),
            sa.Column(
                "created_at",
                TZ,
                nullable=False,
                server_default=sa.text("now()"),
            ),
            sa.Column("updated_at", TZ),
            sa.Column("revoked_at", TZ),
            sa.Column("extra_info", sa.Text),
        ],
        uniques=[
            # Один telegram_id — одна активная запись в whitelist.
            ("uq_admin_nft_whitelist_telegram", ["telegram_id"]),
        ],
        indexes=[
            # Ускоряем выборки по активным записям и по времени добавления.
            ("ix_admin_nft_whitelist_active", ["is_active", "created_at"], False),
        ],
    )


def downgrade() -> None:
    """
    Канон: автоматических деструктивных откатов не делаем.
    Если когда-то потребуется убрать/поменять эти таблицы — создаётся
    отдельная миграция с явными шагами под контролем администратора.
    """
    pass
