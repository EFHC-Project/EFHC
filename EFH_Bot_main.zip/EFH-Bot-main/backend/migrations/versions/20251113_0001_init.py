# -*- coding: utf-8 -*-
# backend/migrations/versions/20251113_0001_init.py
# =============================================================================
# Назначение кода:
# Первичная миграция EFHC Bot под PostgreSQL/Neon. Создаёт все ключевые таблицы,
# индексы и UNIQUE по канону. Безопасна к повторным запускам (ensure_*).
#
# Канон / инварианты:
# • Денежные величины: NUMERIC(30, 8), округление вниз реализовано в сервисах.
# • Идемпотентность: UNIQUE на idempotency_key/tx_hash там, где требуется.
# • Курсорная пагинация: индексы по (created_at, id).
# • Пользователи не уходят в минус — правило в сервисах (CHECK не ставим).
# • Банк может быть в минусе — в БД не ограничиваем, контролирует сервис банка.
#
# ИИ-защиты:
# • Все create-* идут через ensure_* (не ломаем уже созданное).
# • В таблицах логов индексы под фоновые «догон»/ретраи.
#
# Запреты:
# • Никаких DROP/ALTER DROP. Для изменения типов делаем отдельные миграции.
# =============================================================================

from __future__ import annotations
from alembic import op
import sqlalchemy as sa

from backend.migrations.lib.safe import (
    ensure_schema,
    ensure_table_with_basics,
    ensure_column,
    ensure_index,
    ensure_unique_constraint,
)

# Идентификаторы Alembic
revision = "20251113_0001"
down_revision = None
branch_labels = None
depends_on = None

# Общие типы
NUM = sa.Numeric(30, 8)
TZ  = sa.DateTime(timezone=True)

def upgrade() -> None:
    # -----------------------------------------------------------------------------
    # Схема (должна совпадать с DB_SCHEMA_CORE в .env / alembic/env.py)
    # -----------------------------------------------------------------------------
    ensure_schema("efhc_core")

    # -----------------------------------------------------------------------------
    # users — профиль и балансы
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "users",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("telegram_id", sa.BigInteger, nullable=False, unique=True),
            sa.Column("username", sa.String(255)),
            sa.Column("is_vip", sa.Boolean, nullable=False, server_default=sa.text("false")),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
            sa.Column("ton_wallet", sa.String(128), unique=True),
            sa.Column("main_balance", NUM, nullable=False, server_default="0"),
            sa.Column("bonus_balance", NUM, nullable=False, server_default="0"),
            sa.Column("total_generated_kwh", NUM, nullable=False, server_default="0"),
            sa.Column("available_kwh", NUM, nullable=False, server_default="0"),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("updated_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        indexes=[
            ("ix_users_created_id", ["created_at", "id"], False),
            ("ix_users_is_active_id", ["is_active", "id"], False),
        ],
    )

    # -----------------------------------------------------------------------------
    # panels — активные панели пользователя
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "panels",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("user_id", sa.BigInteger, nullable=False),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("expires_at", TZ, nullable=False),
            sa.Column("last_generated_at", TZ),
            sa.Column("base_gen_per_sec", NUM, nullable=False),   # берем из settings GEN_PER_SEC_*
            sa.Column("generated_kwh", NUM, nullable=False, server_default="0"),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
        ],
        indexes=[
            ("ix_panels_user_active_expire", ["user_id", "is_active", "expires_at"], False),
            ("ix_panels_created_id", ["created_at", "id"], False),
        ],
    )
    # FK вручную (через safe не делаем), но add_if_not_exists эквивалента нет — создаём обычным способом:
    op.create_foreign_key(
        "fk_panels_user",
        "panels",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # panels_archive — архивные панели
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "panels_archive",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("user_id", sa.BigInteger, nullable=False),
            sa.Column("created_at", TZ, nullable=False),
            sa.Column("expires_at", TZ, nullable=False),
            sa.Column("closed_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("base_gen_per_sec", NUM, nullable=False),
            sa.Column("generated_kwh", NUM, nullable=False, server_default="0"),
        ],
        indexes=[
            ("ix_panels_archive_user_id", ["user_id", "id"], False),
            ("ix_panels_archive_closed_id", ["closed_at", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_panels_archive_user",
        "panels_archive",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # efhc_transfers_log — банковские движения (ядро идемпотентности денег)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "efhc_transfers_log",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("user_id", sa.BigInteger),  # может быть NULL для чисто банковских операций
            sa.Column("amount", NUM, nullable=False),
            sa.Column("direction", sa.String(16), nullable=False),      # 'credit' | 'debit'
            sa.Column("balance_type", sa.String(16), nullable=False),   # 'main' | 'bonus'
            sa.Column("reason", sa.String(64), nullable=False),
            sa.Column("idempotency_key", sa.String(128), nullable=False),
            sa.Column("extra_info", sa.Text),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        uniques=[("uq_efhc_transfers_idk", ["idempotency_key"])],
        indexes=[
            ("ix_efhc_transfers_created_id", ["created_at", "id"], False),
            ("ix_efhc_transfers_user_created", ["user_id", "created_at"], False),
        ],
    )
    op.create_foreign_key(
        "fk_efhc_transfers_user",
        "efhc_transfers_log",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="SET NULL",
    )

    # -----------------------------------------------------------------------------
    # ton_inbox_logs — входящие транзакции TON (вотчер)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "ton_inbox_logs",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("tx_hash", sa.String(128), nullable=False),
            sa.Column("from_address", sa.String(128)),
            sa.Column("to_address", sa.String(128)),
            sa.Column("amount", NUM, nullable=False, server_default="0"),
            sa.Column("memo", sa.Text),
            sa.Column("status", sa.String(32), nullable=False, server_default="received"),
            sa.Column("next_retry_at", TZ),
            sa.Column("retries_count", sa.Integer, nullable=False, server_default="0"),
            sa.Column("processed_at", TZ),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("updated_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        uniques=[("uq_ton_inbox_tx_hash", ["tx_hash"])],
        indexes=[
            ("ix_ton_inbox_status_retry", ["status", "next_retry_at"], False),
            ("ix_ton_inbox_created_id", ["created_at", "id"], False),
        ],
    )

    # -----------------------------------------------------------------------------
    # shop_orders — магазин (EFHC-пакеты авто; NFT — ручная заявка)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "shop_orders",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("user_id", sa.BigInteger, nullable=False),
            sa.Column("type", sa.String(16), nullable=False),     # 'EFHC' | 'NFT'
            sa.Column("status", sa.String(32), nullable=False, server_default="PENDING"),
            sa.Column("sku", sa.String(128), nullable=False),
            sa.Column("quantity", sa.Integer, nullable=False, server_default="1"),
            sa.Column("amount", NUM, nullable=False, server_default="0"),  # для EFHC-пакетов
            sa.Column("tx_hash", sa.String(128)),                  # для автодоставки EFHC по оплате
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("updated_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        uniques=[("uq_shop_tx_hash", ["tx_hash"])],
        indexes=[
            ("ix_shop_user_created_id", ["user_id", "created_at", "id"], False),
            ("ix_shop_status_id", ["status", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_shop_user",
        "shop_orders",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # withdraw_requests — вывод только EFHC
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "withdraw_requests",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("user_id", sa.BigInteger, nullable=False),
            sa.Column("amount", NUM, nullable=False),
            sa.Column("status", sa.String(32), nullable=False, server_default="PENDING"),
            sa.Column("idempotency_key", sa.String(128), nullable=False),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("updated_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        uniques=[("uq_withdraw_idk", ["idempotency_key"])],
        indexes=[
            ("ix_withdraw_user_created_id", ["user_id", "created_at", "id"], False),
            ("ix_withdraw_status_id", ["status", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_withdraw_user",
        "withdraw_requests",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # referrals — связи рефералов (активность после первой покупки панели)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "referrals",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("inviter_user_id", sa.BigInteger, nullable=False),
            sa.Column("invitee_user_id", sa.BigInteger, nullable=False),
            sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("false")),
            sa.Column("activated_at", TZ),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        uniques=[("uq_ref_invitee", ["invitee_user_id"])],
        indexes=[
            ("ix_ref_inviter_created_id", ["inviter_user_id", "created_at", "id"], False),
            ("ix_ref_is_active_id", ["is_active", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_ref_inviter",
        "referrals",
        "users",
        local_cols=["inviter_user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "fk_ref_invitee",
        "referrals",
        "users",
        local_cols=["invitee_user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # user_tasks — задания (бонусы только через Банк)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "user_tasks",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("user_id", sa.BigInteger, nullable=False),
            sa.Column("task_code", sa.String(64), nullable=False),
            sa.Column("status", sa.String(16), nullable=False, server_default="NEW"),  # NEW/CLAIMING/CLAIMED
            sa.Column("claim_idk", sa.String(128)),  # idempotency для CLAIMED
            sa.Column("claimed_at", TZ),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("updated_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        uniques=[("uq_tasks_claim_idk", ["claim_idk"])],
        indexes=[
            ("ix_tasks_user_created_id", ["user_id", "created_at", "id"], False),
            ("ix_tasks_status_id", ["status", "id"], False),
        ],
    )
    op.create_foreign_key(
        "fk_tasks_user",
        "user_tasks",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # rating_snapshots — снимки для витрин рейтинга (Я + TOP)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "rating_snapshots",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("snapshot_at", TZ, nullable=False),
            sa.Column("user_id", sa.BigInteger, nullable=False),
            sa.Column("total_generated_kwh", NUM, nullable=False, server_default="0"),
            sa.Column("rank", sa.Integer, nullable=False),
        ],
        uniques=[("uq_rating_snapshot_user_at", ["snapshot_at", "user_id"])],
        indexes=[
            ("ix_rating_snapshot_at_rank", ["snapshot_at", "rank"], False),
        ],
    )
    op.create_foreign_key(
        "fk_rating_snapshot_user",
        "rating_snapshots",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # vip_status_log — аудит переключений VIP по NFT
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "vip_status_log",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("user_id", sa.BigInteger, nullable=False),
            sa.Column("had_vip_before", sa.Boolean, nullable=False),
            sa.Column("has_vip_now", sa.Boolean, nullable=False),
            sa.Column("changed_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        indexes=[
            ("ix_vip_log_user_changed", ["user_id", "changed_at"], False),
        ],
    )
    op.create_foreign_key(
        "fk_vip_log_user",
        "vip_status_log",
        "users",
        local_cols=["user_id"],
        remote_cols=["id"],
        ondelete="CASCADE",
    )

    # -----------------------------------------------------------------------------
    # scheduler_task_log — журнал фоновых задач (ретраи/ошибки/метрики)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "scheduler_task_log",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("task_name", sa.String(64), nullable=False),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("error_text", sa.Text),
            sa.Column("retry_time", TZ),
            sa.Column("executed_at", TZ, server_default=sa.text("now()"), nullable=False),
            sa.Column("duration_sec", sa.Integer, nullable=False, server_default="0"),
        ],
        indexes=[
            ("ix_sched_task_name_time", ["task_name", "executed_at"], False),
        ],
    )

    # -----------------------------------------------------------------------------
    # admin_bank_config — конфиг банка (чей telegram_id считается Банком)
    # -----------------------------------------------------------------------------
    ensure_table_with_basics(
        "admin_bank_config",
        cols=[
            sa.Column("id", sa.BigInteger, primary_key=True),
            sa.Column("bank_telegram_id", sa.BigInteger, nullable=False),
            sa.Column("created_at", TZ, server_default=sa.text("now()"), nullable=False),
        ],
        uniques=[("uq_admin_bank_singleton", ["bank_telegram_id"])],
    )

def downgrade() -> None:
    # Канон: деструктивные откаты не выполняем автоматически.
    # Если понадобится — пишем явные шаги под контролем админа.
    pass
