# -*- coding: utf-8 -*-
# backend/migrations/lib/safe.py
# =============================================================================
# Назначение кода:
# Вспомогательные функции для «защищённых» миграций Alembic: таблицы/колонки/
# индексы/констреинты создаются только если их нет. Уже существующие объекты
# не трогаем. Это позволяет безопасно повторно прогонять миграции и «лечить»
# частично развёрнутые базы без ручного вмешательства.
#
# Канон / инварианты:
# • Работает на PostgreSQL. Оперирует только в активной схеме (search_path),
#   которую настраивает alembic/env.py (DB_SCHEMA_CORE).
# • Никаких деструктивных DDL по умолчанию (DROP/ALTER … DROP).
#
# ИИ-защиты:
# • Перед созданием объекта выполняется инспекция каталога БД.
# • Для индексов/уникальных ограничений делаем проверку по имени.
# • Для колонок — проверка существования и минимальная валидация типа.
#
# Запреты:
# • Нет автоматического «исправления» несовпадающих типов колонок. Если тип
#   в БД отличается — миграцию пишем явно (ALTER TABLE … TYPE …).
# • Нет неявного переименования объектов — только проверка/создание.
# =============================================================================

from __future__ import annotations

from typing import Iterable, Sequence

from alembic import op
import sqlalchemy as sa
from sqlalchemy.engine import Connection
from sqlalchemy.engine.reflection import Inspector
from sqlalchemy import text


# -----------------------------------------------------------------------------
# Базовые утилиты инспекции каталога
# -----------------------------------------------------------------------------

def _get_bind() -> Connection:
    """Текущий bind из контекста Alembic."""
    return op.get_bind()


def get_inspector() -> Inspector:
    """Возвращает инспектор для активного соединения."""
    return sa.inspect(_get_bind())


def current_schema() -> str:
    """Имя активной схемы (для отладки/логирования)."""
    row = _get_bind().execute(text("SELECT current_schema()")).scalar()
    return str(row or "")


# -----------------------------------------------------------------------------
# Схема и таблицы
# -----------------------------------------------------------------------------

def ensure_schema(schema_name: str) -> None:
    """
    Создаёт схему, если её нет (безошибочно, если уже есть).
    Полезно запускать в прелюдии «init»-миграции.
    """
    if not schema_name:
        return
    op.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema_name}"'))


def table_exists(table_name: str) -> bool:
    """Проверяет существование таблицы в текущем search_path."""
    insp = get_inspector()
    return insp.has_table(table_name)


def ensure_table(table_name: str, *columns: sa.Column, indexes: Sequence[tuple] | None = None, table_kwargs: dict | None = None) -> None:
    """
    Создаёт таблицу с указанными колонками, если её нет.
    indexes: последовательность кортежей для последующего ensure_index(...)
             формат: (index_name, [col1, col2, ...], unique=False)
    table_kwargs: дополнительные параметры в op.create_table (например, sa.PrimaryKeyConstraint(...))
    """
    if table_exists(table_name):
        return
    op.create_table(table_name, *columns, **(table_kwargs or {}))
    if indexes:
        for idx_name, cols, *rest in indexes:
            unique = bool(rest[0]) if rest else False
            ensure_index(idx_name, table_name, cols, unique=unique)


# -----------------------------------------------------------------------------
# Колонки
# -----------------------------------------------------------------------------

def column_exists(table_name: str, column_name: str) -> bool:
    """Проверяет, есть ли колонка в таблице."""
    insp = get_inspector()
    for col in insp.get_columns(table_name):
        if col.get("name") == column_name:
            return True
    return False


def ensure_column(table_name: str, column: sa.Column) -> None:
    """
    Добавляет колонку, если её нет. Тип/nullable берутся из переданного Column.
    Важно: если колонка есть, но с другим типом — НИЧЕГО не делаем (канон).
    Для смены типа нужен отдельный явный ALTER в миграции.
    """
    if column_exists(table_name, column.name):  # type: ignore[attr-defined]
        return
    op.add_column(table_name, column)


# -----------------------------------------------------------------------------
# Индексы
# -----------------------------------------------------------------------------

def index_exists(table_name: str, index_name: str) -> bool:
    """Проверяет существование индекса по имени."""
    insp = get_inspector()
    try:
        for idx in insp.get_indexes(table_name):
            if idx.get("name") == index_name:
                return True
    except Exception:
        # Некоторые драйверы могут падать при отсутствующей таблице
        return False
    return False


def ensure_index(index_name: str, table_name: str, columns: Sequence[str], unique: bool = False) -> None:
    """
    Создаёт индекс, если его нет.
    На PostgreSQL предпочитаем проверку через инспектор + op.create_index,
    чтобы сохранить кросс-версионную поддержку Alembic.
    """
    if index_exists(table_name, index_name):
        return
    op.create_index(index_name, table_name, list(columns), unique=unique)


# -----------------------------------------------------------------------------
# Уникальные ограничения / констреинты
# -----------------------------------------------------------------------------

def unique_constraint_exists(table_name: str, constraint_name: str) -> bool:
    """Проверяет, существует ли UNIQUE-констреинт на таблице по имени."""
    insp = get_inspector()
    try:
        for uc in insp.get_unique_constraints(table_name):
            if uc.get("name") == constraint_name:
                return True
    except Exception:
        return False
    return False


def ensure_unique_constraint(constraint_name: str, table_name: str, columns: Sequence[str]) -> None:
    """
    Создаёт UNIQUE-констреинт, если его нет.
    Если в БД уже есть уникальный индекс с таким же именем — считаем достаточно.
    """
    if unique_constraint_exists(table_name, constraint_name):
        return
    # На некоторых БД имя UNIQUE-индекса совпадает с именем констреинта.
    # Для единообразия создаём именно констреинт:
    op.create_unique_constraint(constraint_name, table_name, list(columns))


# -----------------------------------------------------------------------------
# Комбинированные «ensure»-сценарии
# -----------------------------------------------------------------------------

def ensure_table_with_basics(
    table_name: str,
    cols: Iterable[sa.Column],
    pk: sa.PrimaryKeyConstraint | None = None,
    uniques: Sequence[tuple[str, Sequence[str]]] | None = None,
    indexes: Sequence[tuple[str, Sequence[str], bool]] | None = None,
) -> None:
    """
    Упрощённый сценарий: создать таблицу (если нет), затем нужные UNIQUE и индексы.
    uniques: [("uq_name", ["col1", "col2"]), ...]
    indexes: [("ix_name", ["col1", "col2"], False), ...]
    """
    if not table_exists(table_name):
        args = list(cols)
        if pk is not None:
            args.append(pk)
        op.create_table(table_name, *args)

    if uniques:
        for uq_name, uq_cols in uniques:
            ensure_unique_constraint(uq_name, table_name, uq_cols)

    if indexes:
        for ix_name, ix_cols, ix_unique in indexes:
            ensure_index(ix_name, table_name, ix_cols, unique=ix_unique)


# =============================================================================
# Пояснения «для чайника»:
# • Эти функции НЕ ломают существующую схему. Если объект уже есть — они молча
#   выходят. Так мы добиваемся идемпотентности миграций при повторных запусках.
# • Для сложных изменений (изменение типа/nullable, перенос данных) делайте
#   отдельные явные шаги миграции — здесь мы сознательно не «угадываем» логику.
# • Пример использования в миграции:
#
#   from backend.migrations.lib.safe import (
#       ensure_schema, ensure_table_with_basics, ensure_column, ensure_index,
#       ensure_unique_constraint, current_schema,
#   )
#
#   def upgrade():
#       ensure_schema("efhc_core")
#       ensure_table_with_basics(
#           "users",
#           cols=[
#               sa.Column("id", sa.BigInteger, primary_key=True),
#               sa.Column("telegram_id", sa.BigInteger, nullable=False, unique=True, index=True),
#               ...
#           ],
#           indexes=[("ix_users_created_id", ["created_at", "id"], False)],
#       )
#
# • После добавления этой библиотеки вы можете постепенно перевести «init»
#   миграцию на ensure_*-вызовы и получить самовосстанавливающийся старт.
# =============================================================================
