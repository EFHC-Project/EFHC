# -*- coding: utf-8 -*-
# backend/migrations/env.py
# =============================================================================
# Назначение кода:
# Alembic-окружение для EFHC Bot с поддержкой Neon (PostgreSQL, SSL) и
# единой схемой (DB_SCHEMA_CORE). Работает в offline/online режимах, выставляет
# search_path, совместим с нашим async-приложением (применяем sync-движок).
#
# Канон / инварианты:
# • База — PostgreSQL (Neon), SSL обязателен (?sslmode=require в URL).
# • Все объекты — в единой схеме DB_SCHEMA_CORE (по умолчанию efhc_core).
# • Миграции не должны быть деструктивными без явной необходимости.
#
# ИИ-защиты:
# • Автоматическая нормализация URL: если в окружении только async URL
#   (postgresql+asyncpg://...), Alembic получит sync-эквивалент (postgresql://...).
# • Явная установка search_path на схему из .env, чтобы миграции не «расползались».
# • Опциональная установка statement_timeout через окружение.
#
# Запреты:
# • Без жёсткого «затирания» схем/таблиц. Инициализацию схемы делаем в 0001_init.
# =============================================================================

from __future__ import annotations

import os
import re
import logging
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool, text
from alembic import context

# Конфигурация Alembic
config = context.config

# Логи Alembic
if config.config_file_name is not None:
    fileConfig(config.config_file_name)
logger = logging.getLogger("alembic.env")


# -----------------------------------------------------------------------------
# Параметры окружения / схема / таймаут
# -----------------------------------------------------------------------------
DB_SCHEMA_CORE = os.getenv("DB_SCHEMA_CORE", "efhc_core")

# Предпочитаем SYNC_DATABASE_URL для Alembic; иначе берём DATABASE_URL и конвертируем.
SYNC_DATABASE_URL = os.getenv("SYNC_DATABASE_URL")
DATABASE_URL = os.getenv("DATABASE_URL")

if not SYNC_DATABASE_URL:
    if not DATABASE_URL:
        raise RuntimeError("Не задан ни SYNC_DATABASE_URL, ни DATABASE_URL")
    # Преобразуем async URL в sync: postgresql+asyncpg:// → postgresql://
    SYNC_DATABASE_URL = re.sub(r"^postgresql\+asyncpg://", "postgresql://", DATABASE_URL)

# Neon требует SSL: добавим ?sslmode=require, если его нет
if "sslmode=" not in SYNC_DATABASE_URL:
    join = "&" if "?" in SYNC_DATABASE_URL else "?"
    SYNC_DATABASE_URL = f"{SYNC_DATABASE_URL}{join}sslmode=require"

# Statement timeout (мс) опционально
PG_STATEMENT_TIMEOUT_MS = os.getenv("PG_STATEMENT_TIMEOUT_MS")
if PG_STATEMENT_TIMEOUT_MS:
    try:
        int(PG_STATEMENT_TIMEOUT_MS)
    except ValueError:
        raise RuntimeError("PG_STATEMENT_TIMEOUT_MS должен быть целым числом миллисекунд")

# Прокидываем URL в конфиг Alembic
config.set_main_option("sqlalchemy.url", SYNC_DATABASE_URL)


# -----------------------------------------------------------------------------
# target_metadata — можно подключить Meta из моделей при необходимости автогенерации
# Мы оставляем None и пишем миграции явными скриптами (канон проекта).
# -----------------------------------------------------------------------------
target_metadata = None


def _set_search_path(connection) -> None:
    """
    Выставляет search_path на нашу схему перед выполнением миграций.
    """
    connection.execute(text(f"SET search_path TO {DB_SCHEMA_CORE}"))
    if PG_STATEMENT_TIMEOUT_MS:
        connection.execute(text(f"SET statement_timeout TO {int(PG_STATEMENT_TIMEOUT_MS)}"))


def run_migrations_offline() -> None:
    """
    Offline-режим: Alembic генерирует SQL без подключения к БД.
    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,   # сравнение типов включено
        compare_server_default=True,
        version_table_schema=DB_SCHEMA_CORE,
        include_schemas=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        # В offline search_path задаётся в 0001_init явным DDL CREATE SCHEMA IF NOT EXISTS
        context.run_migrations()


def run_migrations_online() -> None:
    """
    Online-режим: реальное подключение к БД, установка search_path и прогон миграций.
    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
        future=True,
    )

    with connectable.connect() as connection:
        # Важно: создаём схему, если её нет (безопасно)
        connection.execute(
            text(f"CREATE SCHEMA IF NOT EXISTS {DB_SCHEMA_CORE}")
        )
        _set_search_path(connection)

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
            version_table_schema=DB_SCHEMA_CORE,
            include_schemas=True,
            render_as_batch=False,  # batch не нужен для Neon
        )

        with context.begin_transaction():
            context.run_migrations()


# Точка входа Alembic
if context.is_offline_mode():
    logger.info("EFHC Alembic offline mode; schema=%s", DB_SCHEMA_CORE)
    run_migrations_offline()
else:
    logger.info("EFHC Alembic online mode; schema=%s", DB_SCHEMA_CORE)
    run_migrations_online()
