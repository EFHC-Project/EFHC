# -*- coding: utf-8 -*-
# backend/app/integrations/ton_api.py
# =============================================================================
# EFHC Bot — Интеграция с TON API (клиент + DTO событий)
# -----------------------------------------------------------------------------
# Назначение:
#   • Давать устойчивый к сбоям доступ к входящим платежам TON на адрес проекта.
#   • Нормализовать разные форматы ответов (tonapi.io, альтернативные ноды) в
#     единый DTO TonAPIEvent, пригодный для вотчера.
#
# Канон/инварианты:
#   • Денежные операции НЕ выполняются здесь. Модуль лишь читает блокчейн.
#   • Идемпотентность обеспечивается на уровне вотчера (UNIQUE tx_hash в БД).
#   • Никаких NFT/генераций/балансов — только получение и нормализация событий.
#
# ИИ-защиты/самовосстановление:
#   • Таймауты и последовательный fallback по списку базовых URL.
#   • Мягкая деградация форматов: поддержка нескольких схем JSON-ответов.
#   • Защита от дублей в пределах страницы (по tx_hash).
#   • Детектор «дыр» по времени (optional, для метрик) — возвращает маркеры.
#
# Запреты:
#   • Никакого записи в БД, переводов средств, автодоставки NFT — здесь это запрещено.
# =============================================================================

from __future__ import annotations

import asyncio
import base64
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Iterable, List, Optional, Tuple

import httpx  # асинхронный HTTP-клиент; требуется зависимость "httpx[http2]"

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

logger = get_logger(__name__)
settings = get_settings()

# -----------------------------------------------------------------------------
# Публичный DTO события входящего платежа
# -----------------------------------------------------------------------------
@dataclass
class TonAPIEvent:
    """
    Унифицированное событие входящего платежа.
    ВАЖНО: amount задаём в TON (целая монета), не в нанотонах. Округление вниз.
    """
    tx_hash: str
    from_address: str
    to_address: str
    amount: Decimal        # в TON (не нанотоны)
    memo: str              # human-readable комментарий (если был)
    utime: int             # unixtime (сек)

# -----------------------------------------------------------------------------
# Вспомогательные утилиты нормализации
# -----------------------------------------------------------------------------
def _nt_to_ton(value: Any) -> Decimal:
    """
    Перевод нанотонов (int/str) в TON (Decimal) с округлением вниз и ограничением точности.
    Если приходит уже в TON — пытаемся интерпретировать корректно.
    """
    try:
        # Популярный формат: нанотоны в строке или числе
        n = Decimal(str(value))
        # Эвристика: большие значения считаем нанотонами
        if n > 10_000_000:  # 10 млн нанотон = 0.01 TON, порог безопасен
            return (n / Decimal("1e9")).quantize(Decimal("0.00000001"))
        # Иначе — это уже TON
        return n.quantize(Decimal("0.00000001"))
    except Exception:
        return Decimal("0")

def _norm_addr(addr: Optional[str]) -> str:
    """
    Нормализация адресов: убираем пробелы/кавычки/None, приводим к верхнему регистру
    для стабильных сравнений (визуальный формат в UI может быть иным).
    """
    s = (addr or "").strip()
    # У некоторых API встречаются поля type: "raw"/"bounceable" — тут не различаем
    return s.upper()

def _norm_memo(m: Optional[str]) -> str:
    """
    Нормализация MEMO/сообщения: приводим к безопасной строке UTF-8, обрезаем мусор.
    """
    if m is None:
        return ""
    try:
        # Иногда поле приходит как base64-строка — попытаемся понять
        if _looks_like_b64(m):
            try:
                raw = base64.b64decode(m, validate=True)
                m = raw.decode("utf-8", errors="replace")
            except Exception:
                # не критично — оставим как есть
                pass
        return (m or "").strip()
    except Exception:
        return ""

def _looks_like_b64(s: str) -> bool:
    if not s or len(s) < 8:
        return False
    try:
        base64.b64decode(s, validate=True)
        return True
    except Exception:
        return False

def _dedupe_by_hash(events: Iterable[TonAPIEvent]) -> List[TonAPIEvent]:
    seen = set()
    out: List[TonAPIEvent] = []
    for e in events:
        if e.tx_hash in seen:
            continue
        seen.add(e.tx_hash)
        out.append(e)
    return out

# -----------------------------------------------------------------------------
# Основной клиент TonAPI с fallback-логикой
# -----------------------------------------------------------------------------
class TonAPIClient:
    """
    Асинхронный клиент TON с fallback-узлами, таймаутами и унификацией ответов.
    Поддерживает минимум два семейства API: tonapi.io и "тон-центр" совместимые.
    """

    def __init__(self,
                 base_url: Optional[str] = None,
                 fallback_urls: Optional[List[str]] = None,
                 api_key: Optional[str] = None,
                 request_timeout_sec: float = 20.0) -> None:
        self._primary = base_url or getattr(settings, "TON_API_URL", "") or "https://tonapi.io"
        # fallback из .env TON_API_FALLBACK_URLS="https://toncenter.com/api/v2,https://tonapi.io/v2"
        env_fb = getattr(settings, "TON_API_FALLBACK_URLS", "")
        env_fb_list = [u.strip() for u in env_fb.split(",") if u.strip()]
        self._fallbacks = fallback_urls or env_fb_list or [
            "https://tonapi.io/v2",
            "https://toncenter.com/api/v2",
        ]
        # Гарантируем без дубликатов при сборке списка
        seq = [self._primary] + [u for u in self._fallbacks if u != self._primary]
        self._urls: List[str] = [u.rstrip("/") for u in seq]

        self._key = api_key or getattr(settings, "TON_API_KEY", None)
        self._timeout = request_timeout_sec

        # Внутренний лимитер параллелизма (защита от "DDOS" внешних API)
        self._sem = asyncio.Semaphore(3)

    # -----------------------------
    # Публичный метод: входящие платежи
    # -----------------------------
    async def get_incoming_payments(self,
                                    to_address: str,
                                    limit: int = 200,
                                    since_utime: Optional[int] = None) -> List[TonAPIEvent]:
        """
        Получить список входящих транзакций на адрес проекта:
          • to_address — адрес приёма (обязателен),
          • limit — размер страницы (по умолчанию 200),
          • since_utime — нижняя граница времени (unixtime, опционально).
        Возвращает TonAPIEvent[], отсортированный по времени убыванию (по возможности).
        """
        if not to_address:
            logger.warning("TonAPIClient: empty to_address")
            return []

        # Перебираем базовые URL до успешного ответа
        last_err: Optional[Exception] = None
        for base in self._urls:
            try:
                async with self._sem:
                    data = await self._fetch_generic(base, to_address, limit, since_utime)
                events = self._unify_events(data, to_address)
                if not events:
                    # Пусто — не считаем ошибкой, просто отдаём пустой список
                    return []
                # Сортировка по времени убыванию (utime DESC), затем по хешу
                events.sort(key=lambda e: (e.utime, e.tx_hash), reverse=True)
                # Удалим возможные дубли внутри страницы
                return _dedupe_by_hash(events)
            except Exception as e:
                last_err = e
                logger.warning("TonAPIClient: %s fetch failed (%s)", base, e)
                continue
        if last_err:
            raise last_err
        return []

    # -----------------------------
    # Частные методы — универсальный фетч и унификация
    # -----------------------------
    async def _fetch_generic(self,
                             base_url: str,
                             to_address: str,
                             limit: int,
                             since_utime: Optional[int]) -> Dict[str, Any]:
        """
        Универсальный фетч, пробует несколько известных эндпоинтов в рамках одного base_url.
        Нормализует адрес, пробует варианты маршрутов для tonapi.io / toncenter и подобных.
        """
        addr = _norm_addr(to_address)
        headers = {"Accept": "application/json"}
        if self._key:
            headers["Authorization"] = f"Bearer {self._key}"

        # Набор кандидатов эндпоинтов (в порядке приоритета).
        # Мы не можем полагаться на единственный маршрут: у провайдера версии меняются.
        candidates: List[Tuple[str, Dict[str, Any]]] = []

        # tonapi.io v2 (пример): /v2/accounts/{address}/transactions?limit=..&to_lt=.. (или от утайма)
        candidates.append((f"{base_url}/v2/accounts/{addr}/transactions", {
            "limit": str(int(limit)),
            # Упрощённо: используем since_utime как фильтр по времени, если провайдер поддерживает
            "start_date": str(int(since_utime)) if since_utime else None,
        }))

        # tonapi.io events (альтернатива): /v2/accounts/{address}/events
        candidates.append((f"{base_url}/v2/accounts/{addr}/events", {
            "limit": str(int(limit)),
            "start_date": str(int(since_utime)) if since_utime else None,
        }))

        # toncenter.com (примерно): /getTransactions?address=...&limit=...
        candidates.append((f"{base_url}/getTransactions", {
            "address": addr,
            "limit": str(int(limit)),
            # У toncenter параметры другие (lt/hash), но попробуем отфильтровать по времени на унификации
        }))

        async with httpx.AsyncClient(timeout=self._timeout, http2=True) as client:
            for url, params in candidates:
                # очищаем None из query
                q = {k: v for k, v in params.items() if v is not None}
                try:
                    r = await client.get(url, params=q, headers=headers)
                    if r.status_code >= 500:
                        # серверная ошибка — пробуем следующий маршрут или базовый URL
                        raise RuntimeError(f"upstream {url} http {r.status_code}")
                    if r.status_code == 404:
                        # у конкретного base_url нет такого маршрута — пробуем следующий маршрут
                        continue
                    r.raise_for_status()
                    return r.json()
                except (httpx.ReadTimeout, httpx.ConnectTimeout) as e:
                    logger.warning("TonAPIClient timeout: %s %s", url, e)
                    continue
                except Exception as e:
                    logger.warning("TonAPIClient route fail: %s %s", url, e)
                    continue
        # Если ничего не удалось получить — бросим исключение выше
        raise RuntimeError(f"All routes failed for base {base_url}")

    def _unify_events(self, data: Dict[str, Any], to_address: str) -> List[TonAPIEvent]:
        """
        Приводит разные структуры ответов к списку TonAPIEvent.
        Поддерживаем несколько форматов:
          • { "transactions": [ { "hash": "...", "in_msg": {...}, ... } ] }
          • { "events": [ { "transaction_id": "...", "in_msg": {...} } ] }
          • { "result": [ {... toncenter ...} ] }
        """
        addr_to = _norm_addr(to_address)
        out: List[TonAPIEvent] = []

        # --- Ветвь 1: tonapi.io { "transactions": [...] }
        if isinstance(data, dict) and isinstance(data.get("transactions"), list):
            for item in data["transactions"]:
                ev = self._mk_from_tonapi_transactions(item, addr_to)
                if ev:
                    out.append(ev)

        # --- Ветвь 2: tonapi.io { "events": [...] }
        if isinstance(data, dict) and isinstance(data.get("events"), list):
            for item in data["events"]:
                ev = self._mk_from_tonapi_events(item, addr_to)
                if ev:
                    out.append(ev)

        # --- Ветвь 3: toncenter { "result": [...] }
        if isinstance(data, dict) and isinstance(data.get("result"), list):
            for item in data["result"]:
                ev = self._mk_from_toncenter(item, addr_to)
                if ev:
                    out.append(ev)

        return out

    # -----------------------------
    # Конкретные унификаторы под разные семейства API
    # -----------------------------
    def _mk_from_tonapi_transactions(self, item: Dict[str, Any], expect_to: str) -> Optional[TonAPIEvent]:
        """
        tonapi.io /v2/accounts/{addr}/transactions — примерная модель.
        Ищем входящее сообщение на адрес проекта.
        """
        try:
            tx_hash = str(item.get("hash") or item.get("transaction_id") or "")
            if not tx_hash:
                return None

            # В некоторых схемах есть "in_msg" и "out_msgs"
            in_msg = item.get("in_msg") or item.get("in_message") or {}
            from_addr = _norm_addr(in_msg.get("source") or in_msg.get("from") or in_msg.get("src"))
            to_addr   = _norm_addr(in_msg.get("destination") or in_msg.get("to") or in_msg.get("dst") or item.get("account", ""))
            amount    = _nt_to_ton(in_msg.get("value") or in_msg.get("amount") or item.get("amount"))
            memo      = _norm_memo(in_msg.get("message") or in_msg.get("comment") or item.get("message") or "")
            utime_raw = item.get("utime") or item.get("created_at") or item.get("timestamp")
            utime     = _coerce_utime(utime_raw)

            # Фильтруем только входящие на наш адрес
            if expect_to and to_addr and expect_to != to_addr:
                return None
            if amount <= 0:
                return None

            return TonAPIEvent(
                tx_hash=tx_hash,
                from_address=from_addr,
                to_address=to_addr or expect_to,
                amount=amount,
                memo=memo,
                utime=utime,
            )
        except Exception as e:
            logger.debug("unify tonapi.transactions item failed: %s", e)
            return None

    def _mk_from_tonapi_events(self, item: Dict[str, Any], expect_to: str) -> Optional[TonAPIEvent]:
        """
        tonapi.io /v2/accounts/{addr}/events — примерная модель.
        Берём первую входящую часть, соответствующую нашему адресу.
        """
        try:
            tx_hash = str(item.get("event_id") or item.get("transaction_id") or item.get("hash") or "")
            if not tx_hash:
                return None

            in_msg = item.get("in_msg") or item.get("in_message") or {}
            if not in_msg and isinstance(item.get("actions"), list):
                # Иногда нужное поле прячется в actions
                for act in item["actions"]:
                    if not isinstance(act, dict):
                        continue
                    in_msg = act.get("in_msg") or act.get("message") or in_msg

            from_addr = _norm_addr((in_msg or {}).get("source") or (in_msg or {}).get("from") or "")
            to_addr   = _norm_addr((in_msg or {}).get("destination") or (in_msg or {}).get("to") or "")
            amount    = _nt_to_ton((in_msg or {}).get("value") or (in_msg or {}).get("amount"))
            memo      = _norm_memo((in_msg or {}).get("message") or (in_msg or {}).get("comment") or "")

            utime_raw = item.get("utime") or item.get("created_at") or item.get("timestamp")
            utime     = _coerce_utime(utime_raw)

            if expect_to and to_addr and expect_to != to_addr:
                return None
            if amount <= 0:
                return None

            return TonAPIEvent(
                tx_hash=tx_hash,
                from_address=from_addr,
                to_address=to_addr or expect_to,
                amount=amount,
                memo=memo,
                utime=utime,
            )
        except Exception as e:
            logger.debug("unify tonapi.events item failed: %s", e)
            return None

    def _mk_from_toncenter(self, item: Dict[str, Any], expect_to: str) -> Optional[TonAPIEvent]:
        """
        toncenter /getTransactions — свободная модель. Часто есть поля:
          - transaction_id.hash, in_msg.src/dst/value, utime, comment
        """
        try:
            txh = (item.get("transaction_id") or {}).get("hash") if isinstance(item.get("transaction_id"), dict) else item.get("hash")
            tx_hash = str(txh or "")
            if not tx_hash:
                return None

            in_msg = item.get("in_msg") or item.get("in_message") or {}
            from_addr = _norm_addr((in_msg or {}).get("source") or (in_msg or {}).get("src") or "")
            to_addr   = _norm_addr((in_msg or {}).get("destination") or (in_msg or {}).get("dst") or "")
            amount    = _nt_to_ton((in_msg or {}).get("value") or item.get("value"))
            memo      = _norm_memo((in_msg or {}).get("message") or item.get("comment") or "")

            utime_raw = item.get("utime") or item.get("created_at") or item.get("timestamp")
            utime     = _coerce_utime(utime_raw)

            if expect_to and to_addr and expect_to != to_addr:
                return None
            if amount <= 0:
                return None

            return TonAPIEvent(
                tx_hash=tx_hash,
                from_address=from_addr,
                to_address=to_addr or expect_to,
                amount=amount,
                memo=memo,
                utime=utime,
            )
        except Exception as e:
            logger.debug("unify toncenter item failed: %s", e)
            return None

# -----------------------------------------------------------------------------
# Дополнительные утилиты
# -----------------------------------------------------------------------------
def _coerce_utime(raw: Any) -> int:
    """
    Приведение разных представлений времени к unixtime (секунды).
    Поддержка: int/str (секунды), ISO-8601 строка, миллисекунды (эвристика).
    """
    if raw is None:
        return int(datetime.now(timezone.utc).timestamp())
    try:
        if isinstance(raw, (int, float)):
            v = int(raw)
            # Эвристика: слишком большое число — вероятно миллисекунды
            if v > 2_000_000_000_000:  # 2e12 ~ 2033 год в мс
                return int(v / 1000)
            return v
        if isinstance(raw, str):
            s = raw.strip()
            if s.isdigit():
                v = int(s)
                if v > 2_000_000_000_000:
                    return int(v / 1000)
                return v
            # ISO-8601
            try:
                dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
                return int(dt.timestamp())
            except Exception:
                pass
    except Exception:
        pass
    # fallback: текущее время
    return int(datetime.now(timezone.utc).timestamp())

# =============================================================================
# Пояснения «для чайника»:
#   • Этот модуль только читает внешние API TON и нормализует ответы в общий формат,
#     удобный для вотчера. Балансы не меняет и в БД не пишет.
#   • Устойчивость достигается fallback-списком узлов и таймаутами; если один
#     узел не ответил — берём следующий, ошибки логируем, процесс не падает.
#   • Количество монет в полях ответа разных API бывает в нанотонах — мы
#     аккуратно переводим к TON и ограничиваем точность до 8 знаков.
#   • MEMO/комментарии могут приходить в base64 — мы пытаемся декодировать, но
#     не делаем это критичным: при неудаче используем исходную строку.
#   • Удаление дублей по tx_hash делается на уровне страницы; полная идемпотентность
#     обеспечивается уже в БД через UNIQUE(tx_hash) (модуль вотчера).
# =============================================================================
