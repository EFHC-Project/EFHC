# =============================================================================
# Назначение:
#   • Единый центр генерации и парсинга MEMO для входящих платежей TON/USDT/EFHC.
#   • Закрепляет КАНОН форматов, чтобы пополнения и покупки обрабатывались автоматически.
#
# Для чайника:
#   • MEMO — это короткая «подсказка» в платеже, по которой бот однозначно понимает,
#     кто платил и за что (депозит EFHC или покупка EFHC-пакета за TON/USDT).
#   • Мы используем два строго определённых шаблона:
#       1) Депозит EFHC (прямое пополнение EFHC 1:1 с банка пользователю):
#            EFHC:<telegram_id>
#          — сумма берётся прямо из транзакции EFHC на кошелёк проекта.
#       2) Покупка EFHC-пакета (TON/USDT → EFHC), всё АВТОМАТИЧЕСКИ:
#            BUY:EFHC:<qty>:TG:<telegram_id>[:OID:<order_id>]
#          — <qty> — СКОЛЬКО EFHC надо зачислить пользователю;
#            — сумма на блокчейне должна совпасть с ценой пакета (проверяет watcher).
#
# Где используется:
#   • watcher_service.py — автоматическое зачисление:
#       - при EFHC-депозите: начисляем 1:1 с БАНКА пользователю по факту поступивших EFHC;
#       - при покупке EFHC-пакета: проверяем, что пришло ровно столько TON/USDT,
#         сколько стоит пакет <qty>, и затем зачисляем ровно <qty> EFHC с БАНКА пользователю.
#   • shop_service.py — при создании «инструкции на оплату» формируем корректный MEMO.
#   • бот — подставляет нужный MEMO пользователю (кнопка «Пополнить», карточка покупки).
#
# Важно:
#   • Все операции автоматические (кроме NFT). Если MEMO не распознан — платёж игнорируется.
#   • На депозит EFHC без MEMO мы также реагируем, если платёж пришёл С ПРИВЯЗАННОГО кошелька.
#   • Количество EFHC для покупок — строго целое число (по канону).
# =============================================================================

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Union

# -----------------------------------------------------------------------------
# Регулярные выражения КАНОНА MEMO
# -----------------------------------------------------------------------------
# 1) ДЕПОЗИТ EFHC: "EFHC:<telegram_id>"
_RE_DEPOSIT = re.compile(r"^EFHC:(?P<tgid>\d{3,20})$")

# 2) ПОКУПКА EFHC-ПАКЕТА: "BUY:EFHC:<qty>:TG:<tgid>[:OID:<order_id>]"
#    - qty: целое число, минимум 1
#    - tgid: 3..20 цифр
#    - order_id (опционально): буквы/цифры/дефис/подчёркивание, до 64 символов
_RE_BUY_PACK = re.compile(
    r"^BUY:EFHC:(?P<qty>[1-9]\d*):TG:(?P<tgid>\d{3,20})(?::OID:(?P<oid>[A-Za-z0-9\-_]{1,64}))?$"
)

# -----------------------------------------------------------------------------
# Результаты парсинга (структуры данных)
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class MemoDepositEFHC:
    """Депозит EFHC: сумма берётся из самой транзакции EFHC на проектный адрес."""
    telegram_id: int

@dataclass(frozen=True)
class MemoBuyEFHCPack:
    """Покупка EFHC-пакета за TON/USDT: количество EFHC зафиксировано в MEMO."""
    telegram_id: int
    qty_efhc: int
    order_id: Optional[str] = None


MemoParsed = Union[MemoDepositEFHC, MemoBuyEFHCPack]


# -----------------------------------------------------------------------------
# Генераторы MEMO (использует Shop/бот)
# -----------------------------------------------------------------------------
def build_deposit_memo(telegram_id: int) -> str:
    """
    Создаёт MEMO для депозита EFHC: 'EFHC:<tgid>'.
    Пример: EFHC:362746228
    """
    if telegram_id <= 0:
        raise ValueError("telegram_id должен быть положительным целым.")
    return f"EFHC:{telegram_id}"


def build_buy_pack_memo(telegram_id: int, qty_efhc: int, order_id: Optional[str] = None) -> str:
    """
    Создаёт MEMO для покупки EFHC-пакета: 'BUY:EFHC:<qty>:TG:<tgid>[:OID:<order_id>]'.
    • qty_efhc — СКОЛЬКО EFHC нужно начислить (строго целое число >= 1).
    • order_id — опционально; помогает связывать заказ в нашей БД с транзакцией.
    """
    if telegram_id <= 0:
        raise ValueError("telegram_id должен быть положительным целым.")
    if qty_efhc < 1:
        raise ValueError("qty_efhc должен быть целым числом >= 1.")
    base = f"BUY:EFHC:{qty_efhc}:TG:{telegram_id}"
    if order_id:
        return f"{base}:OID:{order_id}"
    return base


# -----------------------------------------------------------------------------
# Парсер MEMO (использует watcher_service)
# -----------------------------------------------------------------------------
def parse_memo(memo: Optional[str]) -> Optional[MemoParsed]:
    """
    Разбирает строку MEMO и возвращает структуру с данными.
    Возвращает None, если MEMO не соответствует канону.
    """
    if memo is None:
        return None

    s = memo.strip()

    # 1) депозит EFHC
    m = _RE_DEPOSIT.match(s)
    if m:
        return MemoDepositEFHC(telegram_id=int(m.group("tgid")))

    # 2) покупка EFHC-пакета
    m = _RE_BUY_PACK.match(s)
    if m:
        tgid = int(m.group("tgid"))
        qty = int(m.group("qty"))
        oid = m.group("oid")
        return MemoBuyEFHCPack(telegram_id=tgid, qty_efhc=qty, order_id=oid)

    return None


# -----------------------------------------------------------------------------
# Быстрые примеры (для разработчиков)
# -----------------------------------------------------------------------------
# build_deposit_memo(362746228)  -> "EFHC:362746228"
# parse_memo("EFHC:362746228")   -> MemoDepositEFHC(telegram_id=362746228)
#
# build_buy_pack_memo(362746228, 100)                  -> "BUY:EFHC:100:TG:362746228"
# build_buy_pack_memo(362746228, 100, "ORD-123")       -> "BUY:EFHC:100:TG:362746228:OID:ORD-123"
# parse_memo("BUY:EFHC:100:TG:362746228")              -> MemoBuyEFHCPack(telegram_id=362746228, qty_efhc=100)
# parse_memo("BUY:EFHC:250:TG:362746228:OID:ORD-123")  -> MemoBuyEFHCPack(telegram_id=362746228, qty_efhc=250, order_id="ORD-123")
