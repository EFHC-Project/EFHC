# -*- coding: utf-8 -*-
# backend/app/integrations/ads_providers.py
# =============================================================================
# EFHC Bot — Рекламные провайдеры (rewarded ads) и верификация колбэков/токенов
# -----------------------------------------------------------------------------
# Назначение:
#   • Единый реестр провайдеров рекламы (rewarded video и аналоги).
#   • Безопасная верификация событий показа (подписи, токены, анти-replay).
#   • Генерация/проверка «встроенных» токенов (builtin_timer) — псевдо-rewarded.
#
# Канон/инварианты:
#   • Никаких начислений здесь — ТОЛЬКО валидация и извлечение полей события.
#     Начисление бонусов делает tasks_service.confirm_ad_view_and_credit(...)
#     с жёсткой идемпотентностью по idempotency_key.
#   • Все суммы — Decimal с 8 знаками (округление вниз).
#   • Мягкие ошибки/сбои — не «роняют» общий цикл: вызывающий роут может повторить.
#
# ИИ-надёжность:
#   • Резервные режимы:
#       - ADS_TEST_MODE=true — при отсутствии подписи допускаем тестовую валидацию
#         (строго логируется причину).
#       - Двойная верификация хэшей (где применимо).
#   • Явные коды причин отказа (reason), чтобы планировщик мог автодогонять.
#
# Настройки (.env/.config_core):
#   ADS_ENABLED_PROVIDERS="adsgram,builtin_timer"
#   ADS_TEST_MODE=true|false
#   # Adsgram:
#   ADSGRAM_SECRET="your_hmac_secret"               # секрета для подписи колбэка
#   ADSGRAM_ALLOWED_IPS="1.2.3.4,5.6.7.8"           # (опционально) белый список IP
#   # Builtin (псевдо-rewarded, таймер/видимость):
#   ADS_BUILTIN_SECRET="very_secret"                # если не задан — используем SECRET_KEY
#   ADS_BUILTIN_MAX_DRIFT_SEC=60                    # допустимое расхождение часов при exp
#
# Публичный контракт:
#   get_verified_event(provider: str, payload: dict, headers: dict, client_ip: str|None)
#       -> VerifiedAdEvent или бросает ValueError/RuntimeError с reason.
#   issue_builtin_timer_token(user_id: int, task_code: str, reward_bonus_efhc: Decimal,
#                             ttl_sec: int = 600, nonce: str|None = None) -> str
#
# Использование в ads_routes.py:
#   evt = await get_verified_event(name, payload, headers, client_ip)
#   await confirm_ad_view_and_credit(db, user_id=evt.user_id, task_code=evt.task_code,
#         provider=evt.provider, provider_ref=evt.provider_ref,
#         reward_bonus_efhc=evt.reward_bonus_efhc, idempotency_key=evt.idempotency_key)
# =============================================================================

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import ipaddress
import json
import os
import secrets
import time
from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, List, Optional, Protocol

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.deps import d8  # единая функция округления до 8 знаков

logger = get_logger(__name__)
settings = get_settings()

# Константы/дефолты
Q8 = Decimal("0.00000001")
ADS_TEST_MODE = bool(str(getattr(settings, "ADS_TEST_MODE", "false")).lower() in ("1", "true", "yes"))
ENABLED = set(
    [x.strip() for x in str(getattr(settings, "ADS_ENABLED_PROVIDERS", "adsgram,builtin_timer")).split(",") if x.strip()]
)

# -----------------------------------------------------------------------------
# Типизированный результат верификации рекламного события
# -----------------------------------------------------------------------------

@dataclass
class VerifiedAdEvent:
    provider: str                     # "adsgram" | "builtin_timer" | ...
    provider_ref: str                 # стабильная ссылка провайдера (tx_id/req_id/nonce)
    user_id: int                      # Telegram user_id
    task_code: str                    # в EFHC task_code вида "watch_ad_*"
    reward_bonus_efhc: Decimal        # сумма бонуса (Decimal, 8 знаков)
    idempotency_key: str              # глобальный ключ идемпотентности для начисления

# -----------------------------------------------------------------------------
# Базовый интерфейс провайдера
# -----------------------------------------------------------------------------

class AdProvider(Protocol):
    name: str

    async def verify(self, payload: Dict[str, Any], headers: Dict[str, Any], client_ip: Optional[str]) -> VerifiedAdEvent:
        """Должен:
        - проверить подпись/валидность,
        - вернуть VerifiedAdEvent.
        В случае сбоя — бросить ValueError/RuntimeError с человеком читаемым reason.
        """
        ...

# -----------------------------------------------------------------------------
# Утилиты
# -----------------------------------------------------------------------------

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")

def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)

def _hmac_hex(secret: bytes, msg: bytes) -> str:
    return hmac.new(secret, msg, hashlib.sha256).hexdigest()

def _check_ip_whitelist(client_ip: Optional[str], whitelist_csv: str) -> bool:
    if not whitelist_csv:
        return True
    if not client_ip:
        return False
    try:
        ip = ipaddress.ip_address(client_ip)
        for chunk in [x.strip() for x in whitelist_csv.split(",") if x.strip()]:
            if "/" in chunk:
                net = ipaddress.ip_network(chunk, strict=False)
                if ip in net:
                    return True
            else:
                if ip == ipaddress.ip_address(chunk):
                    return True
        return False
    except Exception:
        return False

def _as_decimal8(v: Any) -> Decimal:
    return Decimal(str(v)).quantize(Q8, rounding=ROUND_DOWN)

# -----------------------------------------------------------------------------
# Провайдер: Adsgram (пример внешнего провайдера с подписью HMAC)
# Документация у провайдеров различается; здесь реализован «универсальный»
# стиль колбэка: подпись в заголовке X-Ads-Signature (hex HMAC-SHA256), тело JSON.
# Поля, которые мы ожидаем:
#   payload: {
#     "tx_id": "abc123",             # уникальный id события у провайдера (для идемпотентности)
#     "tg_user_id": 123456789,       # Telegram user id
#     "task_code": "watch_ad_adsgram_default",  # наш task_code
#     "reward": "1.0"                # (опционально) начисляемый бонус
#   }
#   headers: {
#     "X-Ads-Signature": "<hex-hmac>"
#   }
# Секрет: ADSGRAM_SECRET
# Белый список IP: ADSGRAM_ALLOWED_IPS (CSV)
# -----------------------------------------------------------------------------

class AdsgramProvider:
    name = "adsgram"

    def __init__(self) -> None:
        self.secret = (getattr(settings, "ADSGRAM_SECRET", None) or "").encode("utf-8")
        self.whitelist = getattr(settings, "ADSGRAM_ALLOWED_IPS", "") or ""

    async def verify(self, payload: Dict[str, Any], headers: Dict[str, Any], client_ip: Optional[str]) -> VerifiedAdEvent:
        if "adsgram" not in ENABLED:
            raise ValueError("provider_disabled")

        # Проверка IP (если указан белый список)
        if self.whitelist and not _check_ip_whitelist(client_ip, self.whitelist):
            raise ValueError("ip_not_allowed")

        # Подпись
        sign = (headers.get("X-Ads-Signature") or headers.get("x-ads-signature") or "").strip()
        body_bytes = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

        if not self.secret:
            if ADS_TEST_MODE:
                logger.warning("AdsgramProvider: empty secret, ADS_TEST_MODE enabled → accepting test callback")
            else:
                raise ValueError("missing_adsgram_secret")

        if self.secret and sign:
            calc = _hmac_hex(self.secret, body_bytes)
            if not hmac.compare_digest(calc, sign):
                if not ADS_TEST_MODE:
                    raise ValueError("signature_mismatch")
                logger.warning("AdsgramProvider: signature mismatch, ADS_TEST_MODE → soft accept")

        elif self.secret and not sign:
            if not ADS_TEST_MODE:
                raise ValueError("missing_signature")
            logger.warning("AdsgramProvider: no signature, ADS_TEST_MODE → soft accept")

        # Поля
        tx_id = str(payload.get("tx_id") or payload.get("event_id") or "").strip()
        if not tx_id:
            # Принимаем как тестовый/нестабильный кейс — сгенерируем ref
            tx_id = f"stub-{secrets.token_hex(8)}"
        user_id = int(payload.get("tg_user_id") or payload.get("user_id") or 0)
        if user_id <= 0:
            raise ValueError("invalid_user_id")

        task_code = str(payload.get("task_code") or "watch_ad_adsgram_default").strip()
        reward = _as_decimal8(payload.get("reward") or "0")

        idk = f"adsgram:{tx_id}"
        return VerifiedAdEvent(
            provider=self.name,
            provider_ref=tx_id,
            user_id=user_id,
            task_code=task_code,
            reward_bonus_efhc=reward,
            idempotency_key=idk,
        )

# -----------------------------------------------------------------------------
# Провайдер: builtin_timer (псевдо-rewarded без внешнего сервиса)
# Механика:
#   • Бэкенд выдаёт фронту "token" (base64url) через /ads/slot:
#       token = b64url( json({uid, task_code, reward, nonce, exp, sig}) )
#     где sig = HMAC(secret, "{uid}|{task_code}|{reward}|{nonce}|{exp}")
#   • Фронт после «просмотра» шлёт POST /ads/callback/builtin с token,
#     бэкенд верифицирует подпись, exp, идемпотентность — и завершает награду.
#
# Секрет: ADS_BUILTIN_SECRET (или SECRET_KEY)
# Допустимое расхождение часов: ADS_BUILTIN_MAX_DRIFT_SEC (по умолчанию 60)
# -----------------------------------------------------------------------------

class BuiltinTimerProvider:
    name = "builtin_timer"

    def __init__(self) -> None:
        key = getattr(settings, "ADS_BUILTIN_SECRET", None) or getattr(settings, "SECRET_KEY", None)
        if not key:
            # В тестовом режиме позволяем пустой секрет (залогируем)
            if ADS_TEST_MODE:
                logger.warning("BuiltinTimerProvider: empty secret in ADS_TEST_MODE")
                key = "test_secret"
            else:
                # Не бросаем в ctor, дадим шанс верхнему уровню обрабатывать reason
                key = "!!unset!!"
        self.secret = key.encode("utf-8")
        self.max_drift = int(getattr(settings, "ADS_BUILTIN_MAX_DRIFT_SEC", 60) or 60)

    @staticmethod
    def _build_sig(uid: int, task_code: str, reward: Decimal, nonce: str, exp: int, secret: bytes) -> str:
        msg = f"{uid}|{task_code}|{reward}|{nonce}|{exp}".encode("utf-8")
        return _hmac_hex(secret, msg)

    @staticmethod
    def _encode_token(d: Dict[str, Any]) -> str:
        return _b64url(json.dumps(d, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))

    @staticmethod
    def _decode_token(token: str) -> Dict[str, Any]:
        return json.loads(_b64url_decode(token).decode("utf-8"))

    async def verify(self, payload: Dict[str, Any], headers: Dict[str, Any], client_ip: Optional[str]) -> VerifiedAdEvent:
        if "builtin_timer" not in ENABLED:
            raise ValueError("provider_disabled")

        # token приходит в теле
        token = (payload.get("token") or "").strip()
        if not token:
            raise ValueError("missing_token")

        try:
            data = self._decode_token(token)
        except Exception:
            raise ValueError("bad_token_format")

        uid = int(data.get("uid") or 0)
        task_code = str(data.get("task_code") or "").strip()
        reward = _as_decimal8(data.get("reward") or "0")
        nonce = str(data.get("nonce") or "").strip()
        exp = int(data.get("exp") or 0)
        sig = str(data.get("sig") or "").strip()

        if uid <= 0 or not task_code or not nonce or exp <= 0:
            raise ValueError("bad_token_fields")

        # Секрет
        if self.secret == b"!!unset!!":
            if not ADS_TEST_MODE:
                raise ValueError("builtin_secret_unset")
            logger.warning("BuiltinTimerProvider: unset secret, ADS_TEST_MODE → accepting test token")

        # Проверка срока действия
        now = int(time.time())
        if now > exp + self.max_drift:
            raise ValueError("token_expired")

        # Подпись
        calc = self._build_sig(uid, task_code, reward, nonce, exp, self.secret)
        if not hmac.compare_digest(calc, sig):
            if not ADS_TEST_MODE:
                raise ValueError("token_signature_mismatch")
            logger.warning("BuiltinTimerProvider: signature mismatch, ADS_TEST_MODE → soft accept")

        idk = f"builtin:{nonce}"
        return VerifiedAdEvent(
            provider=self.name,
            provider_ref=nonce,
            user_id=uid,
            task_code=task_code,
            reward_bonus_efhc=reward,
            idempotency_key=idk,
        )

    # Публичный помощник для выдачи токена фронту
    def issue_token(self, *, user_id: int, task_code: str, reward_bonus_efhc: Decimal, ttl_sec: int = 600, nonce: Optional[str] = None) -> str:
        if not nonce:
            nonce = secrets.token_urlsafe(16)
        exp = int(time.time()) + int(ttl_sec)
        reward_q = _as_decimal8(reward_bonus_efhc)
        sig = self._build_sig(user_id, task_code, reward_q, nonce, exp, self.secret)
        blob = {
            "uid": user_id,
            "task_code": task_code,
            "reward": str(reward_q),
            "nonce": nonce,
            "exp": exp,
            "sig": sig,
        }
        return self._encode_token(blob)

# -----------------------------------------------------------------------------
# Реестр провайдеров и фасадные функции
# -----------------------------------------------------------------------------

_PROVIDERS: Dict[str, AdProvider] = {
    "adsgram": AdsgramProvider(),
    "builtin_timer": BuiltinTimerProvider(),
}

def get_provider(name: str) -> AdProvider:
    p = _PROVIDERS.get(name)
    if not p:
        raise ValueError("unknown_provider")
    return p

async def get_verified_event(
    provider: str,
    payload: Dict[str, Any],
    headers: Dict[str, Any],
    client_ip: Optional[str] = None,
) -> VerifiedAdEvent:
    """
    Унифицированная точка входа: верифицирует событие показа и возвращает VerifiedAdEvent.
    В случае проблем — бросает ValueError с reason (короткий код), чтобы роут мог
    вернуть 400/403/422; либо RuntimeError для 500 (неожиданный сбой).
    """
    provider = (provider or "").strip().lower()
    try:
        p = get_provider(provider)
        evt = await p.verify(payload, headers, client_ip)
        # Нормализуем сумму/ключ
        evt.reward_bonus_efhc = evt.reward_bonus_efhc.quantize(Q8, rounding=ROUND_DOWN)
        evt.idempotency_key = str(evt.idempotency_key).strip()
        if not evt.idempotency_key:
            # На случай «битого» колбэка — сделаем воспроизводимый ключ
            evt.idempotency_key = f"{evt.provider}:{evt.provider_ref}:{evt.user_id}:{evt.task_code}"
        return evt
    except ValueError as e:
        logger.info("ads.verify rejected provider=%s reason=%s", provider, str(e))
        raise
    except Exception as e:
        logger.error("ads.verify failed provider=%s err=%s", provider, e)
        raise RuntimeError("internal_error") from e

# -----------------------------------------------------------------------------
# Хелпер для выдачи токена builtin_timer фронту (например, в /ads/slot)
# -----------------------------------------------------------------------------

def issue_builtin_timer_token(
    *,
    user_id: int,
    task_code: str,
    reward_bonus_efhc: Decimal,
    ttl_sec: int = 600,
    nonce: Optional[str] = None,
) -> str:
    """
    Выдаёт безопасный токен для «встроенного» таймер-провайдера.
    Используется в маршруте /ads/slot (который выдаёт фронту placement).
    """
    p: BuiltinTimerProvider = _PROVIDERS["builtin_timer"]  # type: ignore
    return p.issue_token(user_id=user_id, task_code=task_code, reward_bonus_efhc=reward_bonus_efhc, ttl_sec=ttl_sec, nonce=nonce)
