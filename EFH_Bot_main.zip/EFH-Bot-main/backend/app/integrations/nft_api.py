# -*- coding: utf-8 -*-
# backend/app/integrations/nft_api.py
# =============================================================================
# EFHC Bot — интеграция с NFT (TON): проверка наличия NFT в коллекции
# -----------------------------------------------------------------------------
# Что даёт модуль:
#   • Унифицированные функции:
#       wallet_has_nft_in_collection(wallet, collection) -> bool
#       fetch_wallet_nfts_in_collection(wallet, collection, limit=100) -> List[NFTItem]
#       batch_wallets_has_nft_in_collection(wallets, collection) -> Dict[wallet,bool]
#   • Провайдеры и fallback:
#       1) TonAPI (https://tonapi.io/v2) — основной
#       2) Getgems API (https://api.getgems.io) — резервный
#   • ИИ-устойчивость:
#       — асинхронные HTTP-вызовы с таймаутами
#       — экспоненциальные ретраи с джиттером
#       — мягкая нормализация разных структур ответов
#
# Важно:
#   • Этот модуль только ЧИТАЕТ внешние API. Никакой бизнес-логики тут нет.
#   • Вся бизнес-логика VIP/статусов — в services/nft_requests_service.py.
#   • Адрес/коллекция сравниваются как строки без пробелов (нормализуем).
# =============================================================================

from __future__ import annotations

import asyncio
import json
import os
import random
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

try:
    import httpx  # асинхронный HTTP-клиент
except Exception:  # pragma: no cover
    httpx = None  # защитим импорт, чтобы не падать при стат. анализе

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

logger = get_logger(__name__)
settings = get_settings()

# ------------------------------ Конфигурация ---------------------------------

TON_API_URL: str = getattr(settings, "TON_API_URL", "") or "https://tonapi.io/v2"
TON_API_KEY: str = getattr(settings, "TON_API_KEY", "") or os.environ.get("TON_API_KEY", "")

GETGEMS_API_URL: str = getattr(settings, "GETGEMS_API_URL", "") or "https://api.getgems.io"

NETWORK_TIMEOUT_SEC: float = float(getattr(settings, "NETWORK_TIMEOUT_SEC", 20) or 20)

# Для удобства: если в конфиге заранее задана коллекция, её можно подставлять
DEFAULT_NFT_COLLECTION: Optional[str] = getattr(settings, "TON_NFT_COLLECTION", None) \
    or getattr(settings, "GETGEMS_COLLECTION", None)


# ------------------------------ Модель ответа --------------------------------

@dataclass
class NFTItem:
    """Унифицированное описание NFT, используем только необходимые поля."""
    address: str         # адрес NFT
    collection: str      # адрес коллекции
    owner: Optional[str] # текущий владелец (если доступно)
    metadata: Dict[str, Any]  # любые поля (name, attributes и т.д.)


# --------------------------- Утилиты и backoff --------------------------------

def _norm_addr(addr: Optional[str]) -> str:
    """Простая нормализация адреса: обрежем пробелы, без конвертации форматов."""
    if not addr:
        return ""
    return addr.strip()

async def _with_backoff(coro_factory, *, tries: int = 3, base: float = 0.4, factor: float = 2.0, max_sleep: float = 5.0):
    """
    Выполняет coro_factory() с экспоненциальным бэкоффом и джиттером.
    coro_factory — функция без аргументов, возвращающая coroutine.
    """
    attempt = 0
    while True:
        try:
            return await coro_factory()
        except Exception as e:
            attempt += 1
            if attempt >= tries:
                raise
            delay = min(max_sleep, base * (factor ** (attempt - 1)))
            delay = delay * (0.7 + random.random() * 0.6)  # ±30% джиттер
            logger.warning("nft integration: attempt %s failed: %s; sleep %.2fs", attempt, e, delay)
            await asyncio.sleep(delay)

async def _http_get_json(base_url: str, path: str, *, headers: Dict[str, str], params: Dict[str, Any]) -> Dict[str, Any]:
    """Безопасный GET JSON с таймаутом. Возвращаем dict (может быть пустым)."""
    if httpx is None:  # pragma: no cover
        raise RuntimeError("httpx is required for network calls")
    url = f"{base_url.rstrip('/')}{path}"
    timeout = httpx.Timeout(NETWORK_TIMEOUT_SEC, read=NETWORK_TIMEOUT_SEC)
    async with httpx.AsyncClient(timeout=timeout, headers=headers) as client:
        r = await client.get(url, params=params, follow_redirects=True)
        r.raise_for_status()
        try:
            return r.json()
        except Exception:
            return json.loads(r.text or "{}")


# ------------------------------ TonAPI (primary) ------------------------------

def _tonapi_headers() -> Dict[str, str]:
    h = {"Accept": "application/json"}
    if TON_API_KEY:
        h["Authorization"] = f"Bearer {TON_API_KEY}"
    return h

async def _tonapi_list_wallet_nfts(wallet: str, *, limit: int = 200) -> List[Dict[str, Any]]:
    """
    TonAPI: список NFT кошелька.
    Варианты путей (по состоянию API): /nft/items?owner=<addr>
                                      или /accounts/{addr}/nfts
    Попробуем наиболее распространённый: /blockchain/accounts/{addr}/nfts
    """
    path = f"/blockchain/accounts/{wallet}/nfts"
    params = {"limit": int(max(1, min(limit, 1000)))}
    data = await _with_backoff(lambda: _http_get_json(TON_API_URL, path, headers=_tonapi_headers(), params=params))
    items = data.get("nft_items") or data.get("items") or data.get("nfts") or []
    if not isinstance(items, list):
        items = []
    return items

def _tonapi_normalize_items(raw_items: List[Dict[str, Any]]) -> List[NFTItem]:
    """Нормализуем TonAPI объекты к NFTItem."""
    out: List[NFTItem] = []
    for it in raw_items:
        addr = _norm_addr(it.get("address") or it.get("nft_item_address") or it.get("id"))
        coll = _norm_addr(it.get("collection_address") or (it.get("collection") or {}).get("address"))
        ownr = _norm_addr(it.get("owner") or (it.get("owner") or {}).get("address"))
        meta = it.get("metadata") or it.get("content") or {}
        out.append(NFTItem(address=addr, collection=coll, owner=ownr, metadata=meta if isinstance(meta, dict) else {}))
    return out


# ------------------------------ Getgems (fallback) ----------------------------

def _getgems_headers() -> Dict[str, str]:
    return {"Accept": "application/json"}

async def _getgems_list_wallet_nfts(wallet: str, *, limit: int = 200) -> List[Dict[str, Any]]:
    """
    Getgems API: список NFT кошелька.
    Часто встречается путь вида: /nft/account/{addr}?limit=...
    """
    path = f"/nft/account/{wallet}"
    params = {"limit": int(max(1, min(limit, 1000)))}
    data = await _with_backoff(lambda: _http_get_json(GETGEMS_API_URL, path, headers=_getgems_headers(), params=params))
    items = data.get("nft_items") or data.get("items") or data.get("nfts") or data.get("result") or []
    if not isinstance(items, list):
        items = []
    return items

def _getgems_normalize_items(raw_items: List[Dict[str, Any]]) -> List[NFTItem]:
    """Нормализуем Getgems объекты к NFTItem."""
    out: List[NFTItem] = []
    for it in raw_items:
        addr = _norm_addr(it.get("address") or it.get("nft_address") or it.get("id"))
        coll = _norm_addr(it.get("collection") or it.get("collection_address"))
        ownr = _norm_addr(it.get("owner") or (it.get("owner") or {}).get("address"))
        meta = it.get("metadata") or it.get("meta") or {}
        out.append(NFTItem(address=addr, collection=coll, owner=ownr, metadata=meta if isinstance(meta, dict) else {}))
    return out


# ------------------------------- Агрегатор ------------------------------------

async def fetch_wallet_nfts_in_collection(wallet: str, collection: Optional[str], *, limit: int = 200) -> List[NFTItem]:
    """
    Вернуть список NFT пользователя, ОТФИЛЬТРОВАННЫХ по коллекции (если задана).
    Алгоритм:
      1) TonAPI: /blockchain/accounts/{wallet}/nfts → normalize → filter
      2) Если TonAPI упал/дал «слишком мало», пробуем Getgems → normalize → filter
      3) Объединяем, дедуп по адресу NFT
    """
    wallet = _norm_addr(wallet)
    collection = _norm_addr(collection or DEFAULT_NFT_COLLECTION)

    items_all: List[NFTItem] = []

    # Primary: TonAPI
    try:
        raw = await _tonapi_list_wallet_nfts(wallet, limit=limit)
        items = _tonapi_normalize_items(raw)
        if collection:
            items = [it for it in items if _norm_addr(it.collection) == collection]
        items_all.extend(items)
    except Exception as e:
        logger.warning("nft tonapi wallet_nfts failed: %s", e)

    # Fallback: Getgems — если TonAPI ничего не дал
    need_fallback = len(items_all) < 1
    if need_fallback:
        try:
            raw2 = await _getgems_list_wallet_nfts(wallet, limit=limit)
            items2 = _getgems_normalize_items(raw2)
            if collection:
                items2 = [it for it in items2 if _norm_addr(it.collection) == collection]
            items_all.extend(items2)
        except Exception as e:
            logger.warning("nft getgems wallet_nfts failed: %s", e)

    # Дедуп по адресу NFT
    dedup: Dict[str, NFTItem] = {}
    for it in items_all:
        if it.address:
            dedup[it.address] = it
    result = list(dedup.values())
    logger.info("nft integration: wallet=%s, collection=%s -> %s item(s)", wallet, collection or "-", len(result))
    return result


async def wallet_has_nft_in_collection(wallet: str, collection: Optional[str] = None) -> bool:
    """
    True, если у кошелька есть хотя бы один NFT из коллекции.
    """
    items = await fetch_wallet_nfts_in_collection(wallet, collection, limit=200)
    return len(items) > 0


async def batch_wallets_has_nft_in_collection(wallets: List[str], collection: Optional[str] = None) -> Dict[str, bool]:
    """
    Пакетная проверка нескольких кошельков.
    Выполняется последовательно (чтобы не DDoS-ить API). При необходимости можно
    оптимизировать на батчи с контролем параллелизма.
    """
    out: Dict[str, bool] = {}
    for w in wallets:
        try:
            out[_norm_addr(w)] = await wallet_has_nft_in_collection(w, collection)
        except Exception as e:
            logger.warning("nft batch check failed for %s: %s", w, e)
            out[_norm_addr(w)] = False
    return out
