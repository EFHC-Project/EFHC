# backend/app/__init__.py
# =======================
# Главный модуль инициализации серверной части EFHC Bot.
# Здесь создаётся приложение FastAPI, подключаются роутеры,
# включаются middleware (CORS/GZip/TrustedHosts), настраивается логирование
# и события жизненного цикла (startup/shutdown).

from __future__ import annotations

import logging
from contextlib import AsyncExitStack
from typing import AsyncIterator, Iterable, Optional

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.types import Lifespan

# Настройки проекта (Pydantic BaseSettings)
# Объект settings предоставляет доступ к переменным окружения (.env)
try:
    from .core.config_core import get_settings
except Exception as exc:  # защитный импорт, чтобы падать с понятной ошибкой
    raise RuntimeError("Не удалось импортировать настройки из core/config_core.py") from exc

# Логирование (единый формат и уровни)
try:
    from .core.logging_core import configure_logging
except Exception as exc:
    raise RuntimeError("Не удалось импортировать конфигурацию логирования (core/logging_core.py).") from exc

# Маршруты API (внутри пакета routes должен быть собранный api_router)
try:
    from .routes import api_router  # type: ignore
except Exception as exc:
    raise RuntimeError("Не удалось импортировать api_router из app.routes. Проверьте пакет routes/.") from exc

# Зависимости для health/ping БД
try:
    from .deps import db_ping  # optional reuse в /healthz
except Exception:
    db_ping = None  # если deps пока не готов, маршрут /healthz будет без проверки БД


# ----------------------------
# Вспомогательные функции
# ----------------------------

def _build_description() -> str:
    """
    Текстовое описание API для Swagger UI/Redoc.
    """
    return (
        "EFHC Bot API — серверная часть экосистемы EFHC:\n\n"
        "- Панели, баланс, обмен kWh→EFHC (1:1)\n"
        "- Магазин: покупки за TON/USDT/EFHC, заявки на VIP NFT\n"
        "- Реферальная система и лотерея\n"
        "- Админ-панель (банк EFHC, товары, заказы, ставки генерации)\n"
    )


def _install_middlewares(app: FastAPI, origins: Iterable[str], trusted_hosts: Iterable[str], gzip_min_size: int) -> None:
    """
    Подключение middleware: CORS, GZip, TrustedHosts.
    """
    # CORS — разрешённые источники фронтенда (например, WebApp/React)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(origins),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["Content-Disposition"],
        max_age=600,
    )

    # Сжатие ответов для экономии трафика
    app.add_middleware(GZipMiddleware, minimum_size=gzip_min_size)

    # Ограничение доверенных хостов (защита от Host-header атак)
    # Если список пуст — не подключаем (разрешаем любые хосты, например, в dev)
    hosts = [h for h in trusted_hosts if h.strip()]
    if hosts:
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)


def _install_exception_handlers(app: FastAPI) -> None:
    """
    Унифицированные обработчики ошибок для аккуратного JSON-ответа.
    """

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content={
                "ok": False,
                "error": "validation_error",
                "details": exc.errors(),
            },
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(_: Request, exc: Exception) -> JSONResponse:
        logging.getLogger("efhc").exception("Unhandled error", exc_info=exc)
        return JSONResponse(
            status_code=500,
            content={"ok": False, "error": "internal_error"},
        )


def _lifespan() -> Lifespan[FastAPI]:
    """
    Жизненный цикл приложения (startup/shutdown) с AsyncExitStack.
    Можно использовать для запуска вотчеров/планировщиков.
    """
    async def _inner(app: FastAPI) -> AsyncIterator[None]:
        stack = AsyncExitStack()
        await stack.__aenter__()
        try:
            # Пример инициализации планировщика/вотчера:
            # try:
            #     from .services.scheduler_service import start_scheduler, stop_scheduler
            #     await start_scheduler(app)
            #     app.state._stop_scheduler = stop_scheduler
            # except Exception as exc:
            #     app.logger.warning("Scheduler not started: %s", exc)

            yield
        finally:
            # Остановка планировщика/вотчеров (если включали выше)
            # stop = getattr(app.state, "_stop_scheduler", None)
            # if stop:
            #     try:
            #         await stop(app)
            #     except Exception:  # аккуратное завершение
            #         pass
            await stack.aclose()

    return _inner


def _install_basic_routes(app: FastAPI) -> None:
    """
    Базовые служебные маршруты для быстрой диагностики.
    """
    @app.get("/", tags=["public"])
    async def root() -> dict:
        return {"ok": True, "service": app.title, "version": app.version}

    @app.get("/healthz", tags=["public"])
    async def healthz() -> dict:
        if db_ping:
            try:
                # db_ping — dependency-функция, здесь вызываем её напрямую без Depends
                # так как это простой SELECT 1
                from .db import AsyncSessionFactory  # локальный импорт чтобы не тянуть при импорте модуля
                async with AsyncSessionFactory() as session:  # type: ignore[reportUnknownMemberType]
                    result = await db_ping(session)  # type: ignore[misc]
                return {"ok": True, "db": result.get("db", "unknown")}
            except Exception:
                return {"ok": False, "db": "fail"}
        return {"ok": True}


# ----------------------------
# Создание приложения
# ----------------------------

def create_app() -> FastAPI:
    """
    Фабричная функция создания FastAPI-приложения.
    """
    settings = get_settings()

    # Логирование настраиваем как можно раньше
    configure_logging(level=settings.LOG_LEVEL)

    # Формируем приложение с учётом настроек (док-эндпоинты можно отключать из .env)
    app = FastAPI(
        title="EFHC Bot API",
        description=_build_description(),
        version=settings.APP_VERSION,
        openapi_url=settings.OPENAPI_URL,
        docs_url=settings.DOCS_URL,
        redoc_url=settings.REDOC_URL,
        lifespan=_lifespan(),
    )

    # Подключение middleware
    _install_middlewares(
        app=app,
        origins=settings.CORS_ORIGINS,
        trusted_hosts=settings.TRUSTED_HOSTS,
        gzip_min_size=settings.GZIP_MIN_BYTES,
    )

    # Обработчики исключений
    _install_exception_handlers(app)

    # Служебные маршруты (root/healthz)
    _install_basic_routes(app)

    # Подключение основного API-роутера
    app.include_router(api_router, prefix=settings.API_PREFIX)

    # Пример сохранения настроек и логгера в app.state для дальнейшего использования
    app.state.settings = settings
    app.state.logger = logging.getLogger("efhc")

    return app


# Экземпляр приложения, который будет использовать ASGI-сервер (uvicorn/gunicorn)
app: FastAPI = create_app()
