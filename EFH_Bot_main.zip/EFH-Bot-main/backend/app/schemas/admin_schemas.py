# -*- coding: utf-8 -*-
# backend/app/schemas/admin_schemas.py
# =============================================================================
# Назначение кода:
# Pydantic-схемы админского API EFHC Bot: эмиссия/сжигание через Банк,
# «насильные» движения между пользователем и Банком (строго через банк-сервис),
# реконсиляция TON-входящих, отчётность, управление витринами Shop/Tasks/Lottery,
# модерация заявок на вывод EFHC и заявок на NFT.
#
# Канон / инварианты:
# • Все денежные операции — только через единый банковский сервис (transactions_service).
# • Денежные POST обязаны требовать Idempotency-Key (проверяется в роутере).
# • Банк может уходить в минус (это допустимо); пользователи — НЕТ (жёсткий запрет).
# • Внутренний курс фиксированный: 1 EFHC = 1 кВт·ч; обратной конверсии нет.
# • NFT — только по заявке (ручная выдача админом); автодоставки NFT нет.
#
# ИИ-защиты:
# • Все суммы нормализуем как строки с 8 знаками (ROUND_DOWN), единый формат для фронта.
# • В админских входных моделях предусмотрены поля audit/meta для трассировки.
# • Для тяжёлых операций (реконсиляция TON) — dry_run и лимиты, чтобы не «ронять» процесс.
#
# Запреты:
# • Нет прямого редактирования балансов пользователей — только через банк-операции.
# • Нет P2P-переводов user→user.
# • Нет «суточных» ставок; бизнес-логика не живёт в схемах (только форма данных).
# =============================================================================

from __future__ import annotations

# =============================================================================
# Импорты
# -----------------------------------------------------------------------------
from datetime import datetime
from typing import Any, Literal, Optional, List

from pydantic import BaseModel, Field, validator

from backend.app.schemas.common_schemas import (
    d8_str,
    OkMeta,
    CursorPage,
    BalancePair,
    IdempotencyContract,
)

# =============================================================================
# Базовые вспомогательные DTO (админ-трассировка)
# -----------------------------------------------------------------------------
class AdminActor(BaseModel):
    """Кто инициировал действие (для аудита и UI-протоколирования)."""
    admin_telegram_id: int = Field(..., description="Telegram ID администратора")
    comment: Optional[str] = Field(None, description="Короткая пометка/причина действия")


# =============================================================================
# Блок: Эмиссия и «сжигание» EFHC (только через Банк)
# -----------------------------------------------------------------------------
class AdminEmitIn(IdempotencyContract):
    """
    Вход эмиссии EFHC в Банк.
    Денежная операция — требуется заголовок Idempotency-Key.
    """
    amount: str = Field(..., description="Сумма EFHC строкой с 8 знаками")
    actor: AdminActor

    @validator("amount", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class AdminEmitOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    emitted: str = Field(..., description="Сколько эмитировано (str, 8)")
    bank_balance_after: str = Field(..., description="Итоговый баланс Банка (str, 8)")
    note: Optional[str] = Field(None, description="Примечание (например, 'manual_emission')")


class AdminBurnIn(IdempotencyContract):
    """
    Вход «сжигания» EFHC из Банка (уменьшает баланс банка).
    Денежная операция — требует Idempotency-Key.
    """
    amount: str = Field(..., description="Сумма EFHC строкой с 8 знаками")
    actor: AdminActor

    @validator("amount", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class AdminBurnOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    burned: str = Field(..., description="Сколько сожжено (str, 8)")
    bank_balance_after: str = Field(..., description="Итоговый баланс Банка (str, 8)")
    note: Optional[str] = Field(None, description="Примечание (например, 'manual_burn')")


# =============================================================================
# Блок: «Насильные» операции Банк ↔ Пользователь (через банк-сервис)
# -----------------------------------------------------------------------------
class AdminForceDebitUserToBankIn(IdempotencyContract):
    """
    Принудительное списание EFHC с пользователя в пользу Банка.
    • Пользователь НЕ может уйти в минус — операция должна быть отклонена сервисом.
    • Списание: сначала bonus, затем main (реализует сервис).
    """
    user_id: int = Field(..., description="ID пользователя (внутренний)")
    amount: str = Field(..., description="Сумма EFHC строкой с 8 знаками")
    reason: str = Field(..., description="Причина списания (для аудита)")
    actor: AdminActor

    @validator("amount", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class AdminForceDebitUserToBankOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    debited: str = Field(..., description="Фактически списано (str, 8)")
    user_balances_after: BalancePair = Field(..., description="Баланс пользователя после операции")
    bank_balance_after: str = Field(..., description="Баланс Банка после операции (str, 8)")
    note: Optional[str] = Field(None, description="Примечание (например, 'force_debit')")


class AdminForceCreditUserFromBankIn(IdempotencyContract):
    """
    Принудительное начисление EFHC пользователю из Банка.
    • Банк может уйти в минус — это допустимо.
    """
    user_id: int = Field(..., description="ID пользователя (внутренний)")
    amount: str = Field(..., description="Сумма EFHC строкой с 8 знаками")
    reason: str = Field(..., description="Причина начисления (для аудита)")
    actor: AdminActor

    @validator("amount", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class AdminForceCreditUserFromBankOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    credited: str = Field(..., description="Фактически начислено (str, 8)")
    user_balances_after: BalancePair = Field(..., description="Баланс пользователя после операции")
    bank_balance_after: str = Field(..., description="Баланс Банка после операции (str, 8)")
    note: Optional[str] = Field(None, description="Примечание (например, 'force_credit')")


# =============================================================================
# Блок: Реконсиляция TON-входящих (по диапазону)
# -----------------------------------------------------------------------------
class AdminTonReconcileIn(BaseModel):
    """
    Параметры административной реконсиляции входящих TON-транзакций.
    • Можно указывать диапазон по unixtime (utime_from/utime_to) и лимит.
    • dry_run=True — только посмотреть, что будет обработано (без движений денег).
    """
    utime_from: Optional[int] = Field(None, description="С какого unixtime включительно")
    utime_to: Optional[int] = Field(None, description="По какой unixtime включительно")
    limit: int = Field(1000, gt=0, le=10000, description="Максимум событий за прогон")
    dry_run: bool = Field(True, description="Только анализ без записей/движений")
    actor: AdminActor


class AdminTonReconcileOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    scanned: int = Field(..., description="Сколько событий просмотрено")
    created_orders: int = Field(..., description="Сколько создано/помечено заказов (Shop)")
    credited_users: int = Field(..., description="Сколько пользователей получило EFHC")
    duplicates_skipped: int = Field(..., description="Сколько дублей пропущено по tx_hash")
    errors: int = Field(..., description="Сколько ошибок за прогон")
    last_seen_utime: Optional[int] = Field(None, description="Последний utime в прогоне")
    note: Optional[str] = Field(None, description="Примечание (например, 'dry_run')")


# =============================================================================
# Блок: Отчётность/наблюдаемость
# -----------------------------------------------------------------------------
class AdminReportsQueryIn(BaseModel):
    """
    Запрос агрегированной статистики для админ-панели.
    """
    period_from: Optional[datetime] = Field(None, description="Начало периода (UTC)")
    period_to: Optional[datetime] = Field(None, description="Конец периода (UTC)")
    include_latency: bool = Field(True, description="Собирать ли лаги догонов/вотчера")
    include_deficit: bool = Field(True, description="Считать долю операций в дефиците банка")


class AdminReportsOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)

    # Денежные агрегаты
    efhc_emitted_total: str = Field(..., description="Эмиссия EFHC за период (str, 8)")
    efhc_burned_total: str = Field(..., description="Сжигание EFHC за период (str, 8)")
    ton_incoming_count: int = Field(..., description="Количество входящих TON (логов)")
    efhc_credited_users: int = Field(..., description="Сколько пользователей получили EFHC")
    bank_balance_now: str = Field(..., description="Текущий баланс Банка (str, 8)")

    # Качество обработки / устойчивость
    retries_total: int = Field(..., description="Всего ретраев (вотчер/планировщик)")
    processed_with_deficit_ratio: str = Field(..., description="Доля операций при дефиците (строкой, 8 знаков)")
    avg_backfill_lag_sec: Optional[int] = Field(None, description="Средний лаг догонов энергии (сек)")
    last_scheduler_fail_streak: int = Field(..., description="Текущая длина серии неудач задач (макс. по задачам)")


# =============================================================================
# Блок: Управление Shop (витрина и позиции)
# -----------------------------------------------------------------------------
ShopItemType = Literal["EFHC_PACKAGE", "NFT_VIP", "GOOD"]

class AdminShopItemUpsertIn(BaseModel):
    """
    Создание/обновление позиции в магазине.
    • EFHC_PACKAGE — упаковка EFHC (автодоставка по оплате TON через вотчер).
    • NFT_VIP — только заявка; выдача вручную (APPROVE/REJECT в админке).
    • GOOD — прочие виртуальные товары (начисление EFHC/бонусов по правилам сервиса).
    """
    item_id: Optional[int] = Field(None, description="ID позиции (None — создать)")
    item_type: ShopItemType = Field(..., description="Тип позиции")
    title: str = Field(..., max_length=120, description="Название витринное")
    description: Optional[str] = Field(None, max_length=1000, description="Описание товара")
    price_ton: Optional[str] = Field(None, description="Цена в TON (строкой, если применимо)")
    efhc_quantity: Optional[str] = Field(None, description="Сколько EFHC выдаём (для EFHC_PACKAGE)")
    is_active: bool = Field(True, description="Показывать ли позицию в витрине")

    @validator("price_ton", "efhc_quantity", pre=True)
    def _q8(cls, v: Any) -> Optional[str]:
        if v is None:
            return None
        return d8_str(v)


class AdminShopItemOut(BaseModel):
    item_id: int
    item_type: ShopItemType
    title: str
    description: Optional[str]
    price_ton: Optional[str]
    efhc_quantity: Optional[str]
    is_active: bool
    meta: OkMeta = Field(default_factory=OkMeta)


# =============================================================================
# Блок: Управление Заданиями (Tasks) — рекламные активности
# -----------------------------------------------------------------------------
TaskType = Literal["JOIN_CHANNEL", "WATCH_AD", "CUSTOM"]

class AdminTaskUpsertIn(BaseModel):
    """
    Создание/обновление задания.
    • JOIN_CHANNEL — проверка подписки на канал/чат.
    • WATCH_AD — просмотр рекламы (через подключаемый провайдер/валидатор).
    • CUSTOM — произвольная проверка (ручной оффер/партнёрки).
    Вознаграждение — БОНУС-EFHC, тратится первым и невыплатно.
    """
    task_id: Optional[int] = Field(None, description="ID задания (None — создать)")
    task_type: TaskType = Field(..., description="Тип задания")
    title: str = Field(..., max_length=140, description="Заголовок")
    description: Optional[str] = Field(None, max_length=2000, description="Описание")
    reward_bonus_efhc: str = Field(..., description="Вознаграждение бонусами EFHC (строкой, 8 знаков)")

    # Поля для JOIN_CHANNEL
    channel_username: Optional[str] = Field(None, description="@username канала/чата (для JOIN_CHANNEL)")

    # Поля для WATCH_AD
    ad_url: Optional[str] = Field(None, description="URL рекламы/ролика (для WATCH_AD)")
    min_watch_seconds: Optional[int] = Field(None, ge=0, le=3600, description="Минимум секунд просмотра")

    # Общие флаги
    is_active: bool = Field(True, description="Доступность задания в витрине")
    daily_cap: Optional[int] = Field(None, ge=1, le=100000, description="Дневной лимит завершений")

    @validator("reward_bonus_efhc", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class AdminTaskOut(BaseModel):
    task_id: int
    task_type: TaskType
    title: str
    description: Optional[str]
    reward_bonus_efhc: str
    channel_username: Optional[str]
    ad_url: Optional[str]
    min_watch_seconds: Optional[int]
    is_active: bool
    daily_cap: Optional[int]
    meta: OkMeta = Field(default_factory=OkMeta)


# =============================================================================
# Блок: Лотереи (создание/завершение, базовые поля)
# -----------------------------------------------------------------------------
class AdminLotteryUpsertIn(BaseModel):
    """
    Создание/обновление лотереи.
    • ticket_price_efhc — цена билета в EFHC (денежная операция при покупке).
    • max_tickets_per_user — лимит на пользователя.
    • starts_at / ends_at — окна активности.
    """
    lottery_id: Optional[int] = Field(None, description="ID лотереи (None — создать)")
    title: str = Field(..., max_length=140, description="Заголовок лотереи")
    description: Optional[str] = Field(None, max_length=2000, description="Описание")
    ticket_price_efhc: str = Field(..., description="Цена билета (str, 8)")
    max_tickets_per_user: int = Field(..., ge=1, le=1000, description="Лимит билетов на пользователя")
    starts_at: Optional[datetime] = Field(None, description="Начало (UTC)")
    ends_at: Optional[datetime] = Field(None, description="Окончание (UTC)")
    is_active: bool = Field(True, description="Лотерея активна? (показывать в витрине)")

    @validator("ticket_price_efhc", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class AdminLotteryOut(BaseModel):
    lottery_id: int
    title: str
    description: Optional[str]
    ticket_price_efhc: str
    max_tickets_per_user: int
    starts_at: Optional[datetime]
    ends_at: Optional[datetime]
    is_active: bool
    meta: OkMeta = Field(default_factory=OkMeta)


# =============================================================================
# Блок: Модерация заявок (Withdraw EFHC, NFT-requests)
# -----------------------------------------------------------------------------
ModerationAction = Literal["APPROVE", "REJECT"]

class AdminWithdrawModerateIn(IdempotencyContract):
    """
    Модерация заявки на вывод EFHC (денежная операция внутри контура):
    • APPROVE — списать EFHC у пользователя в пользу Банка, пометить заявку одобренной.
    • REJECT — отклонить (балансы не трогаем).
    """
    request_id: int = Field(..., description="ID заявки на вывод")
    action: ModerationAction
    admin_note: Optional[str] = Field(None, description="Причина/комментарий")
    actor: AdminActor


class AdminWithdrawModerateOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    request_id: int
    action: ModerationAction
    user_id: int
    new_status: Literal["APPROVED", "REJECTED"] = Field(..., description="Итоговый статус заявки")
    user_balances_after: Optional[BalancePair] = Field(
        None, description="Баланс пользователя после APPROVE (для REJECT — None)"
    )
    bank_balance_after: Optional[str] = Field(None, description="Баланс Банка после APPROVE (str, 8)")
    note: Optional[str] = Field(None, description="Примечание")


class AdminNftRequestModerateIn(IdempotencyContract):
    """
    Модерация заявки на NFT (из Shop):
    • APPROVE — факт ручной выдачи NFT выполнен (вне системы), ставим статус APPROVED.
    • REJECT — отклонить (деньги не возвращаем автоматически; политика — на стороне админа).
    """
    request_id: int = Field(..., description="ID заявки на NFT")
    action: ModerationAction
    admin_note: Optional[str] = Field(None, description="Причина/комментарий")
    actor: AdminActor


class AdminNftRequestModerateOut(BaseModel):
    meta: OkMeta = Field(default_factory=OkMeta)
    request_id: int
    action: ModerationAction
    new_status: Literal["APPROVED", "REJECTED"]
    note: Optional[str] = Field(None)


# =============================================================================
# Блок: Курсорные страницы административных списков (примеры)
# -----------------------------------------------------------------------------
class TonInboxLogRow(BaseModel):
    """Строка журнала входящих TON (свёрнутая форма для админ-вью)."""
    id: int
    tx_hash: str
    from_address: str
    to_address: str
    amount: str
    memo: Optional[str]
    status: str
    retries_count: int
    next_retry_at: Optional[datetime]
    created_at: datetime

    @validator("amount", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


TonInboxPage = CursorPage[TonInboxLogRow]


class WithdrawRow(BaseModel):
    """Строка заявок на вывод EFHC (для админ-таблиц)."""
    id: int
    user_id: int
    amount: str
    status: Literal["PENDING", "APPROVED", "REJECTED"]
    created_at: datetime
    updated_at: Optional[datetime]

    @validator("amount", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


WithdrawPage = CursorPage[WithdrawRow]


# =============================================================================
# Пояснения:
# • Все суммы — только строки с 8 знаками (d8_str). Так фронтенд получает
#   стабильный формат без рассинхрона.
# • Любое «денежное» действие в админке должно требовать Idempotency-Key
#   (в роутере будет верификация заголовка).
# • Прямых правок балансов нет: любые изменения проходят через bank-сервис
#   (credit/debit, бонус-логика и т.д.), что обеспечивает аудит и зеркальные логи.
# • Реконсиляция TON имеет dry_run, лимиты и аккуратный протокол — это помогает
#   самовосстановлению и защищает от перегрузок.
# • DTO для Shop/Tasks/Lottery — это форма данных; бизнес-правила применяются
#   в соответствующих сервисах (shop_service, tasks_service, lottery_service).
# =============================================================================
