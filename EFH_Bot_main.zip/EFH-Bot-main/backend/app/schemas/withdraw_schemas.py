# -*- coding: utf-8 -*-
# backend/app/schemas/withdraw_schemas.py
# =============================================================================
# Назначение кода:
# Pydantic-схемы раздела «Вывод EFHC»:
#  • создание заявки на вывод EFHC на TON-адрес (Jetton transfer),
#  • отмена заявки пользователем,
#  • модерация/выплата в админке,
#  • курсорная пагинация списков заявок.
#
# Канон/инварианты:
#  • Вывод доступен ТОЛЬКО в EFHC (Jetton). Вывод в TON (coin) отключён.
#  • Денежные POST требуют заголовок Idempotency-Key; в теле допустим client_nonce.
#  • Пользователь НЕ может уходить в минус; списание только из main_balance (не бонусы).
#  • Все суммы — Decimal с 8 знаками (округление вниз).
#
# ИИ-защита:
#  • Строгая валидация входных значений (amount > 0, формат адреса, длины строк).
#  • Централизованная квантизация Decimal до 8 знаков через d8().
#  • Никаких скрытых полей: только то, что нужно фронту/админке для надёжной работы.
#
# Запреты:
#  • НЕТ выводу бонусов (bonus_balance).
#  • НЕТ любых P2P — все выплаты оформляются только «банк ↔ пользователь» (через сервис).
#  • НЕТ EFHC→kWh и прочих обратных конверсий.
# =============================================================================

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, condecimal, constr, validator

from backend.app.schemas.common_schemas import CursorPage
from backend.app.deps import d8

# -----------------------------------------------------------------------------
# Статусы заявок на вывод (жизненный цикл)
# -----------------------------------------------------------------------------
WithdrawStatus = Literal[
    "PENDING",         # создана пользователем, ожидает модерации
    "UNDER_REVIEW",    # взята в обработку админом/оператором
    "APPROVED",        # одобрена к выплате (резервация средств)
    "REJECTED",        # отклонена (с пояснением)
    "PAID",            # выплачена (есть tx_hash)
    "FAILED",          # техническая неудача выплаты (можно переоформить)
    "CANCELLED",       # отменена пользователем до выплаты
]

# -----------------------------------------------------------------------------
# Базовые валидаторы
# -----------------------------------------------------------------------------
def _is_lite_ton_address(addr: str) -> bool:
    """
    Мини-валидация TON-адреса без вызова внешних зависимостей.
    Допускаем bounceable/non-bounceable (символы base64/base32), проверяем длину.
    Окончательная проверка должна выполняться в сервисе через интеграцию ноды.
    """
    if not addr or not isinstance(addr, str):
        return False
    if not (48 <= len(addr) <= 68):
        return False
    # Разрешённые символы: базовый набор (упрощённо).
    allowed = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-+="
    return all(c in allowed for c in addr)


# =============================================================================
# Создание/отображение заявок пользователем
# =============================================================================

class WithdrawCreateIn(BaseModel):
    """
    Создание заявки на вывод EFHC пользователем.
    Денежный POST: обязателен заголовок Idempotency-Key (см. роут).
    Списание будет выполнено ТОЛЬКО из main_balance (не бонусов).
    """
    amount_efhc: condecimal(gt=Decimal("0"), max_digits=30, decimal_places=10) = Field(
        ..., description="Сумма EFHC к выводу (> 0). Будет округлена вниз до 8 знаков."
    )
    dest_ton_address: constr(strip_whitespace=True, min_length=48, max_length=68) = Field(
        ..., description="Целевой TON-адрес для перевода EFHC (Jetton)."
    )
    memo: Optional[constr(strip_whitespace=True, max_length=140)] = Field(
        None, description="Необязательное примечание пользователя."
    )
    client_nonce: Optional[constr(strip_whitespace=True, min_length=1, max_length=128)] = Field(
        None, description="Доп. предохранитель идемпотентности; не заменяет Idempotency-Key."
    )

    @validator("amount_efhc", pre=True, always=True)
    def _q8_amount(cls, v: Decimal) -> Decimal:
        return d8(v)

    @validator("dest_ton_address")
    def _check_addr(cls, v: str) -> str:
        if not _is_lite_ton_address(v):
            raise ValueError("Некорректный формат TON-адреса.")
        return v

    class Config:
        json_encoders = {Decimal: lambda v: str(d8(v))}


class WithdrawCancelIn(BaseModel):
    """
    Отмена заявки пользователем (если ещё не выплачена/не в финальном статусе).
    """
    reason: Optional[constr(strip_whitespace=True, max_length=200)] = Field(
        None, description="Причина отмены (для аудита)."
    )


class WithdrawOut(BaseModel):
    """
    Универсальное представление заявки (для пользователя).
    """
    id: int
    user_tg_id: int
    status: WithdrawStatus
    amount_efhc: Decimal
    dest_ton_address: str
    memo: Optional[str] = None

    # Админ/выплата:
    tx_hash: Optional[str] = Field(None, description="Хэш транзакции выплаты EFHC (если выплачено).")
    fee_efhc: Optional[Decimal] = Field(None, description="Комиссия, если применима (Decimal/8).")
    processed_by_tg_id: Optional[int] = Field(None, description="Админ/оператор, обработавший выплату.")

    # Идемпотентность и аудит:
    idempotency_key: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    processed_at: Optional[datetime] = None

    @validator("amount_efhc", "fee_efhc", pre=True, always=True)
    def _q8(cls, v: Optional[Decimal]) -> Optional[Decimal]:
        return None if v is None else d8(v)

    class Config:
        json_encoders = {Decimal: lambda v: str(d8(v))}


class WithdrawPage(CursorPage[WithdrawOut]):  # type: ignore[type-arg]
    """Страница заявок (курсоры без OFFSET)."""
    items: List[WithdrawOut]


# =============================================================================
# Админские входные схемы (модерация/выплата)
# =============================================================================

class AdminWithdrawTakeIn(BaseModel):
    """
    Взять заявку в обработку (UNDER_REVIEW).
    Используется, чтобы помечать обработчика и фиксировать захват в логах.
    """
    operator_tg_id: int = Field(..., description="Telegram ID оператора, взявшего в работу.")


class AdminWithdrawDecisionIn(BaseModel):
    """
    Админское решение по заявке: APPROVED или REJECTED.
    Если rejected=True — заявку отклоняем, указав причину.
    Если approved=True — переводим в APPROVED (резервация средств на выплату).
    """
    approved: bool = Field(..., description="True — одобрить; False — отклонить.")
    operator_tg_id: int = Field(..., description="Telegram ID оператора.")
    reason: Optional[constr(strip_whitespace=True, max_length=240)] = Field(
        None, description="Причина отклонения/комментарий."
    )


class AdminWithdrawMarkPaidIn(BaseModel):
    """
    Отметить заявку как выплаченную (PAID).
    Денежный POST: требуем Idempotency-Key на уровне роута.
    """
    operator_tg_id: int = Field(..., description="Telegram ID оператора.")
    tx_hash: constr(strip_whitespace=True, min_length=16, max_length=128) = Field(
        ..., description="Хэш Jetton-транзакции выплаты EFHC."
    )
    fee_efhc: Optional[condecimal(ge=Decimal("0"), max_digits=30, decimal_places=10)] = Field(
        None, description="Комиссия EFHC, если применима (>= 0)."
    )
    admin_memo: Optional[constr(strip_whitespace=True, max_length=240)] = Field(
        None, description="Комментарий оператора/админа."
    )
    client_nonce: Optional[constr(strip_whitespace=True, min_length=1, max_length=128)] = Field(
        None, description="Доп. предохранитель идемпотентности."
    )

    @validator("fee_efhc", pre=True, always=True)
    def _q8_fee(cls, v: Optional[Decimal]) -> Optional[Decimal]:
        return None if v is None else d8(v)

    class Config:
        json_encoders = {Decimal: lambda v: str(d8(v))}


class AdminWithdrawFailIn(BaseModel):
    """
    Пометить выплату как FAILED (например, ошибка ноды/сети).
    Сервис должен сохранить причину и дать возможность повторить выплату.
    """
    operator_tg_id: int
    error_text: constr(strip_whitespace=True, min_length=1, max_length=240)


# =============================================================================
# Пояснения «для чайника»:
# • Почему требуется TON-адрес?
#   EFHC — Jetton в сети TON. Вывод — это исходящий transfer Jetton на адрес пользователя.
#
# • Почему только main_balance?
#   Бонусы невыплатные по канону. Вывод — только из основного баланса EFHC.
#
# • Где проверяется «не уйти в минус»?
#   В сервисе выплат: перед созданием/подтверждением заявки идёт атомарная проверка
#   и резервация/списание через банковский сервис. Схемы лишь валидируют формат данных.
#
# • Зачем столько статусов?
#   Чтобы не терять контекст обработки и обеспечивать самовосстановление:
#   при сбое можно продолжить с последнего статуса (UNDER_REVIEW/APPROVED и т. д.).
#
# • Где именно идемпотентность?
#   Для денежных POST в роуте требуется заголовок Idempotency-Key (канон).
#   В таблице лога трансферов — UNIQUE(idempotency_key) и read-through обработка.
# =============================================================================
