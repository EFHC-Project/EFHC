# -*- coding: utf-8 -*-
# backend/app/schemas/shop_schemas.py
# =============================================================================
# Назначение кода:
# Pydantic-схемы для раздела «Shop»:
#  • витрина каталога (товары/пакеты),
#  • оформление покупки за EFHC/бонусы внутри бота,
#  • создание TON-интента для оплаты EFHC-пакетов,
#  • заявки на NFT (только ручная выдача),
#  • просмотр заказов (курсоры).
#
# Канон/инварианты:
#  • 1 EFHC = 1 kWh; обратной конверсии НЕТ (Shop это не меняет).
#  • Внутри бота покупка разрешена за EFHC (сначала бонусный, затем основной баланс).
#  • EFHC-пакеты за TON: автодоставка через вотчер (TON→лог→начисление из Банка).
#  • NFT — только заявка и ручная обработка администратором (никакой авто-выдачи).
#  • Все денежные POST требуют Idempotency-Key в заголовке; в теле допускается client_nonce.
#  • Все суммы — Decimal с 8 знаками (округление вниз).
#  • Пользователь не может уходить в минус; банк может (операции не блокируются).
#
# ИИ-защита:
#  • Жёсткая валидация входа, квантизация Decimal до 8 знаков через общий d8().
#  • Защита от нулевых/отрицательных количеств.
#  • Опциональный client_nonce как дополнительный «предохранитель» идемпотентности.
#
# Запреты:
#  • Нет авто-доставки NFT.
#  • Нет P2P (только «банк ↔ пользователь» через банковский сервис).
#  • Нет EFHC→kWh и любых «серых» обменов/скидок, ломающих канон.
# =============================================================================

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, conint, condecimal, constr, validator

from backend.app.schemas.common_schemas import CursorPage
from backend.app.deps import d8

# -----------------------------------------------------------------------------
# Общие литералы/значения домена
# -----------------------------------------------------------------------------

ShopItemType = Literal["EFHC_PACKAGE", "NFT_VIP", "VIRTUAL_GOOD", "DIGITAL_SERVICE"]
ShopOrderStatus = Literal[
    "PENDING",                # создан, ожидает оплаты (для TON) или проведения (для EFHC)
    "PAID_AUTO",              # оплачено автоматически (TON), автодоставлено (кроме NFT)
    "PAID_PENDING_MANUAL",    # оплачено, ждёт ручной обработки (NFT)
    "APPROVED",               # админ утвердил (например, NFT выдан)
    "REJECTED",               # админ отклонил
    "CANCELLED"               # отменён
]
PayMethod = Literal["EFHC", "TON"]

# Канонический SKU-формат для TON-мемо:
#  • EFHC-пакеты: "SKU:EFHC|Q:<INT>|TG:<telegram_id>"
#  • NFT-заявка:  "SKU:NFT_VIP|Q:1|TG:<telegram_id>"
SKU_MAX_LEN = 64

# =============================================================================
# Витрина каталога
# =============================================================================

class ShopCatalogItemOut(BaseModel):
    """
    Элемент витрины Shop. Универсальная карточка товара.
    Для EFHC-пакетов указываем ton_enabled=True, memо_template и т.д.
    Для покупок внутри бота указываем price_efhc (списывается: bonus→main).
    """
    id: int = Field(..., description="ID товара.")
    type: ShopItemType = Field(..., description="Тип товара (EFHC_PACKAGE / NFT_VIP / ...).")
    sku: constr(strip_whitespace=True, min_length=1, max_length=SKU_MAX_LEN) = Field(
        ..., description="Уникальный SKU (используется в заказах/мемо)."
    )
    title: constr(strip_whitespace=True, min_length=1, max_length=255)
    description: Optional[str] = None
    active: bool = True

    # Покупка за EFHC внутри бота (списывается bonus→main):
    price_efhc: Optional[Decimal] = Field(
        None, description="Цена в EFHC (Decimal/8). Если None — внутри бота не купить."
    )

    # Подсказки для TON-оплаты EFHC-пакетов:
    ton_enabled: bool = Field(False, description="Можно оплатить через TON (для EFHC-пакетов).")
    ton_dest_address: Optional[str] = Field(
        None, description="TON-адрес проекта для оплаты (подтверждается watcher'ом)."
    )
    ton_price_hint: Optional[Decimal] = Field(
        None, description="Ориентировочная цена в TON для Q единиц (информативно)."
    )
    memo_template: Optional[str] = Field(
        None,
        description="Шаблон мемо для TON (например, 'SKU:EFHC|Q:{qty}|TG:{tgid}')."
    )

    # Ограничения/наличие
    max_per_user: Optional[conint(ge=0)] = Field(
        None, description="Лимит на пользователя (0 — запрет, None — без лимита)."
    )
    stock_total: Optional[conint(ge=0)] = None
    stock_left: Optional[conint(ge=0)] = None

    # Превью/медиа
    image_url: Optional[str] = None

    created_at: datetime
    updated_at: datetime

    @validator("price_efhc", "ton_price_hint", pre=True, always=True)
    def _q8(cls, v: Optional[Decimal]) -> Optional[Decimal]:
        return None if v is None else d8(v)

    class Config:
        json_encoders = {Decimal: lambda v: str(d8(v))}


class ShopCatalogPage(CursorPage[ShopCatalogItemOut]):  # type: ignore[type-arg]
    """Страница каталога Shop (курсоры без OFFSET)."""
    items: List[ShopCatalogItemOut]


# =============================================================================
# Создание заказа / покупка внутри бота за EFHC
# =============================================================================

class ShopPurchaseByEFHCIn(BaseModel):
    """
    Покупка за EFHC внутри бота.
    Денежный POST: обязателен заголовок Idempotency-Key (см. роуты).
    Списание: сначала бонусный, затем основной баланс; банку — встречная запись.
    """
    sku: constr(strip_whitespace=True, min_length=1, max_length=SKU_MAX_LEN)
    quantity: conint(gt=0) = Field(..., description="Штуки > 0.")
    # Доп. предохранители:
    prefer_bonus_first: bool = Field(True, description="Сначала списать бонусы (канон).")
    client_nonce: Optional[constr(strip_whitespace=True, min_length=1, max_length=128)] = None


class ShopPurchaseByEFHCOut(BaseModel):
    """
    Результат покупки за EFHC внутри бота (через банковский сервис).
    """
    ok: bool = True
    sku: str
    quantity: int
    debited_bonus_efhc: Decimal = Field(Decimal("0"))
    debited_main_efhc: Decimal = Field(Decimal("0"))
    total_debited_efhc: Decimal = Field(Decimal("0"))
    bank_transfer_log_id: int = Field(..., description="ID в efhc_transfers_log.")
    idempotency_key: str
    message: str = ""
    processed_at: datetime

    @validator("debited_bonus_efhc", "debited_main_efhc", "total_debited_efhc", pre=True, always=True)
    def _q8(cls, v: Decimal) -> Decimal:
        return d8(v)

    class Config:
        json_encoders = {Decimal: lambda v: str(d8(v))}


# =============================================================================
# Создание TON-интента (EFHC-пакеты за TON)
# =============================================================================

class TonPaymentIntentIn(BaseModel):
    """
    Запросить параметры оплаты EFHC-пакета через TON.
    Денежного движения на сервере ещё нет; это только выдача адреса/мемо.
    """
    sku: constr(strip_whitespace=True, min_length=1, max_length=SKU_MAX_LEN)
    quantity: conint(gt=0) = Field(..., description="Сколько единиц пакета покупаем.")
    client_nonce: Optional[constr(strip_whitespace=True, min_length=1, max_length=128)] = None


class TonPaymentIntentOut(BaseModel):
    """
    Параметры для оплаты в TON:
     • адрес проекта;
     • мемо для связывания платежа с пользователем и SKU (watcher разберёт);
     • ориентировочная сумма (если применимо).
    """
    ok: bool = True
    dest_address: str = Field(..., description="TON-адрес проекта (из конфигурации).")
    memo: str = Field(..., description="Строгий MEMO (например, 'SKU:EFHC|Q:100|TG:123456').")
    ton_amount_due_hint: Optional[Decimal] = Field(
        None, description="Подсказка по сумме TON, если есть прайс на стороне магазина."
    )
    expires_at: Optional[datetime] = Field(
        None, description="Время жизни интента (информативно)."
    )
    created_order_id: Optional[int] = Field(
        None, description="ID предварительного заказа (если создаётся запись)."
    )

    @validator("ton_amount_due_hint", pre=True, always=True)
    def _q8(cls, v: Optional[Decimal]) -> Optional[Decimal]:
        return None if v is None else d8(v)

    class Config:
        json_encoders = {Decimal: lambda v: str(d8(v))}


# =============================================================================
# Заявка на NFT (ручная обработка)
# =============================================================================

class NftRequestCreateIn(BaseModel):
    """
    Создание заявки на NFT (VIP). Денежный POST (если создаётся платный заказ) —
    обязателен Idempotency-Key. Авто-выдачи NFT НЕТ — только ручной аппрув.
    """
    sku: constr(strip_whitespace=True, min_length=1, max_length=SKU_MAX_LEN) = Field(
        "NFT_VIP", description="По канону: 'NFT_VIP'."
    )
    quantity: conint(gt=0) = Field(1, description="Обычно 1.")
    client_nonce: Optional[constr(strip_whitespace=True, min_length=1, max_length=128)] = None


class NftRequestOut(BaseModel):
    id: int
    sku: str
    quantity: int
    status: ShopOrderStatus
    user_tg_id: int
    tx_hash: Optional[str] = None
    created_at: datetime
    updated_at: datetime


# =============================================================================
# Универсальный заказ (просмотр/история)
# =============================================================================

class ShopOrderOut(BaseModel):
    """
    Универсальное представление заказа в Shop.
    Для EFHC-покупок внутри бота tx_hash=None; для TON — устанавливается вотчером.
    """
    id: int
    type: ShopItemType
    sku: str
    quantity: int
    status: ShopOrderStatus
    user_tg_id: int

    # Для TON-оплаты:
    tx_hash: Optional[str] = Field(None, description="Хэш платежа TON (если применимо).")

    # Для покупок за EFHC внутри бота:
    debited_bonus_efhc: Optional[Decimal] = Field(None, description="Списано бонусов.")
    debited_main_efhc: Optional[Decimal] = Field(None, description="Списано основного баланса.")
    idempotency_key: Optional[str] = Field(None, description="Ключ идемпотентности, если применялся.")

    created_at: datetime
    updated_at: datetime

    @validator("debited_bonus_efhc", "debited_main_efhc", pre=True, always=True)
    def _q8(cls, v: Optional[Decimal]) -> Optional[Decimal]:
        return None if v is None else d8(v)

    class Config:
        json_encoders = {Decimal: lambda v: str(d8(v))}


class ShopOrdersPage(CursorPage[ShopOrderOut]):  # type: ignore[type-arg]
    """Страница заказов пользователя/админ-вида с курсорной пагинацией."""
    items: List[ShopOrderOut]


# =============================================================================
# Пояснения «для чайника»:
# • Почему два способа оплаты?
#   Канон проекта: внутри бота всё можно купить за EFHC (сначала бонус, затем основной).
#   Отдельно EFHC-пакеты покупаются за TON (вне системы) — кредиты начисляет вотчер,
#   когда увидит корректную транзакцию с MEMO «SKU:...|TG:<id>».
#
# • Где именно идемпотентность?
#   Любой денежный POST (покупка за EFHC, создание платной NFT-заявки и т. п.)
#   требует заголовок Idempotency-Key. Дополнительно клиент может передать client_nonce.
#   В БД у efhc_transfers_log UNIQUE(idempotency_key), read-through логика в сервисе.
#
# • Как списываются EFHC?
#   Всегда bonus→main (сначала бонусы), и зеркальная запись в лог «банк↔пользователь».
#   Пользователь в минус уйти не может (код сервиса это запрещает).
#
# • Почему курсоры?
#   Курсорная пагинация стабильнее OFFSET на больших объёмах и естественно дружит
#   с ретраями, догоном и повторными запросами.
# =============================================================================
