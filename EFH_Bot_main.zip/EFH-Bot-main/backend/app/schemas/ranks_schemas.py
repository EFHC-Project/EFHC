
# -*- coding: utf-8 -*-
# backend/app/schemas/ranks_schemas.py
# =============================================================================
# Назначение кода:
# Pydantic-схемы для модуля «Рейтинг» (Ranks/Rating) EFHC Bot.
# Этот файл описывает ВСЕ формы данных, которыми обмениваются роуты и сервисы:
#   • «Я + TOP» — выдача реального места пользователя + витрина TOP-N (без
#     дублирования «Я» в списке),
#   • курсорная пагинация TOP-списков (без OFFSET),
#   • определения уровней (12 рангов) как витринные DTO (без бизнес-логики),
#   • служебная «принудительная синхронизация» рейтинговых снимков.
#
# Канон / инварианты:
# • Источник рейтинга — только total_generated_kwh (тотал энергии), НЕ available.
# • Денежных операций здесь нет. Никаких P2P/конверсий/списаний — запрещено.
# • Все числовые значения энергии наружу — СТРОКОЙ с 8 знаками (Decimal, вниз).
# • «Я» всегда показывается первым с реальным place, далее TOP без повторения «Я».
#
# ИИ-защита / самовосстановление:
# • Единый контейнер CursorPage[T] для устойчивой подгрузки списков (next_cursor, etag).
# • OkMeta в каждом комплексном ответе для дружелюбного восстановления UI.
# • Отдельные DTO для «принудительной синхронизации» (force_refresh/догон).
#
# Запреты:
# • В схемах нет бизнес-логики (порогов уровней, перерасчётов и т.п.).
# • Никаких «суточных» абстракций — сервисы опираются только на per-sec ставки,
#   а рейтинг строится исключительно по total_generated_kwh.
# =============================================================================

from __future__ import annotations

# =============================================================================
# Импорты
# -----------------------------------------------------------------------------
from typing import Optional, List, Any
from pydantic import BaseModel, Field, validator

from backend.app.schemas.common_schemas import (
    OkMeta,         # служебная «ок»-обёртка (ok/trace/ts) для устойчивости UI
    CursorPage,     # унифицированный контейнер курсорной пагинации
    d8_str,         # Decimal → строка с 8 знаками (ROUND_DOWN) для энергии/EFHC
)

# =============================================================================
# Базовые карточки рейтинга
# -----------------------------------------------------------------------------
class RankRow(BaseModel):
    """
    Карточка участника рейтинга для TOP-списка.
    """
    user_id: int = Field(..., description="Внутренний ID пользователя")
    telegram_id: int = Field(..., description="Telegram ID пользователя")
    username: Optional[str] = Field(None, description="Ник (если задан)")
    place: int = Field(..., ge=1, description="Позиция в общем рейтинге (1-based)")
    total_generated_kwh: str = Field(..., description="Тотал сгенерированной энергии (str, 8 знаков)")
    level_index: int = Field(..., ge=1, le=12, description="Порядковый номер уровня 1..12")
    level_name: str = Field(..., description="Название уровня (витрина)")
    is_vip: bool = Field(..., description="Флаг VIP (наличие NFT из коллекции)")

    @validator("total_generated_kwh", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


class RankMeBlock(BaseModel):
    """
    Короткий блок «Я» — отдельный от TOP, чтобы исключить повтор.
    """
    user_id: int
    telegram_id: int
    username: Optional[str]
    place: int
    total_generated_kwh: str
    level_index: int
    level_name: str
    is_vip: bool

    ahead_count: int = Field(..., ge=0, description="Сколько пользователей выше меня")
    behind_count: int = Field(..., ge=0, description="Сколько пользователей ниже меня")

    @validator("total_generated_kwh", pre=True)
    def _q8(cls, v: Any) -> str:
        return d8_str(v)


# =============================================================================
# Витрина «Я + TOP» (комбинированная форма)
# -----------------------------------------------------------------------------
# Страница TOP-N — CursorPage[RankRow] с items[], next_cursor, etag
TopPage = CursorPage[RankRow]


class RankFeedOut(BaseModel):
    """
    Комплексный ответ для экрана рейтинга:
    • me — реальный блок «Я» (всегда присутствует, даже если не попадаю в TOP-N),
    • top — страница TOP-N (без дублирования «Я»),
    • meta — служебные поля для дружелюбного восстановления UI.
    """
    meta: OkMeta = Field(default_factory=OkMeta)
    me: RankMeBlock
    top: TopPage


# =============================================================================
# Опциональные витрины определений уровней
# -----------------------------------------------------------------------------
class RankLevelDef(BaseModel):
    """
    Витринная запись определения уровня (без жесткой бизнес-логики в схемах).
    threshold_kwh — строка с 8 знаками (если сервис публикует порог).
    """
    level_index: int = Field(..., ge=1, le=12, description="Порядок уровня 1..12")
    level_name: str = Field(..., description="Название уровня")
    threshold_kwh: Optional[str] = Field(
        None,
        description="Порог тотала для уровня (str, 8). Может быть скрыт/None."
    )

    @validator("threshold_kwh", pre=True)
    def _q8(cls, v: Any) -> Optional[str]:
        if v is None:
            return None
        return d8_str(v)


class RankLevelsOut(BaseModel):
    """
    Витрина уровней для UI (например, справка на экране рейтинга).
    """
    meta: OkMeta = Field(default_factory=OkMeta)
    levels: List[RankLevelDef] = Field(default_factory=list)


# =============================================================================
# Параметры курсорной пагинации для TOP-списков
# -----------------------------------------------------------------------------
class RankTopQueryIn(BaseModel):
    """
    Параметры курсорной пагинации TOP-списка.
    next_cursor — из предыдущего ответа; отсутствует для первой страницы.
    limit — желаемый размер страницы; дефолт выставляет сам роут.
    """
    next_cursor: Optional[str] = Field(None, description="Курсор следующей страницы (base64)")
    limit: Optional[int] = Field(None, ge=1, le=200, description="Размер страницы (1..200)")


# =============================================================================
# «Принудительная синхронизация» рейтинга (догон снапшотов)
# -----------------------------------------------------------------------------
class RankSyncOut(BaseModel):
    """
    Результат служебной синхронизации/догоняющего пересчёта (на открытии экрана).
    refreshed — сколько записей рейтинга или снапшотов было обновлено.
    """
    meta: OkMeta = Field(default_factory=OkMeta)
    refreshed: int = Field(..., ge=0, description="Сколько записей пересчитано/обновлено")
    errors: int = Field(..., ge=0, description="Сколько ошибок за проход")
    note: Optional[str] = Field(None, description="Короткая приметка ('partial'/'ok' и т.п.)")


# =============================================================================
# Пояснения (для разработчиков/ревью):
# • RankFeedOut — главный контракт экрана: «me» + страница «top». Сервисы
#   гарантируют, что «me» НЕ продублируется в top.items.
# • CursorPage[T] — общий контейнер с items[], next_cursor, etag. Роуты кодируют
#   курсор без OFFSET (например, по (snapshot_at, id) или (total, id)).
# • Все значения энергии — строки с 8 знаками (d8_str). Источник — total_generated_kwh.
# • В этих схемах нет бизнес-логики (порогов/алгоритмов уровней); уровни и места
#   вычисляет сервис рейтинга (ranks_service) + планировщик (update_rating).
# =============================================================================
