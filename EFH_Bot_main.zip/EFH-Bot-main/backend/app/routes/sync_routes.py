# -*- coding: utf-8 -*-
# backend/app/routes/sync_routes.py
# =============================================================================
# EFHC Bot — Единый синхро-роут для фронта (жёсткая сверка «на входе в экран»)
# -----------------------------------------------------------------------------
# Назначение:
#   • По запросу фронта (например, при открытии раздела) быстро «догоняет»
#     посекундную генерацию конкретного пользователя (идемпотентно),
#     затем возвращает единый снапшот для UI:
#       - профиль и балансы,
#       - сводку панелей,
#       - предпросмотр обмена,
#       - производную метрику gen_per_sec_effective (для анимации),
#       - server_now и next_scheduler_eta_sec (когда тикнет планировщик).
#
# ИИ-защита / автономность:
#   • Если догон генерации временно не удался (timeout/lock/network),
#     мы НЕ роняем запрос — возвращаем актуальные на сейчас данные,
#     параллельно ставим задачу в scheduler_task_log на авто-повтор
#     ('resync_user_energy') и отдаём caller'у fallback_task_id.
#   • Никаких денежных операций — только энергия (безопасно).
#
# Контракт:
#   GET /sync/user/{user_id}?fresh=1
#   fresh=1 (по умолчанию) — попытаться догнать генерацию перед сбором снапшота.
#   Ответ: см. SyncSnapshotOut ниже.
# =============================================================================

from __future__ import annotations

from decimal import Decimal, ROUND_DOWN
from typing import Any, Optional, Dict

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.deps import get_db

from backend.app.services.energy_service import generate_for_user as svc_generate_for_user
from backend.app.services.panels_service import panels_summary as svc_panels_summary
from backend.app.services.exchange_service import preview_exchange as svc_preview_exchange

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

EFHC_DECIMALS: int = int(getattr(settings, "EFHC_DECIMALS", 8) or 8)
Q8 = Decimal(1).scaleb(-EFHC_DECIMALS)

GEN_PER_SEC_BASE_KWH = Decimal(str(getattr(settings, "GEN_PER_SEC_BASE_KWH", "0.00000692") or "0.00000692")).quantize(Q8, rounding=ROUND_DOWN)
GEN_PER_SEC_VIP_KWH  = Decimal(str(getattr(settings, "GEN_PER_SEC_VIP_KWH",  "0.00000741") or "0.00000741")).quantize(Q8, rounding=ROUND_DOWN)
DAILY_BASE = Decimal(str(getattr(settings, "PANEL_GENERATION_NORMAL", "0.598") or "0.598")).quantize(Q8, rounding=ROUND_DOWN)
DAILY_VIP  = Decimal(str(getattr(settings, "PANEL_GENERATION_VIP",    "0.64")  or "0.64")).quantize(Q8, rounding=ROUND_DOWN)

TICK_SECONDS = 600  # плановый ритм планировщика 10 минут

def d8(x: Any) -> Decimal:
    return Decimal(str(x)).quantize(Q8, rounding=ROUND_DOWN)

router = APIRouter(prefix="/sync", tags=["sync"])

# -----------------------------------------------------------------------------
# Модели ответа
# -----------------------------------------------------------------------------

class ProfilePart(BaseModel):
    telegram_id: int
    username: Optional[str]
    is_vip: bool
    main_balance: str
    bonus_balance: str
    available_kwh: str
    total_generated_kwh: str
    daily_generation_base: str
    daily_generation_vip: str
    gen_per_sec_base: str
    gen_per_sec_vip: str

class PanelsPart(BaseModel):
    active_count: int
    total_generated_by_panels: str
    nearest_expire_at: Optional[str] = None

class ExchangePart(BaseModel):
    ok: bool
    available_kwh: str
    max_exchangeable_kwh: str
    rate_kwh_to_efhc: str
    detail: str

class SyncMeta(BaseModel):
    server_now_iso: str = Field(..., description="Время сервера ISO8601")
    gen_per_sec_effective: str = Field(..., description="Скорость генерации пользователя (кВт·ч/сек) = активные_панели * ставка(VIP?)")
    next_scheduler_eta_sec: int = Field(..., description="Сколько секунд осталось до ближайшего 10-минутного тика планировщика")
    fallback_task_id: Optional[int] = Field(None, description="Если был временный сбой догон-генерации — id постановки в очередь")

class SyncSnapshotOut(BaseModel):
    profile: ProfilePart
    panels: PanelsPart
    exchange_preview: ExchangePart
    meta: SyncMeta

# -----------------------------------------------------------------------------
# Вспомогательные функции
# -----------------------------------------------------------------------------

async def _enqueue_resync_energy(db: AsyncSession, *, user_id: int, reason: str, minutes: int = 10) -> int:
    """
    Ставит задачу на догон генерации для пользователя в scheduler_task_log.
    """
    row = await db.execute(
        text(
            f"""
            INSERT INTO {SCHEMA}.scheduler_task_log
                (task_name, status, error_text, payload, retry_time, executed_at, duration_sec, created_at, updated_at)
            VALUES
                ('resync_user_energy', 'queued', :err,
                 jsonb_build_object('user_id', :uid),
                 NOW() + (:min || ' minutes')::interval,
                 NULL, NULL, NOW(), NOW())
            RETURNING id
            """
        ),
        {"err": reason[:500], "uid": int(user_id), "min": int(minutes)},
    )
    rid = row.fetchone()
    return int(rid[0]) if rid else 0

def _is_transient_error(e: Exception) -> bool:
    s = f"{type(e).__name__}: {e}".lower()
    for sign in ("timeout", "temporar", "connection", "too many", "locked", "deadlock", "network", "server error"):
        if sign in s:
            return True
    return False

def _calc_next_tick_eta_sec(server_now_epoch: int) -> int:
    """
    Считает, сколько секунд до ближайшего «кратного 600» момента.
    Например, если TICK_SECONDS=600, то тики: 00:00, 00:10, 00:20, ...
    """
    r = server_now_epoch % TICK_SECONDS
    return 0 if r == 0 else (TICK_SECONDS - r)

# -----------------------------------------------------------------------------
# GET /sync/user/{user_id}?fresh=1 — «жёсткая» сверка снапшота для UI
# -----------------------------------------------------------------------------

@router.get("/user/{user_id}", response_model=SyncSnapshotOut, summary="Синхро-снапшот для UI (опционально догоняет генерацию)")
async def sync_user_snapshot(
    user_id: int,
    fresh: bool = Query(True, description="Попытаться догнать генерацию перед сбором снапшота"),
    db: AsyncSession = Depends(get_db),
) -> SyncSnapshotOut:
    fallback_task_id: Optional[int] = None

    # 1) При необходимости — «догон генерации» для пользователя (безопасная операция)
    if fresh:
        try:
            await svc_generate_for_user(db, user_id=int(user_id))
        except Exception as e:
            logger.warning("sync: generate_for_user failed (user %s): %s", user_id, e)
            if _is_transient_error(e):
                try:
                    fallback_task_id = await _enqueue_resync_energy(
                        db, user_id=int(user_id), reason=f"transient: {type(e).__name__}: {e}", minutes=10
                    )
                except Exception as enq_err:
                    logger.warning("sync: enqueue resync failed: %s", enq_err)
            # Даже если ошибка — продолжаем формировать снапшот из текущего состояния

    # 2) Профиль/балансы
    row = await db.execute(
        text(
            f"""
            SELECT
              u.telegram_id,
              u.username,
              COALESCE(u.is_vip, FALSE) AS is_vip,
              COALESCE(u.main_balance, 0) AS main_balance,
              COALESCE(u.bonus_balance, 0) AS bonus_balance,
              COALESCE(u.available_kwh, 0) AS available_kwh,
              COALESCE(u.total_generated_kwh, 0) AS total_generated_kwh
            FROM {SCHEMA}.users u
            WHERE u.id = :uid
            LIMIT 1
            """
        ),
        {"uid": int(user_id)},
    )
    rec = row.fetchone()
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="user_not_found")

    is_vip = bool(rec[2])
    gen_rate = GEN_PER_SEC_VIP_KWH if is_vip else GEN_PER_SEC_BASE_KWH

    profile = ProfilePart(
        telegram_id=int(rec[0]),
        username=rec[1],
        is_vip=is_vip,
        main_balance=str(d8(rec[3])),
        bonus_balance=str(d8(rec[4])),
        available_kwh=str(d8(rec[5])),
        total_generated_kwh=str(d8(rec[6])),
        daily_generation_base=str(DAILY_BASE),
        daily_generation_vip=str(DAILY_VIP),
        gen_per_sec_base=str(GEN_PER_SEC_BASE_KWH),
        gen_per_sec_vip=str(GEN_PER_SEC_VIP_KWH),
    )

    # 3) Сводка панелей
    ps = await svc_panels_summary(db, user_id=int(user_id))
    active_count = int(ps["active_count"])
    gen_per_sec_effective = d8(Decimal(active_count) * gen_rate)

    panels = PanelsPart(
        active_count=active_count,
        total_generated_by_panels=str(d8(ps["total_generated_by_panels"])),
        nearest_expire_at=(ps["nearest_expire_at"].isoformat() if ps.get("nearest_expire_at") else None),
    )

    # 4) Предпросмотр обмена
    xp = await svc_preview_exchange(db, user_id=int(user_id))
    exchange_preview = ExchangePart(
        ok=bool(xp.ok),
        available_kwh=str(d8(xp.available_kwh)),
        max_exchangeable_kwh=str(d8(xp.max_exchangeable_kwh)),
        rate_kwh_to_efhc=str(d8(xp.rate_kwh_to_efhc)),
        detail=xp.detail,
    )

    # 5) Мета: время сервера и ETA до следующего тика планировщика
    #    Получаем epoch через now() в БД, чтобы не зависеть от времени клиента
    now_row = await db.execute(text("SELECT EXTRACT(EPOCH FROM NOW())::bigint, NOW()::timestamptz"))
    epoch_val, now_ts = now_row.fetchone()
    eta = _calc_next_tick_eta_sec(int(epoch_val))

    meta = SyncMeta(
        server_now_iso=str(now_ts.isoformat()),
        gen_per_sec_effective=str(gen_per_sec_effective),
        next_scheduler_eta_sec=int(eta),
        fallback_task_id=fallback_task_id,
    )

    return SyncSnapshotOut(
        profile=profile,
        panels=panels,
        exchange_preview=exchange_preview,
        meta=meta,
    )
