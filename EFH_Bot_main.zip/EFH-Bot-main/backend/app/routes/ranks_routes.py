# backend/app/routes/ranks_routes.py
# =============================================================================
# Назначение:
#   • HTTP-роуты (FastAPI) для страницы "Рейтинг" (Rating) и системы достижений EFHC Bot.
#   • Показывает место пользователя + глобальный топ-100.
#
# Для чайника:
#   • Рейтинг = таблица пользователей по суммарной генерации энергии (total_generated_kwh).
#   • "Я" всегда вверху списка, даже если не в топе, чтобы видеть свой прогресс.
#
# Где используется:
#   • WebApp → страница "Рейтинг"
#   • Админ-панель → пересчёт рангов
#
# Важно:
#   • Первым в списке всегда идёт текущий пользователь (со своей позицией, даже если >100).
#   • Затем — топ-100 пользователей (1, 2, 3, …).
# =============================================================================

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from decimal import Decimal

from backend.app.database import get_db
from backend.app.deps import get_current_user, require_admin
from backend.app.models.user_models import User, UserBalance
from backend.app.models.ranks_models import UserRank
from backend.app.services.ranks_service import (
    get_rank_level,
    get_global_ranking,
    recalc_all_ranks,
)

router = APIRouter(prefix="/ranks", tags=["Ranks"])


# -----------------------------------------------------------------------------
# GET /ranks/me — профиль пользователя в рейтинге
# -----------------------------------------------------------------------------
@router.get("/me", summary="Получить свой уровень и место в рейтинге")
async def get_my_rank(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Возвращает:
      - уровень пользователя (название достижения),
      - общее количество сгенерированных kWh,
      - реальное место в рейтинге.
    """
    # 1. Получаем баланс пользователя
    stmt = select(UserBalance).where(UserBalance.user_id == current_user.telegram_id)
    res = await db.execute(stmt)
    balance = res.scalar()
    if not balance:
        raise HTTPException(status_code=404, detail="Balance not found")

    total_generated = Decimal(balance.total_generated_kwh)
    my_rank_name = get_rank_level(total_generated)

    # 2. Определяем позицию в рейтинге
    stmt_rank = (
        select(UserBalance.user_id, UserBalance.total_generated_kwh)
        .order_by(desc(UserBalance.total_generated_kwh))
    )
    all_rows = await db.execute(stmt_rank)
    rank_list = all_rows.all()

    position = next(
        (i + 1 for i, row in enumerate(rank_list) if row.user_id == current_user.telegram_id),
        None,
    )

    return {
        "status": "ok",
        "data": {
            "telegram_id": current_user.telegram_id,
            "username": current_user.username,
            "rank_name": my_rank_name,
            "total_generated_kwh": str(total_generated),
            "position": position or "—",
        },
    }


# -----------------------------------------------------------------------------
# GET /ranks/top — глобальный рейтинг (включая текущего пользователя)
# -----------------------------------------------------------------------------
@router.get("/top", summary="Глобальный рейтинг (пользователь + топ-100)")
async def get_top_ranking(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Возвращает комбинированный рейтинг:
      1. Сначала — текущий пользователь (даже если он на месте 1435 и не входит в топ-100).
      2. Затем — топ-100 пользователей по total_generated_kwh.
    """
    # 1. Получаем все балансы по убыванию total_generated_kwh
    stmt_all = (
        select(UserBalance, User)
        .join(User, User.telegram_id == UserBalance.user_id)
        .order_by(desc(UserBalance.total_generated_kwh))
    )
    all_res = await db.execute(stmt_all)
    rows = all_res.all()

    # 2. Определяем позицию пользователя
    position = None
    for i, (balance, user) in enumerate(rows):
        if user.telegram_id == current_user.telegram_id:
            position = i + 1
            my_entry = {
                "position": position,
                "telegram_id": user.telegram_id,
                "username": user.username,
                "rank_name": get_rank_level(Decimal(balance.total_generated_kwh)),
                "total_generated_kwh": str(balance.total_generated_kwh),
                "is_vip": user.is_vip,
                "me": True,
            }
            break

    if position is None:
        raise HTTPException(status_code=404, detail="User not found in ranking")

    # 3. Получаем топ-100 пользователей (без "me")
    stmt_top = (
        select(UserBalance, User)
        .join(User, User.telegram_id == UserBalance.user_id)
        .order_by(desc(UserBalance.total_generated_kwh))
        .limit(100)
    )
    top_res = await db.execute(stmt_top)
    top_rows = top_res.all()

    top_data = [
        {
            "position": idx + 1,
            "telegram_id": usr.telegram_id,
            "username": usr.username,
            "rank_name": get_rank_level(Decimal(bal.total_generated_kwh)),
            "total_generated_kwh": str(bal.total_generated_kwh),
            "is_vip": usr.is_vip,
            "me": False,
        }
        for idx, (bal, usr) in enumerate(top_rows)
    ]

    # 4. Комбинируем: сначала текущий пользователь, потом топ-100
    return {
        "status": "ok",
        "data": [my_entry] + top_data,
    }


# -----------------------------------------------------------------------------
# POST /ranks/recalculate — пересчёт всех рангов (для админа)
# -----------------------------------------------------------------------------
@router.post("/recalculate", summary="Пересчитать ранги всех пользователей (админ)")
async def recalculate_ranks(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """
    Принудительно пересчитывает ранги всех пользователей на основе total_generated_kwh.
    """
    count = await recalc_all_ranks(db)
    return {
        "status": "ok",
        "data": {
            "message": f"Ранги обновлены для {count} пользователей",
            "updated_count": count,
        },
    }


# -----------------------------------------------------------------------------
# GET /ranks/levels — справочник уровней
# -----------------------------------------------------------------------------
@router.get("/levels", summary="Справочник уровней достижений EFHC")
async def get_rank_levels():
    """
    Возвращает фиксированные уровни (12 рангов EFHC).
    """
    return {
        "status": "ok",
        "data": [
            {"level": "Eco Initiate", "threshold_kwh": "0"},
            {"level": "Hope Bringer", "threshold_kwh": "100"},
            {"level": "Energy Seeker", "threshold_kwh": "500"},
            {"level": "Nature's Voice", "threshold_kwh": "1000"},
            {"level": "Earth Ally", "threshold_kwh": "2500"},
            {"level": "Climate Fighter", "threshold_kwh": "5000"},
            {"level": "Green Sentinel", "threshold_kwh": "10000"},
            {"level": "Planet Defender", "threshold_kwh": "25000"},
            {"level": "Eco Champion", "threshold_kwh": "50000"},
            {"level": "Planet Saver", "threshold_kwh": "100000"},
            {"level": "Green Commander", "threshold_kwh": "250000"},
            {"level": "Guardian of Earth", "threshold_kwh": "500000"},
        ],
  }
