# -*- coding: utf-8 -*-
# backend/app/routes/admin_referral_routes.py
# =============================================================================
# Назначение кода:
#   Админ-ручки реферального блока: обзор статистики, ручное бонусное начисление,
#   переназначение пригласившего. Роутер сам денег не трогает — всё через сервисы.
#
# Канон/инварианты:
#   • Денежные POST требуют строгий Idempotency-Key в заголовке.
#   • Все начисления бонусов идут только через единый банковский сервис (через
#     referral_service → transactions_service.credit_user_bonus_from_bank).
#   • Никаких P2P и «скрытой эмиссии». Роутер — только оркестрация.
#   • Списки — курсорная пагинация + ETag (для кэша на фронте/админке).
#
# ИИ-защита/самовосстановление:
#   • «Мягкие» вызовы сервисов: если модуль временно недоступен — возвращаем 503
#     с дружелюбным сообщением, цикл системы не ломается.
#   • Никаких суточных расчётов — только читательские агрегаты/делегирование.
#
# Запреты:
#   • Нет прямых SQL-изменений балансов, нет авто-выдачи NFT, нет P2P.
#   • Нет локальных дубликатов d8/ETag/cursor-кодеков — всё централизовано в deps.py.
# =============================================================================

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Response, status
from pydantic import BaseModel, Field, conint, constr, validator
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.deps import (
    get_db,             # AsyncSession провайдер
    require_admin,      # 403, если не админ
    d8,                 # Decimal(8) округление вниз
    encode_cursor,      # курсор → str
    decode_cursor,      # str → dict
    etag,               # ETag из тела ответа
)
from backend.app.core.logging_core import get_logger

# «Мягкий» импорт сервисов (ИИ-деградация: роутер не падает, если сервисов ещё нет)
try:
    from backend.app.services.referral_service import (
        admin_summary,               # async def admin_summary(db, limit, after) -> dict
        admin_manual_bonus,          # async def admin_manual_bonus(db, user_id, amount, reason, idempotency_key)
        admin_reassign_inviter,      # async def admin_reassign_inviter(db, invitee_user_id, new_inviter_user_id, *, note, idempotency_key=None)
    )
    _REF_SVC_AVAILABLE = True
except Exception:
    admin_summary = admin_manual_bonus = admin_reassign_inviter = None
    _REF_SVC_AVAILABLE = False

logger = get_logger(__name__)
router = APIRouter(prefix="/api/admin/referrals", tags=["admin:referrals"])

# -----------------------------------------------------------------------------
# Pydantic-схемы (локально, чтобы не тянуть ещё не готовые app/schemas/*)
# -----------------------------------------------------------------------------

class SummaryItem(BaseModel):
    inviter_user_id: int = Field(..., description="Пользователь-инвайтер")
    active_count: int = Field(..., ge=0, description="Количество активных рефералов (купили панель хотя бы раз)")
    inactive_count: int = Field(..., ge=0, description="Количество неактивных рефералов")
    total_bonus_efhc: constr(strip_whitespace=True) = Field(..., description="Сумма бонусов (EFHC, строкой c 8 знаками)")
    last_invited_at: Optional[datetime] = Field(None, description="Время последнего приглашения")

class SummaryResponse(BaseModel):
    items: List[SummaryItem]
    next_cursor: Optional[str] = None

class ManualBonusRequest(BaseModel):
    user_id: int = Field(..., description="Получатель бонуса (кому зачисляем на bonus_balance)")
    amount: constr(strip_whitespace=True) = Field(..., description="Сумма EFHC (строка), Decimal(30,8)")
    reason: Optional[str] = Field("referral_manual_bonus", description="Причина/мета для логов банка")

    @validator("amount")
    def _valid_amount(cls, v: str) -> str:
        amt = d8(v)
        if amt <= Decimal("0"):
            raise ValueError("Сумма должна быть > 0")
        return str(amt)

class ReassignRequest(BaseModel):
    invitee_user_id: int = Field(..., description="Кому переназначаем пригласившего")
    new_inviter_user_id: int = Field(..., description="Новый пригласивший")
    note: Optional[str] = Field(None, description="Опциональная служебная пометка")

# -----------------------------------------------------------------------------
# GET /api/admin/referrals/summary — витрина «топ инвайтеров»
# курсорная пагинация + ETag
# -----------------------------------------------------------------------------

@router.get("/summary", response_model=SummaryResponse, summary="Рефералы: админ-сводка (курсоры, ETag)")
async def get_summary(
    response: Response,
    limit: conint(ge=1, le=200) = 50,
    cursor: Optional[str] = None,
    _admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> SummaryResponse:
    """
    Что делает:
      • Возвращает агрегированную сводку по инвайтерам: активные/неактивные, сумма бонусов, время последнего приглашения.
      • Курсорная пагинация (без OFFSET): передаём `cursor` из прошлого ответа для следующей страницы.
      • Ставит ETag заголовок для кэша админки.

    Важно:
      • Это ТОЛЬКО чтение. Денежных операций нет. Все расчёты — в сервисе.
      • Если сервис временно недоступен — возвращаем 503, не ломая приложение.
    """
    if not _REF_SVC_AVAILABLE or admin_summary is None:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="referral_service недоступен, попробуйте позже")

    after: Dict[str, Any] = {}
    if cursor:
        try:
            after = decode_cursor(cursor)
        except Exception:
            # Некорректный курсор — 400
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Некорректный cursor")

    try:
        # Ожидаемый контракт сервиса:
        #   data = await admin_summary(db, limit=limit, after=after)
        #   -> {"items":[{...}], "next_after":{...} or None}
        data: Dict[str, Any] = await admin_summary(db, limit=limit, after=after)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_summary failed: %s", e)
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Временная ошибка сводки")

    items_in: List[Dict[str, Any]] = list(data.get("items") or [])
    items: List[SummaryItem] = []
    for it in items_in:
        items.append(
            SummaryItem(
                inviter_user_id=int(it["inviter_user_id"]),
                active_count=int(it.get("active_count", 0)),
                inactive_count=int(it.get("inactive_count", 0)),
                total_bonus_efhc=str(d8(it.get("total_bonus_efhc", "0"))),
                last_invited_at=it.get("last_invited_at"),
            )
        )

    next_after: Optional[Dict[str, Any]] = data.get("next_after")
    next_cursor: Optional[str] = encode_cursor(next_after) if next_after else None

    body = SummaryResponse(items=items, next_cursor=next_cursor)
    # ETag для кэша: строим по сериализованному телу
    try:
        response.headers["ETag"] = etag(body.dict())
    except Exception:
        # Если построить ETag не удалось, это не критично
        pass

    return body

# -----------------------------------------------------------------------------
# POST /api/admin/referrals/manual-bonus — денежная операция (строгая идемпотентность)
# -----------------------------------------------------------------------------

@router.post("/manual-bonus", status_code=status.HTTP_204_NO_CONTENT, summary="Рефералы: ручное бонусное начисление (Idempotency-Key)")
async def post_manual_bonus(
    payload: ManualBonusRequest,
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
    _admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    """
    Что делает:
      • Начисляет бонусные EFHC пользователю (на bonus_balance) от лица Банка.
      • Денежная операция → ОБЯЗАТЕЛЕН заголовок Idempotency-Key (канон).

    Вход:
      • payload.user_id (кому), payload.amount (строка Decimal(30,8)), payload.reason (опционально).
      • Idempotency-Key — строка, уникальная для запроса (например, UUID от клиента/админки).

    Побочные эффекты:
      • Зеркальная запись в банковском журнале (efhc_transfers_log), idempotency_key UNIQUE.
      • Баланс банка может уйти в минус (допустимо по канону), у пользователя — нет.

    Исключения:
      • 400 — отсутствует/пустой Idempotency-Key или недопустимая сумма.
      • 503 — referral_service временно недоступен/ошибка.
    """
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key обязателен для денежных операций",
        )

    if not _REF_SVC_AVAILABLE or admin_manual_bonus is None:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="referral_service недоступен, попробуйте позже")

    try:
        amt = d8(payload.amount)
        await admin_manual_bonus(
            db,
            user_id=int(payload.user_id),
            amount=amt,
            reason=payload.reason or "referral_manual_bonus",
            idempotency_key=idempotency_key.strip(),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_manual_bonus failed: %s", e)
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Временная ошибка начисления")

# -----------------------------------------------------------------------------
# POST /api/admin/referrals/reassign — переназначение пригласившего
# -----------------------------------------------------------------------------

@router.post("/reassign", status_code=status.HTTP_204_NO_CONTENT, summary="Рефералы: переназначить пригласившего")
async def post_reassign_inviter(
    payload: ReassignRequest,
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
    _admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
) -> None:
    """
    Что делает:
      • Переназначает пригласившего для указанного пользователя.
      • Денег не трогает. Idempotency-Key опционален (для защиты от повторов в UI).

    Вход:
      • invitee_user_id — у кого меняем пригласившего.
      • new_inviter_user_id — на кого меняем.
      • note — необязательная пометка.

    Защита:
      • Самопривлечение запрещено (invitee_user_id == new_inviter_user_id → 400).
      • Если сервис временно недоступен — 503.

    Побочные эффекты:
      • Логирование в таблицах рефералок/аудита (делает сервис).
    """
    if int(payload.invitee_user_id) == int(payload.new_inviter_user_id):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Self-invite запрещён")

    if not _REF_SVC_AVAILABLE or admin_reassign_inviter is None:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="referral_service недоступен, попробуйте позже")

    try:
        await admin_reassign_inviter(
            db,
            invitee_user_id=int(payload.invitee_user_id),
            new_inviter_user_id=int(payload.new_inviter_user_id),
            note=(payload.note or None),
            idempotency_key=(idempotency_key.strip() if idempotency_key else None),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("admin_reassign_inviter failed: %s", e)
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Временная ошибка переназначения")

# =============================================================================
# Пояснения «для чайника»:
#   • Этот модуль сам не изменяет балансы — все деньги проходят ТОЛЬКО через
#     сервисы и единый банковский сервис. Поэтому здесь нет SQL-логики денег.
#   • Для витрин: всегда используйте cursor-based пагинацию и ETag — это снижает
#     нагрузку и упрощает кэширование в админке.
#   • Для денежных POST: если в заголовке нет Idempotency-Key — сразу 400.
#     Повторная отправка с тем же ключом не должна дублировать операцию.
# =============================================================================
