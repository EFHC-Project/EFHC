# -*- coding: utf-8 -*-
# backend/app/deps.py
# =============================================================================
# EFHC Bot — Общие зависимости FastAPI: БД-сессия, идемпотентность, аутентификация,
#             админ-гейт, keyset-пагинация, ETag и точность Decimal.
# -----------------------------------------------------------------------------
# Канон/требования:
#   • Все денежные POST — строго с Idempotency-Key (или client_nonce).
#   • Списки — только cursor-based (keyset) пагинация.
#   • Источник истины для генерации — posекундные ставки (в сервисах; тут не считаем).
#   • Пользователь не может уходить в минус, Банк — может (проверки в сервисах/locks).
#
# Этот модуль НЕ делает бизнес-логику, только инфраструктуру/валидацию.
# =============================================================================

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, Optional, Tuple

from fastapi import Depends, Header, HTTPException, Query, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

logger = get_logger(__name__)
settings = get_settings()

# -----------------------------------------------------------------------------
# БД-сессия
# -----------------------------------------------------------------------------

# Ожидаем, что в backend/app/database.py определён async_session_maker (SQLAlchemy 2.0).
try:
    from backend.app.database import async_session_maker  # type: ignore
except Exception as e:  # мягкая деградация: лог и дальнейшая ошибка при вызове get_db
    async_session_maker = None  # type: ignore
    logger.error("deps.get_db: cannot import async_session_maker: %s", e)


async def get_db() -> AsyncSession:
    """
    Выдаёт AsyncSession для роутов/сервисов.
    • Роут/сервис сам решает — коммитить или нет (паттерн unit of work).
    • При исключении в стеке зависимостей — безопасный rollback().
    """
    if async_session_maker is None:
        # Явная и понятная ошибка на раннем этапе.
        raise HTTPException(status_code=500, detail="DB session factory is not initialized")

    async with async_session_maker() as session:  # type: ignore
        try:
            yield session
        except Exception:
            # На любой ошибке откатываем пользовательскую транзакцию,
            # чтобы не держать «грязную» сессию.
            await session.rollback()
            raise

# -----------------------------------------------------------------------------
# Точность Decimal и утилиты для UI/списков
# -----------------------------------------------------------------------------

EFHC_DECIMALS: int = int(getattr(settings, "EFHC_DECIMALS", 8) or 8)
Q8 = Decimal(1).scaleb(-EFHC_DECIMALS)

def d8(x: Any) -> Decimal:
    """Округление вниз до 8 знаков — строго по канону."""
    return Decimal(str(x)).quantize(Q8, rounding=ROUND_DOWN)

def make_etag(payload: Dict[str, Any]) -> str:
    """
    Делает детерминированный ETag из JSON-представления payload.
    Используется фронтом для «304 Not Modified».
    """
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def encode_cursor(ts: datetime, row_id: int) -> str:
    """
    Keyset-cursor b64(ts|id), где ts — unix-timestamp (UTC), id — целочисленный PK.
    """
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    blob = f"{int(ts.timestamp())}|{row_id}".encode("utf-8")
    return base64.urlsafe_b64encode(blob).decode("ascii")

def decode_cursor(cursor: str) -> Tuple[int, int]:
    """
    Инверсия encode_cursor: возвращает (ts_unix:int, row_id:int).
    Бросает HTTP 400 при некорректной строке.
    """
    try:
        raw = base64.urlsafe_b64decode(cursor.encode("ascii")).decode("utf-8")
        ts_str, id_str = raw.split("|", 1)
        return int(ts_str), int(id_str)
    except Exception:
        raise HTTPException(status_code=400, detail="Некорректный cursor")

# -----------------------------------------------------------------------------
# Идемпотентность денежных операций
# -----------------------------------------------------------------------------

def normalize_idempotency_key(raw: Optional[str]) -> str:
    """
    Нормализует произвольную строку пользователя в безопасный ключ.
    Удобно, когда client_nonce приходит в body — роут может сам вызвать эту функцию.
    """
    if not raw or not raw.strip():
        raise HTTPException(status_code=400, detail="Idempotency-Key (или client_nonce) обязателен")
    return hashlib.sha256(raw.strip().encode("utf-8")).hexdigest()

async def require_idempotency_key(
    idempotency_key: Optional[str] = Header(default=None, convert_underscores=False, alias="Idempotency-Key"),
    client_nonce: Optional[str] = Query(default=None, description="Альтернатива заголовку Idempotency-Key"),
) -> str:
    """
    Зависимость FastAPI: требует Idempotency-Key (заголовок) ИЛИ client_nonce (query).
    Возвращает нормализованный ключ (sha256 hex).
    Применять ТОЛЬКО для денежных POST (exchange, shop, tasks-claim, lotteries, withdraw, admin-ops).
    """
    raw = (idempotency_key or "").strip() or (client_nonce or "").strip()
    if not raw:
        raise HTTPException(status_code=400, detail="Idempotency-Key (или client_nonce) обязателен")
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return digest

async def require_idempotency_key_header_only(
    idempotency_key: Optional[str] = Header(default=None, convert_underscores=False, alias="Idempotency-Key"),
) -> str:
    """
    Вариант «строже»: разрешён ТОЛЬКО заголовок Idempotency-Key (без client_nonce).
    Включать там, где запрещены query/body-ноны (по вашей политике).
    """
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(status_code=400, detail="Idempotency-Key обязателен")
    return hashlib.sha256(idempotency_key.strip().encode("utf-8")).hexdigest()

# -----------------------------------------------------------------------------
# Аутентификация пользователя (auth-ready, с запасным контуром)
# -----------------------------------------------------------------------------

@dataclass
class AuthContext:
    user_id: int
    is_admin: bool = False

def _try_int(val: Any) -> Optional[int]:
    try:
        v = int(val)
        return v if v > 0 else None
    except Exception:
        return None

async def get_current_user_id(
    request: Request,
    user_id_q: Optional[int] = Query(default=None, alias="user_id", description="Резервный способ передать user_id"),
    x_user_id: Optional[int] = Header(default=None, alias="X-User-Id"),
) -> int:
    """
    Определяет user_id c приоритетами:
      1) Если middleware уже положил user_id в request.state.user_id (например, Telegram/JWT) — используем.
      2) Заголовок X-User-Id (fallback-режим).
      3) Квери-параметр ?user_id= (fallback-режим).
      4) Telegram WebApp initData (опционально, если security_core доступен).
    Если ничего не найдено — 401.
    """
    # 1) Middleware/авторизация уже проставила
    st_uid = getattr(request.state, "user_id", None)
    uid = _try_int(st_uid)
    if uid:
        return uid

    # 2) X-User-Id
    uid = _try_int(x_user_id)
    if uid:
        return uid

    # 3) ?user_id=
    uid = _try_int(user_id_q)
    if uid:
        return uid

    # 4) Telegram initData (если есть проверка в security_core)
    init_data = request.headers.get("X-Telegram-Init-Data")
    if init_data:
        try:
            from backend.app.core.security_core import verify_telegram_init_data  # type: ignore
            tg_uid = verify_telegram_init_data(init_data)  # ожидается int или None
            uid = _try_int(tg_uid)
            if uid:
                return uid
        except Exception as e:
            logger.warning("auth telegram init data verify failed: %s", e)

    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Требуется аутентификация")

# -----------------------------------------------------------------------------
# Админ-гейт (эмиссия/модерация и т.п.)
# -----------------------------------------------------------------------------

async def require_admin(
    request: Request,
    admin_id_header: Optional[int] = Header(default=None, alias="X-Admin-Id"),
    admin_token: Optional[str] = Header(default=None, alias="X-Admin-Token"),
    db: AsyncSession = Depends(get_db),
) -> AuthContext:
    """
    Пускает только администратора Банка EFHC.
    Канон: все админские операции должны идти от лица Банка (emission/adjust/burn).
    Правила:
      • Основная проверка — X-Admin-Id == ADMIN_BANK_TELEGRAM_ID (или ADMIN_TELEGRAM_ID).
      • Резервная — X-Admin-Token == settings.SECRET_KEY (например, для CI/внутренних задач).
      • Если middleware уже положил request.state.user_id и он совпадает с ADMIN_BANK_TELEGRAM_ID — ок.
      • Дополнительно (опционально) поддерживаем whitelist в БД: efhc_core.admin_nft_whitelist(telegram_id).
    """
    bank_admin_id = getattr(settings, "ADMIN_BANK_TELEGRAM_ID", None) or getattr(settings, "ADMIN_TELEGRAM_ID", None)
    bank_admin_id = _try_int(bank_admin_id)

    # 1) state.user_id (например, после JWT)
    st_uid = getattr(request.state, "user_id", None)
    if bank_admin_id and _try_int(st_uid) == bank_admin_id:
        return AuthContext(user_id=bank_admin_id, is_admin=True)

    # 2) X-Admin-Id заголовок
    if bank_admin_id and _try_int(admin_id_header) == bank_admin_id:
        return AuthContext(user_id=bank_admin_id, is_admin=True)

    # 3) Резервный токен (например, для внутреннего сервиса)
    secret = getattr(settings, "SECRET_KEY", None)
    if secret and admin_token and admin_token == secret and bank_admin_id:
        return AuthContext(user_id=bank_admin_id, is_admin=True)

    # 4) Опциональный whitelist в БД (не ломает канон, но помогает эксплуатации)
    try:
        from sqlalchemy import text as _text  # локальный импорт, чтобы не тянуть наверх
        row = await db.execute(_text("SELECT 1 FROM efhc_core.admin_nft_whitelist WHERE telegram_id = :tid LIMIT 1"),
                               {"tid": _try_int(admin_id_header) or _try_int(st_uid)})
        if row.fetchone():
            # Допускаем как администратора (например, «оператор» с NFT/whitelist-роллёй).
            # В этом режиме is_admin=True, но реальную политику операций ограничиваем на роутерах.
            return AuthContext(user_id=_try_int(admin_id_header) or _try_int(st_uid) or 0, is_admin=True)
    except Exception as e:
        # Не блокируем из-за ошибки БД — просто логируем и продолжаем строгой политикой
        logger.warning("admin whitelist check failed: %s", e)

    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Доступ только для администратора Банка EFHC")

# -----------------------------------------------------------------------------
# Health-проверка БД
# -----------------------------------------------------------------------------

async def db_ping(db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    try:
        from sqlalchemy import text as _text
        row = await db.execute(_text("SELECT 1"))
        ok = row.scalar_one_or_none() == 1
        return {"db": "ok" if ok else "fail"}
    except Exception as e:
        logger.error("db_ping error: %s", e)
        return {"db": "fail", "error": str(e)}

# =============================================================================
# Пояснения «для чайника»:
#   • get_db() — отдаёт AsyncSession; при ошибках — rollback, затем исключение.
#   • require_idempotency_key() — включайте как Depends во всех денежных POST.
#     Если клиент не может передать заголовок — используйте client_nonce в query,
#     или нормализуйте body-поле через normalize_idempotency_key().
#   • get_current_user_id() — готов к будущей Telegram/JWT-аутентификации,
#     но уже работает в fallback-режиме (X-User-Id / ?user_id= / initData).
#   • require_admin() — сверяет ADMIN_BANK_TELEGRAM_ID/ADMIN_TELEGRAM_ID, допускает
#     резервный X-Admin-Token == SECRET_KEY; опционально — whitelist в БД.
#   • encode_cursor()/decode_cursor() — единые helpers для keyset-пагинации списков.
#   • Никаких «суточных» ставок в этом файле нет и быть не должно.
# =============================================================================
