# -*- coding: utf-8 -*-
# backend/app/database.py
# =============================================================================
# Назначение кода:
# Единая инициализация БД с поддержкой двух вариантов окружения:
#   • PostgreSQL/Neon (asyncpg) — прод/стейдж;
#   • SQLite (aiosqlite) — локальная разработка и офлайн-тесты.
# Выбор делается по схеме в DATABASE_URL. В каждый момент активен ровно один драйвер.
#
# Канон / инварианты (важно):
# • Боевая БД — PostgreSQL. SQLite разрешён только как режим окружения (dev/offline).
# • Схема данных одна: settings.DB_SCHEMA_CORE. Для Postgres принудительно настраиваем search_path.
# • Миграции выполняет Alembic. Этот модуль схему не «рисует», только создаёт её при необходимости.
#
# ИИ-защиты:
# • Автодобавление ?sslmode=require для Postgres (Neon-friendly).
# • NullPool по умолчанию (серверлесс/локально) + pre_ping — устойчивость к разрывам.
# • Самовосстановление search_path/PRAGMA через connect-хуки.
#
# Запреты:
# • Одновременное использование нескольких СУБД в одном запуске запрещено.
# • Никаких «долгоживущих» транзакций в фоновых задачах; короткие сессии по фабрике.
# =============================================================================

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncIterator
from urllib.parse import urlparse, urlunparse, parse_qsl, urlencode

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

settings = get_settings()
logger = get_logger(__name__)

# -----------------------------------------------------------------------------
# Вспомогательные утилиты URL/детекции диалекта
# -----------------------------------------------------------------------------

def _ensure_sslmode_require(db_url: str) -> str:
    """Добавляем sslmode=require к Postgres-URL (Neon/облако). Для SQLite не применяется."""
    try:
        parsed = urlparse(db_url)
        if not parsed.scheme.startswith("postgres"):
            return db_url
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        query.setdefault("sslmode", "require")
        return urlunparse(parsed._replace(query=urlencode(query)))
    except Exception:
        logger.warning("DATABASE_URL parse failed; using raw URL (no ssl enforcement).")
        return db_url


def _dialect_name(db_url: str) -> str:
    """Возвращает 'postgresql' или 'sqlite' по схеме URL."""
    scheme = urlparse(db_url).scheme.lower()
    if scheme.startswith("postgres"):
        return "postgresql"
    if scheme.startswith("sqlite"):
        return "sqlite"
    # По канону — только эти два варианта. Любое иное значение считаем ошибкой конфигурации.
    raise RuntimeError(f"Unsupported DATABASE_URL scheme: {scheme}. Use postgresql+asyncpg or sqlite+aiosqlite.")


# -----------------------------------------------------------------------------
# Создание движка под конкретный диалект
# -----------------------------------------------------------------------------

def _build_engine() -> AsyncEngine:
    raw_url = settings.DATABASE_URL
    if not raw_url or not raw_url.strip():
        raise RuntimeError("DATABASE_URL is not set")

    dialect = _dialect_name(raw_url)

    if dialect == "postgresql":
        url = _ensure_sslmode_require(raw_url)
        engine = create_async_engine(
            url,
            echo=bool(getattr(settings, "DEBUG", False)),
            poolclass=NullPool,       # Neon/serverless — не держим лишних коннектов
            pool_pre_ping=True,       # здоровье соединения перед использованием
            future=True,
        )
        schema = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

        # На каждый connect выставляем search_path и UTC
        @event.listens_for(engine.sync_engine, "connect")
        def _pg_on_connect(dbapi_conn, connection_record):  # pragma: no cover
            try:
                with dbapi_conn.cursor() as cur:
                    cur.execute("SET TIME ZONE 'UTC'")
                    cur.execute(f"SET search_path TO {schema}")
            except Exception:
                # Не роняем создание движка — search_path продублируем в init_db()
                pass

        return engine

    # --- SQLite (dev/offline) ---
    # Важно: это режим окружения, а не боевая БД.
    engine = create_async_engine(
        raw_url,
        echo=bool(getattr(settings, "DEBUG", False)),
        poolclass=NullPool,
        future=True,
    )

    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_on_connect(dbapi_conn, connection_record):  # pragma: no cover
        try:
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys = ON")
            cur.execute("PRAGMA journal_mode = WAL")
            cur.execute("PRAGMA synchronous = NORMAL")
            cur.execute("PRAGMA busy_timeout = 5000")
            cur.close()
        except Exception:
            pass

    return engine


# -----------------------------------------------------------------------------
# Глобальные объекты доступа
# -----------------------------------------------------------------------------

async_engine: AsyncEngine = _build_engine()

async_session = async_sessionmaker(
    bind=async_engine,
    expire_on_commit=False,
    autoflush=False,
    class_=AsyncSession,
)

# Алиас для совместимости со старым кодом (роуты чаще используют deps.get_db,
# но местами могли ссылаться на database.get_db)
get_db = None  # переопределим ниже через get_session()


# -----------------------------------------------------------------------------
# Инициализация/health-check
# -----------------------------------------------------------------------------

async def init_db() -> None:
    """
    Инициализация при старте:
      • Для Postgres — CREATE SCHEMA IF NOT EXISTS и SET search_path.
      • Для SQLite — применяются PRAGMA в connect-хуке.
      • Быстрый ping SELECT 1.
    Миграции не выполняются (Alembic отдельно).
    """
    dialect = _dialect_name(settings.DATABASE_URL)
    if dialect == "postgresql":
        schema = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")
        async with async_engine.begin() as conn:
            await conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {schema}"))
            await conn.execute(text(f"SET search_path TO {schema}"))
            await conn.execute(text("SET TIME ZONE 'UTC'"))
    # ping
    await ping_db()


async def ping_db() -> None:
    """Лёгкий health-check соединения (SELECT 1)."""
    async with async_engine.connect() as conn:
        await conn.execute(text("SELECT 1"))


# -----------------------------------------------------------------------------
# Сессии: генератор/контекстник (короткие, безопасные)
# -----------------------------------------------------------------------------

@asynccontextmanager
async def session_scope(commit_on_exit: bool = True) -> AsyncIterator[AsyncSession]:
    """
    Контекстный менеджер «сессия как транзакция» для скриптов/шедулеров.
    Пример:
        async with session_scope() as db:
            await db.execute(...)
    """
    async with async_session() as session:
        try:
            yield session
            if commit_on_exit:
                await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_session() -> AsyncIterator[AsyncSession]:
    """
    Асинхронный генератор для FastAPI Depends / фоновых задач.
    По канону — короткая жизнь сессии на запрос/тик.
    """
    async with async_session() as session:
        yield session

# Совместимый алиас
get_db = get_session


# -----------------------------------------------------------------------------
# Служебные функции (если нужно узнать активный диалект в рантайме)
# -----------------------------------------------------------------------------

def current_dialect() -> str:
    """Возвращает 'postgresql' или 'sqlite' в текущем окружении."""
    return _dialect_name(settings.DATABASE_URL)


# -----------------------------------------------------------------------------
# Экспорт
# -----------------------------------------------------------------------------
__all__ = [
    "async_engine",
    "async_session",
    "init_db",
    "ping_db",
    "get_session",
    "get_db",
    "session_scope",
    "current_dialect",
]
# =============================================================================
# Пояснения «для чайника»:
# • В проде используйте PostgreSQL/Neon: DATABASE_URL должен быть вида
#     postgresql+asyncpg://user:pass@<host>.neon.tech/db?sslmode=require
#   Параметр sslmode=require добавляется автоматически, если его забыли.
# • В dev можно указать SQLite:
#     sqlite+aiosqlite:///./dev.db
#   Это удобно для быстрой локальной разработки без внешней БД.
# • Одновременно активен ТОЛЬКО один диалект (по URL). Код выше не «мешает» СУБД,
#   а позволяет выбирать окружение без переписывания приложения.
# • Миграции всегда выполняет Alembic в ту же БД/схему.
# =============================================================================
