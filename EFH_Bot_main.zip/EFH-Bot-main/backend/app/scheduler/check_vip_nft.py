# -*- coding: utf-8 -*-
# backend/app/scheduler/check_vip_nft.py
# =============================================================================
# Назначение кода:
# Периодическая проверка VIP-статуса пользователей по наличию NFT из канонической
# коллекции. Работает только в цикле каждые SCHEDULER_TICK_SECONDS (по канону: 600с).
#
# Канон / инварианты (важно):
#   • VIP-ставка определяется ТОЛЬКО фактом владения NFT из коллекции TON_NFT (env: VIP_NFT_COLLECTION).
#   • Никаких «суточных» расписаний — единый тик планировщика; решения по due/ретраям принимаются
#     сервисом (nft_requests_service) на основе статусов/next_retry_at.
#   • Денежных операций здесь нет (балансы не трогаем); меняется только флаг is_vip и журналы VIP-логов.
#
# ИИ-защиты:
#   • Самовосстановление: любые ошибки сети/БД не роняют цикл — пишем предупреждение и продолжаем.
#   • Короткие итеративные обработчики: обрабатываем партиями, пока есть «долги» по due-записям.
#   • Тайминги: уважаем SCHEDULER_TICK_SECONDS; при ошибке — мягкая пауза RETRY_ON_ERROR_SEC и следующий тик.
#
# Запреты:
#   • Никакой автодоставки/выпуска NFT — проверяем только факт владения внешним NFT.
#   • Никаких изменений денежных балансов/эмиссии EFHC — эта задача об этом не знает.
# =============================================================================

from __future__ import annotations

import asyncio
import time
from typing import Callable, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

# Сервис, который инкапсулирует всю бизнес-логику проверки NFT и flip is_vip.
# Он обязан уметь:
#   • находить «должников» по due/next_retry_at;
#   • проверять владение NFT по коллекции VIP_NFT_COLLECTION;
#   • переключать is_vip, писать VIP-логи и планировать next_retry_at;
#   • возвращать статистику обработки (processed/updated/left/...).
from backend.app.services import nft_requests_service

settings = get_settings()
logger = get_logger(__name__)

# Сколько спать при непредвиденной ошибке, чтобы не зациклить горячие ретраи
RETRY_ON_ERROR_SEC = 60

# Максимальный размер партии на один внутренний шаг; не «магия», а предохрана
DEFAULT_BATCH_LIMIT = 1000


# -----------------------------------------------------------------------------
# Внутренний помощник: один прогон обработки due-записей
# -----------------------------------------------------------------------------
async def run_check_vip_nft_once(
    db: AsyncSession,
    *,
    batch_limit: int = DEFAULT_BATCH_LIMIT,
    force: bool = False,
) -> dict:
    """
    Что делает:
      • Делегирует выборку due-пользователей и проверку NFT сервису nft_requests_service.
      • Возвращает агрегированную статистику по шагу (processed/updated/left/...).

    Вход:
      db           — AsyncSession (от внешнего планировщика).
      batch_limit  — размер партии на один внутренний шаг.
      force        — форсировать проверку (игнор due/next_retry_at), по умолчанию False.

    Выход:
      dict с ключами: processed, updated, left, errors, duration_ms (может быть больше полей —
      сервис решает, что отдавать; мы просто пробрасываем).

    Идемпотентность:
      • Обеспечивается самим сервисом: он должен уметь безопасно повторять проверку и
        переключение флага is_vip без гонок (например, через UPDATE ... WHERE ... и журналы).

    Исключения:
      • Любые исключения не «проглатываются» здесь — поднимаем вверх, чтобы внешний цикл
        применил стратегию самовосстановления (лог + пауза + следующий тик).
    """
    # Поддержка устойчивого публичного API сервиса: пробуем несколько канонических имен
    if hasattr(nft_requests_service, "refresh_vip_status_due_batch"):
        # Предпочтительное имя по канону
        return await nft_requests_service.refresh_vip_status_due_batch(
            db, limit=batch_limit, force=force
        )
    if hasattr(nft_requests_service, "refresh_vip_status_for_due_users"):
        return await nft_requests_service.refresh_vip_status_for_due_users(
            db, limit=batch_limit, force=force
        )
    if hasattr(nft_requests_service, "check_vip_nft_due_batch"):
        return await nft_requests_service.check_vip_nft_due_batch(
            db, limit=batch_limit, force=force
        )
    # Если ни одной ожидаемой функции нет — это ошибка интеграции
    raise RuntimeError(
        "nft_requests_service.* API не найден. Ожидались: "
        "refresh_vip_status_due_batch / refresh_vip_status_for_due_users / check_vip_nft_due_batch"
    )


# -----------------------------------------------------------------------------
# Публичный API задачи: «один тик» (используется внешним планировщиком-оркестратором)
# -----------------------------------------------------------------------------
async def scheduler_tick_check_vip_nft(db: AsyncSession) -> dict:
    """
    Что делает:
      • Обрабатывает due-записи батчами, пока сервис сообщает, что есть что обрабатывать.
      • Между батчами отдаёт управление циклу (await asyncio.sleep(0)), чтобы не монополизировать event loop.

    Вход:
      db — открытая AsyncSession (контекст жизни сессии контролирует вызывающий код).

    Выход:
      Сводная статистика тика: total_processed, total_updated, batches, last_step, took_ms.

    Исключения:
      • Пробрасывает ошибки вызывающему — внешняя «рамка» решает, что делать (лог+пауза).

    Замечание:
      • Денежных операций нет; только флаг is_vip и журналы VIP-статуса.
    """
    t0 = time.monotonic()
    total_processed = 0
    total_updated = 0
    batches = 0
    last_step: Optional[dict] = None

    while True:
        step = await run_check_vip_nft_once(db, batch_limit=DEFAULT_BATCH_LIMIT, force=False)
        last_step = step
        batches += 1

        processed = int(step.get("processed", 0))
        updated = int(step.get("updated", 0))
        total_processed += processed
        total_updated += updated

        # Если сервис сообщил, что больше нечего обрабатывать — выходим из внутреннего цикла
        left = int(step.get("left", 0))
        if processed <= 0 and left <= 0:
            break

        # Дать «подышать» event loop, чтобы не блокировать другие задачи
        await asyncio.sleep(0)

    took_ms = int((time.monotonic() - t0) * 1000)
    return {
        "total_processed": total_processed,
        "total_updated": total_updated,
        "batches": batches,
        "last_step": last_step or {},
        "took_ms": took_ms,
    }


# -----------------------------------------------------------------------------
# Фоновый цикл задачи (опционально): полноценный «ИИ-агент» с самовосстановлением
# -----------------------------------------------------------------------------
async def scheduler_task_check_vip_nft(
    session_factory: Callable[[], "AsyncSession"],
    stop_event: Optional[asyncio.Event] = None,
) -> None:
    """
    Что делает:
      • Запускает бесконечный цикл тиков с периодичностью SCHEDULER_TICK_SECONDS.
      • На каждом тике создаёт сессию БД, прогоняет обработку батчами, логирует метрики.
      • При ошибках — лог + мягкая пауза RETRY_ON_ERROR_SEC, затем следующий тик (самовосстановление).
      • Если передан stop_event и он выставлен — корректно завершается после текущего цикла сна.

    Вход:
      session_factory — callable без аргументов, который возвращает AsyncSession (например,
        functools.partial(async_sessionmaker, expire_on_commit=False)()).
      stop_event      — опционально, внешний сигнал на остановку.

    Выход:
      Нет (бесконечный цикл до stop_event).

    Идемпотентность:
      • Обеспечивается сервисом (идемпотентные апдейты/журналы), здесь — только оркестрация.

    Исключения:
      • Внутри тика перехватываются и логируются; задача не прекращается из-за временных ошибок.
    """
    tick_sec = int(settings.SCHEDULER_TICK_SECONDS) if settings.SCHEDULER_TICK_SECONDS else 600

    logger.info("VIP NFT checker started: tick=%ss, batch_limit=%s", tick_sec, DEFAULT_BATCH_LIMIT)

    while True:
        t_loop_start = time.monotonic()
        try:
            async with session_factory() as db:
                # Один «плотный» тик: обрабатываем due батчами
                stats = await scheduler_tick_check_vip_nft(db)
                await db.commit()
                logger.info(
                    "VIP NFT tick ok: processed=%s updated=%s batches=%s took=%sms",
                    stats.get("total_processed"),
                    stats.get("total_updated"),
                    stats.get("batches"),
                    stats.get("took_ms"),
                )
        except asyncio.CancelledError:
            logger.warning("VIP NFT checker cancelled — stopping gracefully.")
            break
        except Exception as e:
            # Самовосстановление: логируем и коротко ждём, затем следующий тик
            logger.warning("VIP NFT tick failed: %s", e, exc_info=settings.is_dev)
            await asyncio.sleep(RETRY_ON_ERROR_SEC)

        # Выдерживаем единый ритм тиков (не зацикливаем CPU, не спамим сеть)
        elapsed = time.monotonic() - t_loop_start
        sleep_for = max(1.0, tick_sec - elapsed)

        # Поддержка корректной остановки
        if stop_event is not None and stop_event.is_set():
            logger.info("VIP NFT checker stop requested — exiting.")
            break

        await asyncio.sleep(sleep_for)


__all__ = [
    "run_check_vip_nft_once",
    "scheduler_tick_check_vip_nft",
    "scheduler_task_check_vip_nft",
]

# =============================================================================
# Пояснения «для чайника»:
#   • Этот модуль НИЧЕГО не знает о балансовых операциях и деньгах — он только вызывает
#     сервис, который проверяет наличие NFT и переключает флаг is_vip у пользователей.
#   • Важно: мы не используем «календарные» расписания. Каждые 10 минут задача просыпается,
#     итерирует due-записи батчами, пока их не останется. Ошибки сети/БД не останавливают
#     процесс — фиксируется предупреждение и выполняется следующий тик.
#   • Как подключить к оркестратору:
#       from backend.app.database import async_session  # ваш sessionmaker
#       asyncio.create_task(scheduler_task_check_vip_nft(async_session, stop_event))
#     Где async_session — фабрика AsyncSession (например, sessionmaker(..., class_=AsyncSession)).
# =============================================================================
