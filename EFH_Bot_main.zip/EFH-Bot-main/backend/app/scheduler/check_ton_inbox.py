# -*- coding: utf-8 -*-
# backend/app/scheduler/check_ton_inbox.py
# =============================================================================
# Назначение кода:
#   Оркестратор входящих TON-платежей. Каждые 10 минут будит вотчер, читает
#   новые транзакции, «догоняет хвосты» по статусам логов и опционально делает
#   глубокую сверку за последние N часов. Никаких денежных действий сам не делает.
#
# Канон/инварианты:
#   • Все начисления EFHC выполняются только через единый банковский сервис
#     из watcher_service (read-through по tx_hash). Здесь — лишь orchestration.
#   • Идемпотентность обеспечена на уровне логов: UNIQUE(tx_hash) и повторная
#     обработка безопасна. MEMO: EFHC<tgid> / SKU:EFHC|Q:<INT>|TG:<id> /
#     SKU:NFT_VIP|Q:1|TG:<id> (NFT — только заявка PAID_PENDING_MANUAL).
#   • Время — триггер (10 минут), а не фильтр: обработка строится по статусам
#     и next_retry_at, а не «последние N минут».
#   • Банк может быть в минусе; операции не блокируются этим модулем.
#
# ИИ-защита/самовосстановление:
#   • Таймаут тика; advisory-lock в БД для защиты от параллельных запусков
#     между инстансами; локальный asyncio.Lock — от реэнтранса в процессе.
#   • Короткие ретраи: ошибки/таймауты не валят цикл — пишем лог и продолжаем.
#   • «Глубокая» сверка запускается периодически (страхует сетевые «дыры»).
#
# Запреты:
#   • Нет прямых изменений балансов/эмиссии. Нет авто-выдачи NFT.
#   • Нет суточных расчётов, только события TON. P2P запрещён.
# =============================================================================

from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, AsyncIterator, Callable, Dict, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.deps import get_db
from backend.app.services import watcher_service as watcher

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# -----------------------------------------------------------------------------
# Параметры тика/защиты (читаем из .env; безопасные значения по умолчанию)
# -----------------------------------------------------------------------------
INTERVAL_SEC: int        = int(getattr(settings, "CHECK_TON_INBOX_INTERVAL_SEC", 600) or 600)   # 10 минут
TASK_TIMEOUT_SEC: int    = int(getattr(settings, "CHECK_TON_INBOX_TIMEOUT_SEC", 900) or 900)    # 15 минут

TON_POLL_LIMIT: int      = int(getattr(settings, "TON_WATCHER_POLL_LIMIT", 200) or 200)
TON_RETRY_LIMIT: int     = int(getattr(settings, "TON_WATCHER_RETRY_LIMIT", 500) or 500)

# Раз в сколько тиков запускать «глубокую» сверку последних N часов
RECONCILE_EVERY_TICKS: int = int(getattr(settings, "TON_RECONCILE_EVERY_TICKS", 6) or 6)        # ~каждый час
RECONCILE_HOURS: int       = int(getattr(settings, "TON_RECONCILE_HOURS", 24) or 24)

# Advisory-lock ключи для этой задачи (два int, как требует PostgreSQL)
LOCK_KEY1: int = int(getattr(settings, "TON_INBOX_ADVISORY_KEY1", 0xEFHC) or 0xEFHC)
LOCK_KEY2: int = int(getattr(settings, "TON_INBOX_ADVISORY_KEY2", 0x01) or 0x01)

# Локальная защита от повторного входа в рамках одного процесса
_LOCAL_LOCK = asyncio.Lock()

# -----------------------------------------------------------------------------
# Вспомогательный контекст: получить AsyncSession из FastAPI-зависимости get_db()
# -----------------------------------------------------------------------------
@asynccontextmanager
async def _db_session_from_deps() -> AsyncIterator[AsyncSession]:
    """
    Открывает/закрывает AsyncSession аналогично FastAPI-зависимости get_db().
    Позволяет использовать этот планировщик и в фоне приложения.
    """
    agen = get_db()
    db = await agen.__anext__()
    try:
        yield db
    finally:
        try:
            await agen.aclose()
        except Exception:
            pass

# -----------------------------------------------------------------------------
# PostgreSQL advisory-lock: предотвращаем конкурентный запуск между инстансами
# -----------------------------------------------------------------------------
async def _try_acquire_advisory_lock(db: AsyncSession) -> bool:
    row = await db.execute(text("SELECT pg_try_advisory_lock(:k1, :k2)"), {"k1": LOCK_KEY1, "k2": LOCK_KEY2})
    got = row.scalar()
    return bool(got)

async def _release_advisory_lock(db: AsyncSession) -> None:
    try:
        await db.execute(text("SELECT pg_advisory_unlock(:k1, :k2)"), {"k1": LOCK_KEY1, "k2": LOCK_KEY2})
    except Exception:
        # Не критично: лок будет снят при закрытии сессии
        pass

# -----------------------------------------------------------------------------
# Логирование результата тиков в (опциональную) таблицу scheduler_task_log
# -----------------------------------------------------------------------------
def _json_dump_safe(obj: Any) -> str:
    try:
        import json
        return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    except Exception:
        return "{}"

async def _insert_scheduler_log(
    db: AsyncSession,
    *,
    status: str,
    error_text: Optional[str],
    duration_sec: float,
    stats: Dict[str, int],
) -> None:
    """
    Пишем запись о тике в efhc_core.scheduler_task_log, если таблица уже создана.
    Если таблицы ещё нет (первый запуск до миграций) — молча игнорируем.
    """
    try:
        await db.execute(
            text(
                f"""
                INSERT INTO {SCHEMA}.scheduler_task_log
                    (task_name, status, error_text, executed_at, duration_sec, meta, created_at, updated_at)
                VALUES
                    ('check_ton_inbox', :status, :error_text, NOW(), :dur, :meta::jsonb, NOW(), NOW())
                """
            ),
            {"status": status, "error_text": error_text, "dur": float(duration_sec), "meta": _json_dump_safe(stats)},
        )
    except Exception:
        pass

# -----------------------------------------------------------------------------
# Один тик задачи: новые входящие + догон «хвостов» + (опц.) глубокая сверка
# -----------------------------------------------------------------------------
@dataclass
class TickResult:
    stats: Dict[str, int]
    duration_sec: float
    status: str
    error_text: Optional[str] = None

async def run_tick(db: AsyncSession, *, do_reconcile: bool = False) -> TickResult:
    """
    Что делает:
      1) Получает новые входящие платежи из TON и передаёт их вотчеру (идемпотентно).
      2) Догоняет все логи с не финальными статусами и наступившим next_retry_at.
      3) (Опционально) выполняет «глубокую» сверку последних RECONCILE_HOURS часов.
    Возврат: TickResult со статистикой.
    Исключения наружу не выбрасывает — переводит в статус error/timeout и логирует.
    """
    start = time.perf_counter()
    stats: Dict[str, int] = {}
    try:
        # 1) Новые входящие (read-through по tx_hash)
        s1 = await watcher.process_incoming_payments(db, limit=TON_POLL_LIMIT, since_utime=None)
        stats["new_ok"] = sum(v for k, v in s1.items() if not k.startswith("error"))
        for k, v in s1.items():
            stats[f"new_{k}"] = stats.get(f"new_{k}", 0) + int(v)

        # 2) Догон хвостов (status!=final и next_retry_at<=now)
        s2 = await watcher.reprocess_unfinished_logs(db, limit=TON_RETRY_LIMIT)
        stats["retry_ok"] = sum(v for k, v in s2.items() if not k.startswith("error"))
        for k, v in s2.items():
            stats[f"retry_{k}"] = stats.get(f"retry_{k}", 0) + int(v)

        # 3) Глубокая сверка (страхует сетевые «дыры», задержки внешних API)
        if do_reconcile:
            s3 = await watcher.reconcile_last_hours(db, hours=RECONCILE_HOURS, limit=TON_POLL_LIMIT)
            stats["reconcile_ok"] = sum(v for k, v in s3.items() if not k.startswith("error"))
            for k, v in s3.items():
                stats[f"reconcile_{k}"] = stats.get(f"reconcile_{k}", 0) + int(v)

        dur = time.perf_counter() - start
        await _insert_scheduler_log(db, status="ok", error_text=None, duration_sec=dur, stats=stats)
        return TickResult(stats=stats, duration_sec=dur, status="ok")

    except asyncio.CancelledError:
        dur = time.perf_counter() - start
        await _insert_scheduler_log(db, status="cancelled", error_text=None, duration_sec=dur, stats=stats)
        return TickResult(stats=stats, duration_sec=dur, status="cancelled")

    except Exception as e:
        dur = time.perf_counter() - start
        msg = f"{e.__class__.__name__}: {e}"
        logger.exception("check_ton_inbox: tick failed: %s", msg)
        await _insert_scheduler_log(db, status="error", error_text=msg, duration_sec=dur, stats=stats)
        return TickResult(stats=stats, duration_sec=dur, status="error", error_text=msg)

# -----------------------------------------------------------------------------
# Бесконечный цикл (будильник каждые 10 минут, advisory-lock, таймаут тика)
# -----------------------------------------------------------------------------
async def run_forever(session_factory: Optional[Callable[[], AsyncIterator[AsyncSession]]] = None) -> None:
    """
    Главный цикл:
      • Каждые INTERVAL_SEC секунд выполняет один тик (run_tick) с таймаутом TASK_TIMEOUT_SEC.
      • Advisory-lock в БД защищает от параллельных запусков между инстансами.
      • Каждые RECONCILE_EVERY_TICKS — «глубокая» сверка.
    """
    tick_no = 0
    session_factory = session_factory or _db_session_from_deps

    while True:
        await asyncio.sleep(0)  # уступаем цикл событий
        tick_no += 1
        do_reconcile = (tick_no % RECONCILE_EVERY_TICKS == 0)

        async with _LOCAL_LOCK:  # защита от реэнтранса в этом процессе
            async with session_factory() as db:
                got_lock = False
                try:
                    got_lock = await _try_acquire_advisory_lock(db)
                    if not got_lock:
                        logger.info("check_ton_inbox: skip — another instance holds advisory lock")
                    else:
                        try:
                            res = await asyncio.wait_for(run_tick(db, do_reconcile=do_reconcile), timeout=TASK_TIMEOUT_SEC)
                            logger.info(
                                "check_ton_inbox: ok in %.2fs (stats=%s, reconcile=%s)",
                                res.duration_sec, res.stats, "yes" if do_reconcile else "no"
                            )
                        except asyncio.TimeoutError:
                            msg = f"tick timeout > {TASK_TIMEOUT_SEC}s"
                            logger.warning("check_ton_inbox: %s", msg)
                            await _insert_scheduler_log(
                                db, status="timeout_error", error_text=msg, duration_sec=float(TASK_TIMEOUT_SEC), stats={}
                            )
                finally:
                    if got_lock:
                        await _release_advisory_lock(db)

        # Пауза до следующего пробуждения (время — только триггер)
        try:
            await asyncio.sleep(INTERVAL_SEC)
        except asyncio.CancelledError:
            logger.info("check_ton_inbox: cancelled; stopping loop")
            break

# =============================================================================
# Пояснения «для чайника»:
#   • Этот модуль ничего не «начисляет» и не меняет балансы — он только будит
#     watcher_service, который идемпотентно обрабатывает входящие TON-события.
#   • Три шага тика: новые входящие, догон по статусам, периодическая сверка.
#   • Advisory-lock в БД исключает гонку между несколькими инстансами сервера.
#   • Любая ошибка или таймаут — это запись в лог и продолжение цикла; ручной
#     перезапуск не нужен. Система самовосстанавливается в следующем тике.
# =============================================================================
