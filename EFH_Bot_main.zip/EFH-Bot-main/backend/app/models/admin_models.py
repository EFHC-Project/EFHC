# backend/app/models/admin_models.py
# -*- coding: utf-8 -*-
"""
ORM-модели «админской» части EFHC Bot.

Идея файла (для чайника):
  • Это таблицы PostgreSQL, с которыми будет работать SQLAlchemy (через async engine).
  • Все таблицы живут в СХЕМЕ БД для админки (`settings.DB_SCHEMA_ADMIN`), чтобы не смешивать
    их с пользовательскими таблицами. Это удобно для миграций и бэкапов.
  • Здесь нет бизнес-логики — только структура таблиц и связи между ними.

Что здесь есть:
  1) AdminWhitelist — «белый список» администраторов (по Telegram ID и/или TON-адресу).
  2) AdminRole — роли админов (superadmin/admin/support/auditor). Один админ может иметь несколько ролей.
  3) AdminActionLog — аудит действий админов (кто/когда/что сделал; JSON-подробности).
  4) IdempotencyKey — ключи идемпотентности для безопасной обработки повторных запросов
     (используется ядром безопасности; удобно хранить в админской схеме).

Важно:
  • Модели используют типизированные аннотации SQLAlchemy 2.0 (Mapped[T], mapped_column).
  • Все временные метки — UTC, задаются на стороне БД (server_default timezone('utc', now())).
  • Валидируем TON-адреса «по-быстрому» (формат EQ/UQ и base64url) перед записью.
  • Поля и ограничения названы прозрачно, чтобы в логах/миграциях было легко ориентироваться.

Зависимости:
  • Требуется общий Declarative Base: `backend/app/models/__init__.py` должен предоставлять `Base`.
  • Этот файл использует глобальный объект `settings` из `core/config_core.py` для выбора схемы.
  • Миграции Alembic должны подключать `target_metadata` с общей метаданной `Base.metadata`.

Если `Base` не найден — значит нарушена структура проекта. Исправь `models/__init__.py`.
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import List, Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship, validates

try:
    # Единый Declarative Base для всех моделей проекта
    from . import Base  # type: ignore
except Exception as exc:  # pragma: no cover - это «жёсткая» зависимость
    # Явная подсказка, чтобы не терять время на поиски причины падения импорта
    raise ImportError(
        "Не найден общий Declarative Base. Проверь backend/app/models/__init__.py "
        "и убедись, что он экспортирует 'Base' (DeclarativeBase)."
    ) from exc

from ..core.config_core import settings  # единый источник конфигурации проекта


# -----------------------------------------------------------------------------
#                                ВСПОМОГАТЕЛЬНОЕ
# -----------------------------------------------------------------------------

ADMIN_SCHEMA = settings.DB_SCHEMA_ADMIN  # Схема БД для админских таблиц


class RoleEnum(str, enum.Enum):
    """
    Набор ролей администратора.

    • superadmin — полный доступ, назначает/снимает роли других админов.
    • admin      — основной функционал панели администратора.
    • support    — поддержка: просмотр и базовые операции, без финансового воздействия.
    • auditor    — только чтение (включая логирование действий других админов).
    """
    SUPERADMIN = "superadmin"
    ADMIN = "admin"
    SUPPORT = "support"
    AUDITOR = "auditor"


# =============================================================================
#                              МОДЕЛЬ: AdminWhitelist
# =============================================================================

class AdminWhitelist(Base):
    """
    «Белый список» администраторов.

    Логика (просто):
      • Админ определяется по Telegram ID (обязательно) и/или по TON-адресу (опционально).
      • Флаг is_active позволяет временно отключать админа без удаления записи.
      • Поле note — свободный комментарий (кто это, зачем доступ и т.п.).
      • added_by_telegram_id — кто именно добавил этого админа (аудит и ответственность).
      • Отдельная таблица AdminRole хранит набор ролей для каждого админа.

    Индексы/уникальности:
      • Каждый telegram_id в таблице уникален.
      • Тоже самое для ton_address (если указан).
      • Индекс по created_at для недорогой сортировки в аудитах/панели.
    """

    __tablename__ = "admin_whitelist"
    __table_args__ = (
        UniqueConstraint("telegram_id", name="uq_admin_whitelist_telegram"),
        UniqueConstraint("ton_address", name="uq_admin_whitelist_ton"),
        {"schema": ADMIN_SCHEMA},
    )

    # ---- Идентификатор записи ----
    id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True, comment="PK записи"
    )

    # ---- Идентификация администратора ----
    telegram_id: Mapped[int] = mapped_column(
        BigInteger,
        nullable=False,
        index=True,
        comment="Telegram ID администратора (уникален)",
    )
    ton_address: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        comment="TON-адрес администратора (user-friendly/Base64url)",
    )

    # ---- Атрибуты статуса ----
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("true"),
        comment="Статус: активен/заблокирован",
    )
    note: Mapped[Optional[str]] = mapped_column(
        String(255),
        nullable=True,
        comment="Комментарий: кто это и зачем доступ",
    )
    added_by_telegram_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        nullable=True,
        comment="Telegram ID того, кто добавил админа",
    )

    # ---- Временные метки ----
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда создан (UTC)",
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        onupdate=text("timezone('utc', now())"),
        comment="Когда обновлён (UTC)",
    )

    # ---- Связи ----
    roles: Mapped[List["AdminRole"]] = relationship(
        back_populates="admin",
        cascade="all, delete-orphan",
        passive_deletes=True,
        order_by="AdminRole.created_at.desc()",
        lazy="selectin",
        doc="Список ролей администратора",
    )
    action_logs: Mapped[List["AdminActionLog"]] = relationship(
        back_populates="admin",
        cascade="all, delete-orphan",
        passive_deletes=True,
        order_by="AdminActionLog.created_at.desc()",
        lazy="selectin",
        doc="История действий администратора",
    )

    __mapper_args__ = {"eager_defaults": True}

    # ---- Валидация входных данных ----
    @validates("ton_address")
    def _validate_ton_address(self, key: str, value: Optional[str]) -> Optional[str]:
        """
        Проверка TON-адреса перед записью.
        Правила:
          • None/пустую строку разрешаем (поле опционально).
          • Непустое значение должно походить на TON user-friendly адрес:
              — начинается с EQ/UQ,
              — base64url,
              — длина >= 48.
        """
        if value is None:
            return None
        val = value.strip()
        if not val:
            return None
        if not settings.is_valid_ton_address(val):
            raise ValueError("Некорректный TON-адрес в AdminWhitelist. Проверь формат EQ/UQ...")
        return val

    def __repr__(self) -> str:  # pragma: no cover - для удобства дебага
        return (
            f"<AdminWhitelist id={self.id} tgid={self.telegram_id} "
            f"active={self.is_active} ton={self.ton_address!r}>"
        )


# Индекс по дате создания — часто сортируем/фильтруем по свежести
Index(
    "ix_admin_whitelist_created_at",
    AdminWhitelist.created_at.desc(),
    schema=ADMIN_SCHEMA,
)


# =============================================================================
#                                МОДЕЛЬ: AdminRole
# =============================================================================

class AdminRole(Base):
    """
    Роль администратора.

    Зачем отдельная таблица:
      • Один админ может иметь сразу несколько ролей (многие-к-одному к AdminWhitelist).
      • Нужна история назначения ролей: кто выдал, когда выдал.
      • Удобно делать выборки (например, список всех с ролью support).

    Ограничения:
      • Пара (admin_id, role) — уникальна (одну и ту же роль нельзя повесить дважды).
    """

    __tablename__ = "admin_role"
    __table_args__ = (
        UniqueConstraint("admin_id", "role", name="uq_admin_role_pair"),
        {"schema": ADMIN_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True, comment="PK записи роли"
    )
    admin_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{ADMIN_SCHEMA}.admin_whitelist.id",
            ondelete="CASCADE",
            onupdate="CASCADE",
            name="fk_admin_role_admin",
        ),
        nullable=False,
        index=True,
        comment="FK → AdminWhitelist.id",
    )
    role: Mapped[RoleEnum] = mapped_column(
        Enum(RoleEnum, name="enum_admin_role", create_constraint=True),
        nullable=False,
        comment="Название роли",
    )
    granted_by_telegram_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        nullable=True,
        comment="Кто назначил (Telegram ID)",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда назначена роль (UTC)",
    )

    # Связь с админом
    admin: Mapped["AdminWhitelist"] = relationship(
        back_populates="roles",
        lazy="joined",
        doc="Владелец роли",
    )

    __mapper_args__ = {"eager_defaults": True}

    def __repr__(self) -> str:  # pragma: no cover
        return f"<AdminRole id={self.id} admin_id={self.admin_id} role={self.role}>"


Index(
    "ix_admin_role_created_at",
    AdminRole.created_at.desc(),
    schema=ADMIN_SCHEMA,
)


# =============================================================================
#                             МОДЕЛЬ: AdminActionLog
# =============================================================================

class AdminActionLog(Base):
    """
    Аудит действий администраторов.

    Зачем:
      • Прозрачность и разбор инцидентов: кто/когда/что сделал.
      • Уровень действий максимальный — без излишних ограничений, чтобы не терять информацию.

    Поля:
      • action        — короткое имя действия, например: 'create_item', 'ban_user', 'mint_efhc'.
      • target_type   — тип сущности: 'user', 'order', 'shop_item', 'nft_request', 'lottery', ...
      • target_id     — строковый идентификатор цели (ID, уникальный код, адрес и т.п.).
      • details_json  — JSON с дополнительными данными (до/после, диффы, параметры).
      • ip / user_agent — дополнительный контекст запроса, если он известен.

    Организация:
      • Логически «многие-к-одному» к AdminWhitelist.
      • Индексы по admin_id и created_at для частых фильтров в админ-панели.
    """

    __tablename__ = "admin_action_log"
    __table_args__ = (
        {"schema": ADMIN_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True, comment="PK записи лога"
    )

    admin_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{ADMIN_SCHEMA}.admin_whitelist.id",
            ondelete="SET NULL",
            onupdate="CASCADE",
            name="fk_admin_action_log_admin",
        ),
        nullable=True,
        index=True,
        comment="FK → AdminWhitelist.id (может быть NULL, если админа удалили)",
    )

    action: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        index=True,
        comment="Короткое имя действия ('ban_user', 'create_item', ...)",
    )
    target_type: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        index=True,
        comment="Тип цели ('user', 'order', 'shop_item', 'nft_request', ...)",
    )
    target_id: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        index=True,
        comment="Идентификатор цели (ID/код/адрес)",
    )

    details_json: Mapped[Optional[dict]] = mapped_column(
        JSONB,
        nullable=True,
        comment="Подробности действия в JSON (вход/выход, диффы и т.п.)",
    )

    ip: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        comment="IP-адрес источника (если известен)",
    )
    user_agent: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="User-Agent клиента (если известен)",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда зафиксировано действие (UTC)",
    )

    # Связь к администратору
    admin: Mapped[Optional["AdminWhitelist"]] = relationship(
        back_populates="action_logs",
        lazy="joined",
        doc="Связанный администратор (может быть None, если удалён)",
    )

    __mapper_args__ = {"eager_defaults": True}

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<AdminActionLog id={self.id} admin_id={self.admin_id} action={self.action} "
            f"target={self.target_type}:{self.target_id}>"
        )


# Индексы по частым фильтрам для панели
Index(
    "ix_admin_action_log_created_at",
    AdminActionLog.created_at.desc(),
    schema=ADMIN_SCHEMA,
)
Index(
    "ix_admin_action_log_action_type",
    AdminActionLog.action,
    AdminActionLog.target_type,
    schema=ADMIN_SCHEMA,
)


# =============================================================================
#                             МОДЕЛЬ: IdempotencyKey
# =============================================================================

class IdempotencyKey(Base):
    """
    Хранилище ключей идемпотентности.

    Сценарий:
      • Клиент (панель/бот) при опасной операции передаёт уникальный ключ (идемпотентный),
        и сервер гарантирует, что операция будет выполнена максимум один раз.
      • При повторном запросе с тем же ключом сервер либо возвращает тот же результат,
        либо сообщает, что ключ уже использован/просрочен.

    Поля:
      • key                    — уникальный строковый ключ (можно хранить хэш, если требуется).
      • scope                  — область применения (например, 'withdraw', 'shop_order').
      • request_fingerprint    — отпечаток запроса (хэш JSON-параметров) для проверки идентичности.
      • used                   — флаг, что ключ уже «сожжён».
      • response_code          — HTTP-код (или произвольный код результата) первой обработки.
      • response_payload_json  — JSON с фрагментом ответа (опционально, для возврата без повтора).
      • admin_id               — если ключ применяется из админ-панели, можно связать с админом.
      • created_at / expires_at — контроль времени жизни ключа.
    """

    __tablename__ = "idempotency_key"
    __table_args__ = (
        UniqueConstraint("key", name="uq_idempotency_key_key"),
        {"schema": ADMIN_SCHEMA},
    )

    id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True, comment="PK записи ключа"
    )

    key: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
        comment="Уникальный идемпотентный ключ (или его хэш)",
    )
    scope: Mapped[Optional[str]] = mapped_column(
        String(64),
        nullable=True,
        index=True,
        comment="Область применения ключа ('withdraw', 'shop_order', ...)",
    )
    request_fingerprint: Mapped[Optional[str]] = mapped_column(
        String(128),
        nullable=True,
        comment="Хэш входных данных запроса (для проверки идентичности)",
    )

    used: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("false"),
        index=True,
        comment="Признак, что ключ уже использован",
    )
    response_code: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        nullable=True,
        comment="Код результата первой обработки (например, HTTP-код)",
    )
    response_payload_json: Mapped[Optional[dict]] = mapped_column(
        JSONB,
        nullable=True,
        comment="Часть ответа первой обработки (если нужно вернуть без повтора)",
    )

    admin_id: Mapped[Optional[int]] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{ADMIN_SCHEMA}.admin_whitelist.id",
            ondelete="SET NULL",
            onupdate="CASCADE",
            name="fk_idempotency_key_admin",
        ),
        nullable=True,
        index=True,
        comment="FK → AdminWhitelist.id (если операция из админки)",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
        comment="Когда создан ключ (UTC)",
    )
    expires_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        index=True,
        comment="Когда ключ перестаёт быть валидным (UTC)",
    )

    __mapper_args__ = {"eager_defaults": True}

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<IdempotencyKey id={self.id} key={self.key} scope={self.scope} "
            f"used={self.used} admin_id={self.admin_id}>"
        )


Index(
    "ix_idempotency_key_expiry",
    IdempotencyKey.expires_at,
    schema=ADMIN_SCHEMA,
)
Index(
    "ix_idempotency_key_scope_used",
    IdempotencyKey.scope,
    IdempotencyKey.used,
    schema=ADMIN_SCHEMA,
)


# -----------------------------------------------------------------------------
#                                 ПУБЛИЧНЫЙ ЭКСПОРТ
# -----------------------------------------------------------------------------

__all__ = [
    "RoleEnum",
    "AdminWhitelist",
    "AdminRole",
    "AdminActionLog",
    "IdempotencyKey",
]
