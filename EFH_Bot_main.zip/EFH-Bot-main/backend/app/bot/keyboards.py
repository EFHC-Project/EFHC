# -*- coding: utf-8 -*-
# backend/app/bot/keyboards.py
# =============================================================================
# Назначение кода:
# Конструктор инлайн-клавиатур Telegram для EFHC Bot: кнопка WebApp, подписки
# на каналы, пагинация курсором, админ-модерация заявок по заданиям и общие
# URL/Callback-кнопки. Возвращает чистые dict-структуры Bot API (reply_markup).
#
# Канон/инварианты:
# • Денежных операций здесь НЕТ — только UI. Вся экономика выполняется сервисами.
# • Пагинация использует cursor (base64-safe) в callback-данных.
# • Callback-данные ограничены (~64 байта), есть авто-усечение и safety-префиксы.
#
# ИИ-защита/самовосстановление:
# • Все билдеры стойкие к пустым/невалидным параметрам — создают безопасный UI.
# • Автоматическое ограничение длины текста/данных, защита от Unicode-«мусора».
# • Fallback: если нет FRONTEND_URL — кнопка WebApp заменяется ссылкой на help.
#
# Запреты:
# • Не трогает БД, не меняет балансы, не вызывает банковский сервис.
# • Не делает автодоставок NFT/VIP — только визуальные кнопки.
# =============================================================================

from __future__ import annotations

import base64
import os
from typing import Iterable, List, Optional, Sequence, Tuple

# -----------------------------------------------------------------------------
# Константы и i18n
# -----------------------------------------------------------------------------

FRONTEND_URL = os.getenv("FRONTEND_URL", "").strip() or os.getenv("APP_URL", "").strip()

# Жёсткие лимиты Telegram
MAX_CB_DATA = 60          # безопаснее 60 (<64), чтобы не упираться в лимит.
MAX_BTN_TEXT = 64         # рекомендации Telegram: делаем мягкий предел по тексту.

# Префиксы callback-данных для маршрутизации в обработчике
CB_PAGINATION = "pg"      # пример: "pg:n:<cursor>" | "pg:p:<cursor>"
CB_TASK_MOD   = "admtsk"  # пример: "admtsk:ap:<id>" | "admtsk:rej:<id>"

I18N = {
    "ru": {
        "open_app": "Открыть приложение",
        "open": "Открыть",
        "subscribe": "Подписаться",
        "next": "Далее »",
        "prev": "« Назад",
        "help": "Помощь",
        "approve": "✅ Одобрить",
        "reject": "❌ Отклонить",
        "view": "👁 Посмотреть",
        "task": "Задание",
    },
    "en": {
        "open_app": "Open App",
        "open": "Open",
        "subscribe": "Subscribe",
        "next": "Next »",
        "prev": "« Prev",
        "help": "Help",
        "approve": "✅ Approve",
        "reject": "❌ Reject",
        "view": "👁 View",
        "task": "Task",
    },
}

# -----------------------------------------------------------------------------
# Вспомогательные утилиты (без внешних зависимостей)
# -----------------------------------------------------------------------------

def _t(lang: str, key: str) -> str:
    """Мини-i18n: безопасный доступ к строкам, ru по умолчанию."""
    d = I18N.get(lang or "ru") or I18N["ru"]
    return d.get(key, key)

def _safe_text(s: str, limit: int = MAX_BTN_TEXT) -> str:
    """Обрезает текст кнопки по мягкому лимиту, с многоточием при усечении."""
    if not s:
        return ""
    s = s.strip().replace("\n", " ")
    if len(s) <= limit:
        return s
    return s[: max(0, limit - 1)].rstrip() + "…"

def _safe_cb(data: str, prefix: str = "", limit: int = MAX_CB_DATA) -> str:
    """
    Обрезает callback-данные под лимит, добавляя префикс-маршрутизатор.
    Гарантирует отсутствие пробелов/переводов строки.
    """
    data = (data or "").replace(" ", "").replace("\n", "")
    if prefix:
        data = f"{prefix}:{data}"
    if len(data) <= limit:
        return data
    # Сжимаем хвост, чтобы сохранить префикс/тип
    head = data[: max(0, limit - 5)]
    tail_hash = base64.urlsafe_b64encode(data.encode("utf-8")).decode("ascii")[:4]
    return f"{head}:{tail_hash}"

def _b64_cursor(raw_cursor: str) -> str:
    """Курсор → компактный base64 (urlsafe), подходящий для callback."""
    if not raw_cursor:
        return ""
    b = base64.urlsafe_b64encode(raw_cursor.encode("utf-8")).decode("ascii")
    # Слегка укорачиваем (убираем паддинг '=') для компактности
    return b.rstrip("=")

def _rows(*btn_rows: Sequence[dict]) -> dict:
    """Формирует InlineKeyboardMarkup из заданных строк кнопок."""
    rows: List[List[dict]] = []
    for r in btn_rows:
        if not r:
            continue
        rows.append(list(r))
    return {"inline_keyboard": rows}

def _chunk(items: Sequence[dict], per_row: int) -> List[List[dict]]:
    """Разбивает список кнопок на строки по per_row элементов."""
    out: List[List[dict]] = []
    row: List[dict] = []
    for btn in items:
        row.append(btn)
        if len(row) >= per_row:
            out.append(row)
            row = []
    if row:
        out.append(row)
    return out

# -----------------------------------------------------------------------------
# Базовые кнопки
# -----------------------------------------------------------------------------

def btn_webapp(url: str, text: Optional[str] = None, lang: str = "ru") -> dict:
    """Кнопка для открытия WebApp."""
    label = _safe_text(text or _t(lang, "open_app"))
    return {"text": label, "web_app": {"url": url}}

def btn_url(text: str, url: str) -> dict:
    """Обычная URL-кнопка."""
    return {"text": _safe_text(text), "url": url}

def btn_cb(text: str, data: str) -> dict:
    """Callback-кнопка (обрезает text и data до безопасных лимитов)."""
    return {"text": _safe_text(text), "callback_data": _safe_cb(data)}

# -----------------------------------------------------------------------------
# Клавиатуры (билдеры)
# -----------------------------------------------------------------------------

def kb_open_app_or_help(lang: str = "ru") -> dict:
    """
    Минимальная клавиатура «Открыть приложение» или «Помощь» (если нет URL).
    """
    if FRONTEND_URL:
        return _rows([btn_webapp(FRONTEND_URL, _t(lang, "open_app"), lang)])
    return _rows([btn_url(_t(lang, "help"), "https://t.me/")])  # fallback

def kb_subscribe_channels(channels: Iterable[str], lang: str = "ru") -> dict:
    """
    Клавиатура с кнопками «Подписаться» на список каналов.
    Принимает формы: @name или https://t.me/name.
    """
    buttons: List[dict] = []
    for ch in channels or []:
        ch = (ch or "").strip()
        if not ch:
            continue
        url = ch
        if ch.startswith("@"):
            url = f"https://t.me/{ch[1:]}"
        elif not ch.startswith("http"):
            url = f"https://t.me/{ch}"
        buttons.append(btn_url(_t(lang, "subscribe"), url))
    # По 2-3 в строку (зависит от длины названия — оставим 2)
    return {"inline_keyboard": _chunk(buttons, per_row=2)}

def kb_pagination(*, next_cursor: Optional[str], prev_cursor: Optional[str], lang: str = "ru",
                  base: str = CB_PAGINATION) -> dict:
    """
    Клавиатура пагинации с «Назад/Далее». Курсоры кодируются base64-urlsafe.
    """
    btns: List[dict] = []
    if prev_cursor:
        cb = _safe_cb(f"p:{_b64_cursor(prev_cursor)}", prefix=base)
        btns.append(btn_cb(_t(lang, "prev"), cb))
    if next_cursor:
        cb = _safe_cb(f"n:{_b64_cursor(next_cursor)}", prefix=base)
        btns.append(btn_cb(_t(lang, "next"), cb))
    if not btns:
        return {"inline_keyboard": []}
    return _rows(btns)

def kb_task_moderation(task_id: int, lang: str = "ru") -> dict:
    """
    Админ-модерация заявки по заданию: Одобрить/Отклонить.
    callback_data: admtsk:ap:<id> | admtsk:rej:<id>
    """
    cb_ok  = _safe_cb(f"ap:{task_id}", prefix=CB_TASK_MOD)
    cb_rej = _safe_cb(f"rej:{task_id}", prefix=CB_TASK_MOD)
    return _rows(
        [btn_cb(_t(lang, "approve"), cb_ok), btn_cb(_t(lang, "reject"), cb_rej)]
    )

def kb_main_menu(*, webapp_url: Optional[str] = None, lang: str = "ru",
                 need_subscribe_for: Optional[Iterable[str]] = None,
                 add_view_task_id: Optional[int] = None) -> dict:
    """
    Универсальное стартовое меню:
      • Кнопка WebApp (если url есть), иначе — Help.
      • (Опц.) Кнопки «Подписаться» на каналы (если требуется).
      • (Опц.) Кнопка «Посмотреть задание» (callback).
    """
    rows: List[List[dict]] = []

    # WebApp/Help
    if webapp_url or FRONTEND_URL:
        rows.append([btn_webapp(webapp_url or FRONTEND_URL, _t(lang, "open_app"), lang)])
    else:
        rows.append([btn_url(_t(lang, "help"), "https://t.me/")])

    # Subscribe
    subs = list(need_subscribe_for or [])
    if subs:
        subs_kb = kb_subscribe_channels(subs, lang)
        rows.extend(subs_kb.get("inline_keyboard", []))

    # View task (пример для удобной навигации)
    if add_view_task_id is not None:
        cb = _safe_cb(f"v:{add_view_task_id}", prefix=CB_TASK_MOD)  # используем тот же неймспейс
        rows.append([btn_cb(f"{_t(lang, 'view')} {_t(lang, 'task')} #{add_view_task_id}", cb)])

    return {"inline_keyboard": rows}

# -----------------------------------------------------------------------------
# Пример сборки кастомной клавиатуры для «витрин» с пагинацией и WebApp
# -----------------------------------------------------------------------------

def kb_list_with_pagination(*, title_url_pairs: Sequence[Tuple[str, str]],
                            next_cursor: Optional[str],
                            prev_cursor: Optional[str],
                            webapp_url: Optional[str] = None,
                            lang: str = "ru") -> dict:
    """
    Список элементов (text→url) + пагинация + (опц.) кнопка WebApp.
    Удобно для витрин (магазин/лотереи/рефералы) при просмотре в Telegram.
    """
    rows: List[List[dict]] = []
    # Элементы списком, по одной кнопке в строке
    for title, url in title_url_pairs or []:
        rows.append([btn_url(_safe_text(title), url)])

    # Пагинация
    p = kb_pagination(next_cursor=next_cursor, prev_cursor=prev_cursor, lang=lang)
    if p.get("inline_keyboard"):
        rows.extend(p["inline_keyboard"])

    # WebApp
    if webapp_url or FRONTEND_URL:
        rows.append([btn_webapp(webapp_url or FRONTEND_URL, _t(lang, "open_app"), lang)])

    return {"inline_keyboard": rows}

# =============================================================================
# Пояснения «для чайника»:
# • Где используется?
#   В местах, где нужно быстро отдать пользователю/админу инлайн-клавиатуру:
#
#       from backend.app.bot.keyboards import (
#           kb_open_app_or_help, kb_subscribe_channels, kb_pagination,
#           kb_task_moderation, kb_main_menu, kb_list_with_pagination
#       )
#
#   Все функции возвращают dict вида {"inline_keyboard": [[...], ...]}, который
#   можно напрямую передать в sendMessage: {"reply_markup": <dict>}.
#
# • Безопасность и лимиты:
#   Telegram ограничивает длину callback_data (~64 байта). Мы используем MAX_CB_DATA=60
#   и авто-усечение _safe_cb(). Курсоры кодируем _b64_cursor() (urlsafe base64 без '=').
#
# • i18n:
#   Параметр lang ("ru"/"en") переключает подписи. Можно расширить словарь I18N.
#
# • Денежных действий здесь нет:
#   Клавиатуры — только визуальные. Любые списания/начисления выполняются в сервисах
#   (transactions_service.py и др.) и по защищённым маршрутам API.
# =============================================================================
