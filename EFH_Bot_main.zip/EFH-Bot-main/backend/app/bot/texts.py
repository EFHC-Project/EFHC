# -*- coding: utf-8 -*-
# backend/app/bot/texts.py
# =============================================================================
# Назначение кода:
# Централизованное хранилище и форматирование текстов Telegram-бота EFHC Bot
# (приветствие, подсказки, статусы, ошибки, уведомления). Предоставляет
# безопасные функции шаблонизации и i18n (RU как канон, с graceful-fallback).
#
# Канон/инварианты:
# • Никаких пересчётов экономики внутри текстов. Все суммы/кВт⋅ч приходят
#   из сервисов и округляются до 8 знаков (Decimal, округление вниз).
# • Канонические ставки генерации только посекундные:
#   GEN_PER_SEC_BASE_KWH и GEN_PER_SEC_VIP_KWH (берём из settings для вставок).
# • Банковская модель не затрагивается — модуль ТОЛЬКО форматирует строки.
#
# ИИ-защита:
# • Безопасное форматирование: пропуски плейсхолдеров не роняют бота (safe_format).
# • Защита от «плохих» юзернеймов (sanitize_username): обрезка длины, фильтр.
# • Фолбэки языка: lang → DEFAULT_LANGUAGE → 'ru'. Отсутствующий ключ не валит код.
# • Мягкая деградация при недоступности зависимостей (d8 из deps недоступен → локальный).
#
# Запреты:
# • НЕТ сторонних сетевых вызовов/БД, НЕТ логики балансов/транзакций.
# • НЕТ генерации «суточных» значений — только вставка уже подсчитанных данных.
# =============================================================================

from __future__ import annotations

from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, Mapping, Optional

# --- Конфиг/логгер: используем только лёгкие зависимости, без БД ----------------
try:
    from backend.app.core.config_core import get_settings
except Exception:  # pragma: no cover
    def get_settings():  # минимальный мок, если импорт недоступен при ранней загрузке
        class S:
            DEFAULT_LANGUAGE = "ru"
            GEN_PER_SEC_BASE_KWH = Decimal("0.00000692")
            GEN_PER_SEC_VIP_KWH = Decimal("0.00000741")
        return S()

try:
    from backend.app.core.logging_core import get_logger
except Exception:  # pragma: no cover
    import logging
    def get_logger(name: str):
        logging.basicConfig(level=logging.INFO)
        return logging.getLogger(name)

# d8 — единый канонический квантизатор
try:
    from backend.app.deps import d8  # централизованный помощник округления
except Exception:  # pragma: no cover
    def d8(x: Any) -> Decimal:
        q = Decimal(1).scaleb(-8)
        return Decimal(str(x)).quantize(q, rounding=ROUND_DOWN)

logger = get_logger(__name__)
settings = get_settings()

# =============================================================================
# УТИЛИТЫ БЕЗОПАСНОГО ФОРМАТИРОВАНИЯ
# =============================================================================

_Q8 = Decimal(1).scaleb(-8)

def fmt_amount_efhc(v: Any) -> str:
    """
    Возвращает строку Decimal/8 для EFHC/кВт⋅ч (округление вниз).
    Не роняет процесс при мусорных входных данных.
    """
    try:
        return str(d8(v))
    except Exception as e:  # pragma: no cover
        logger.warning("fmt_amount_efhc: fallback for value %r (%s)", v, e)
        return "0.00000000"

def sanitize_username(name: Optional[str], max_len: int = 32) -> str:
    """
    Приводит юзернейм к безопасному виду (без управляющих, ограниченная длина).
    Используется только для отрисовки текстов UI/бота.
    """
    if not name:
        return "—"
    s = "".join(ch for ch in name if " " <= ch <= "\uFFFF")
    s = s.strip()
    if len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s if s else "—"

def safe_format(template: str, **kwargs: Any) -> str:
    """
    Безопасный .format: незаполненные плейсхолдеры остаются как есть,
    исключения не «роняют» ответ пользователю.
    """
    class SafeDict(dict):
        def __missing__(self, key):  # placeholder остаётся нетронутым
            return "{" + key + "}"
    try:
        return template.format_map(SafeDict(kwargs))
    except Exception as e:  # pragma: no cover
        logger.warning("safe_format: error on %r with %r: %s", template, kwargs, e)
        return template

# =============================================================================
# ТЕКСТОВЫЕ ШАБЛОНЫ (i18n, RU — канон)
# Ключи плоские, группировка — через точки (section.key)
# =============================================================================

TEXTS: Dict[str, Dict[str, str]] = {
    "ru": {
        # --- приветствия/помощь
        "welcome": (
            "Привет, {username}! ⚡\n"
            "Это EFHC Bot — симулятор чистой энергии и учёт {efhc}=кВт·ч.\n"
            "Ваш статус: {vip_flag}\n"
            "Панелей: {panels}, доступно к обмену: {avail_kwh} кВт·ч."
        ),
        "help": (
            "Помощь:\n"
            "• Панели генерируют энергию посекундно.\n"
            "• Обмен kWh→EFHC строго 1:1 (обратного обмена нет).\n"
            "• VIP ставка: {gen_vip}/сек, обычная: {gen_base}/сек.\n"
            "• Вывод возможен только в EFHC (Jetton в TON)."
        ),
        # --- профиль
        "profile.header": "👤 Профиль {username}",
        "profile.lines": (
            "VIP: {vip_flag}\n"
            "EFHC (основной): {main}\n"
            "EFHC (бонусы): {bonus}\n"
            "Энергия: доступно {avail_kwh} • всего {total_kwh}"
        ),
        # --- панели
        "panels.summary": (
            "🔋 Панели: {active_count} активных\n"
            "Ближайшее окончание: {nearest_expire}\n"
            "Суммарная генерация панелей: {generated}"
        ),
        # --- обмен
        "exchange.preview": (
            "🔄 Обмен энергии на EFHC\n"
            "Доступно: {avail_kwh} кВт·ч • Макс. к обмену сейчас: {max_kwh}\n"
            "Курс: 1 кВт·ч → 1 EFHC"
        ),
        "exchange.ok": "✅ Обмен выполнен: {kwh} кВт·ч → {efhc} EFHC",
        "exchange.blocked.user_negative": (
            "⛔ Обмен временно недоступен: у вас исторический минус. "
            "Пополните баланс или закройте минус обменом энергии."
        ),
        # --- магазин
        "shop.order.accepted": (
            "🧾 Заказ принят: {sku}\n"
            "Сумма: {amount}\n"
            "Оплатите по инструкции. Доставка EFHC/NFT будет произведена автоматически/вручную по канону."
        ),
        "shop.nft.manual": (
            "🎟️ Заявка на NFT VIP создана. Администратор обработает вручную.\n"
            "Статус: PAID_PENDING_MANUAL"
        ),
        # --- TON / депозит
        "ton.deposit.detected": (
            "💠 Получен депозит: {amount} EFHC (по MEMO {memo}). Средства зачислены."
        ),
        "ton.deposit.unknown": (
            "ℹ️ Обнаружен платёж без привязки (MEMO: {memo}). "
            "Если это ваш депозит EFHC, привяжите кошелёк или используйте формат MEMO."
        ),
        # --- VIP
        "vip.is_active": "🌟 VIP активен (генерация {gen_vip}/сек).",
        "vip.not_active": "⭐ VIP не активен (генерация {gen_base}/сек).",
        # --- рейтинг
        "rating.me": "🏆 Ваше место: {pos}. Всего сгенерировано: {total_kwh} кВт·ч.",
        "rating.top.header": "TOP-{n} (без дублирования «Я»):",
        "rating.top.line": "#{pos} • {username} — {total_kwh} кВт·ч",
        # --- рефералы
        "referrals.header": "👥 Рефералы",
        "referrals.active.count": "Активных: {count}",
        "referrals.inactive.count": "Неактивных: {count}",
        # --- вывод
        "withdraw.created": (
            "📤 Заявка на вывод создана: {amount} EFHC → {address}\n"
            "Статус: PENDING. Идемпотентный ключ: {idk}"
        ),
        "withdraw.paid": "✅ Выплата совершена. Tx: {tx_hash}",
        "withdraw.rejected": "⛔ Заявка отклонена: {reason}",
        "withdraw.blocked.user_negative": (
            "⛔ Нельзя создать заявку: у вас минус по пользователю. "
            "Закройте минус пополнением или обменом энергии."
        ),
        # --- задачи/бонусы
        "tasks.submitted": "📝 Заявка на выполнение отправлена. Статус: UNDER_REVIEW.",
        "tasks.approved": "✅ Выполнение принято. Начислено: {bonus} бонус-EFHC.",
        # --- общее/ошибки
        "error.network": "⚠️ Сетевая ошибка. Повторим попытку автоматически.",
        "error.idempotency.required": "⛔ Требуется заголовок Idempotency-Key для денежных операций.",
        "error.try_later": "⏳ Попробуйте позже — задача на повтор уже поставлена.",
        "sync.forced": "🔁 Принудительная синхронизация выполнена ({section}).",
    },
    # Пример EN/UА — укороченные шаблоны (основной язык — RU).
    "en": {
        "welcome": "Hi, {username}! EFHC Bot is ready. VIP: {vip_flag}, Panels: {panels}, Avail: {avail_kwh} kWh.",
        "error.network": "Network error. We'll retry automatically.",
    },
    "ua": {
        "welcome": "Вітаю, {username}! EFHC Bot готовий. VIP: {vip_flag}, Панелей: {panels}, Доступно: {avail_kwh} кВт·год.",
        "error.network": "Помилка мережі. Спробуємо ще раз автоматично.",
    },
}

# =============================================================================
# I18N: извлечение строк с фолбэками
# =============================================================================

def _lang_chain(lang: Optional[str]) -> tuple[str, str, str]:
    """Формирует последовательность фолбэков языка: lang→DEFAULT→ru."""
    default_lang = getattr(settings, "DEFAULT_LANGUAGE", "ru") or "ru"
    lang1 = (lang or "").strip().lower() or default_lang
    return (lang1, default_lang, "ru")

def t(key: str, lang: Optional[str] = None, **kwargs: Any) -> str:
    """
    Извлекает текст по ключу с фолбэками языка и безопасной подстановкой.
    Пример: t("welcome", lang="ru", username="@user", vip_flag="ON", ...)
    """
    for l in _lang_chain(lang):
        bundle = TEXTS.get(l, {})
        if key in bundle:
            return safe_format(bundle[key], **kwargs)
    logger.debug("texts: missing key %r for langs=%r", key, _lang_chain(lang))
    return key  # отдаём ключ, чтобы не молчать

# =============================================================================
# ВЫСОКОУРОВНЕВЫЕ КОНСТРУКТОРЫ СООБЩЕНИЙ (готовые шаблоны для бота)
# =============================================================================

def make_welcome_text(
    username: Optional[str],
    panels: int,
    avail_kwh: Any,
    is_vip: bool,
    lang: Optional[str] = None,
) -> str:
    """
    Текст приветствия с краткой сводкой.
    Все суммы приводятся к Decimal/8 строке.
    """
    vip_flag = "ON" if is_vip else "OFF"
    return t(
        "welcome",
        lang=lang,
        username=sanitize_username(username),
        efhc="1 EFHC",
        vip_flag=vip_flag,
        panels=panels,
        avail_kwh=fmt_amount_efhc(avail_kwh),
    )

def make_help_text(lang: Optional[str] = None) -> str:
    """Краткая справка с подстановкой канонических ставок/сек."""
    return t(
        "help",
        lang=lang,
        gen_base=str(d8(getattr(settings, "GEN_PER_SEC_BASE_KWH", Decimal("0.00000692")))),
        gen_vip=str(d8(getattr(settings, "GEN_PER_SEC_VIP_KWH",  Decimal("0.00000741")))),
    )

def make_profile_text(
    username: Optional[str],
    is_vip: bool,
    main_balance: Any,
    bonus_balance: Any,
    avail_kwh: Any,
    total_kwh: Any,
    lang: Optional[str] = None,
) -> str:
    """
    Отрисовка «Профиля» в два блока: заголовок + значения.
    """
    head = t("profile.header", lang=lang, username=sanitize_username(username))
    body = t(
        "profile.lines",
        lang=lang,
        vip_flag=("ON" if is_vip else "OFF"),
        main=fmt_amount_efhc(main_balance),
        bonus=fmt_amount_efhc(bonus_balance),
        avail_kwh=fmt_amount_efhc(avail_kwh),
        total_kwh=fmt_amount_efhc(total_kwh),
    )
    return f"{head}\n{body}"

def make_panels_summary_text(
    active_count: int,
    nearest_expire: Optional[str],
    total_generated_by_panels: Any,
    lang: Optional[str] = None,
) -> str:
    """Короткая сводка по панелям для чата."""
    return t(
        "panels.summary",
        lang=lang,
        active_count=active_count,
        nearest_expire=(nearest_expire or "—"),
        generated=fmt_amount_efhc(total_generated_by_panels),
    )

def make_exchange_preview_text(
    avail_kwh: Any,
    max_exchangeable_kwh: Any,
    lang: Optional[str] = None,
) -> str:
    """Предпросмотр обмена kWh→EFHC (без списаний)."""
    return t(
        "exchange.preview",
        lang=lang,
        avail_kwh=fmt_amount_efhc(avail_kwh),
        max_kwh=fmt_amount_efhc(max_exchangeable_kwh),
    )

def make_exchange_ok_text(kwh: Any, efhc: Any, lang: Optional[str] = None) -> str:
    """Подтверждение успешного обмена."""
    return t(
        "exchange.ok",
        lang=lang,
        kwh=fmt_amount_efhc(kwh),
        efhc=fmt_amount_efhc(efhc),
    )

def make_vip_text(is_vip: bool, lang: Optional[str] = None) -> str:
    """Текущая ставка генерации для пользователя."""
    if is_vip:
        return t(
            "vip.is_active",
            lang=lang,
            gen_vip=str(d8(getattr(settings, "GEN_PER_SEC_VIP_KWH", Decimal("0.00000741")))),
        )
    return t(
        "vip.not_active",
        lang=lang,
        gen_base=str(d8(getattr(settings, "GEN_PER_SEC_BASE_KWH", Decimal("0.00000692")))),
    )

def make_rating_me_text(position: int, total_kwh: Any, lang: Optional[str] = None) -> str:
    """Строка «моё место в рейтинге»."""
    return t(
        "rating.me",
        lang=lang,
        pos=position,
        total_kwh=fmt_amount_efhc(total_kwh),
    )

def make_rating_top_block(
    items: list[dict],
    top_n: int,
    lang: Optional[str] = None,
) -> str:
    """
    Формирует блок TOP-N (items — массив {pos, username, total_kwh}).
    Предполагается, что «Я» уже исключён из списка сервисом.
    """
    header = t("rating.top.header", lang=lang, n=top_n)
    lines = []
    for it in items:
        lines.append(
            t(
                "rating.top.line",
                lang=lang,
                pos=it.get("pos", "?"),
                username=sanitize_username(it.get("username")),
                total_kwh=fmt_amount_efhc(it.get("total_kwh", "0")),
            )
        )
    return header + ("\n" + "\n".join(lines) if lines else "\n—")

def make_withdraw_created_text(amount: Any, address: str, idk: str, lang: Optional[str] = None) -> str:
    """Подтверждение создания заявки на вывод."""
    return t(
        "withdraw.created",
        lang=lang,
        amount=fmt_amount_efhc(amount),
        address=address,
        idk=idk,
    )

def make_withdraw_paid_text(tx_hash: str, lang: Optional[str] = None) -> str:
    """Подтверждение выплаты."""
    return t("withdraw.paid", lang=lang, tx_hash=tx_hash)

def make_withdraw_rejected_text(reason: str, lang: Optional[str] = None) -> str:
    """Отказ по заявке на вывод."""
    return t("withdraw.rejected", lang=lang, reason=reason or "—")

def make_sync_forced(section: str, lang: Optional[str] = None) -> str:
    """Сообщение о принудительной синхронизации данных при открытии экрана."""
    return t("sync.forced", lang=lang, section=section)

# =============================================================================
# Пояснения «для чайника»:
# • Этот модуль НИЧЕГО не считает и НИЧЕГО не меняет в БД — только собирает строки.
# • Все денежные/энергетические значения должны приходить уже из сервисов.
# • Если ключа/языка нет — сработает фолбэк, бот не упадёт (safe_format + lang chain).
# • Для корректности UI используйте готовые фабрики make_* — в них встроена
#   квантизация Decimal/8 и фильтрация username.
# • Добавляя новые тексты, придерживайтесь плоских ключей ("section.key")
#   и не забывайте про RU как канон, EN/UA — по мере необходимости.
# =============================================================================
