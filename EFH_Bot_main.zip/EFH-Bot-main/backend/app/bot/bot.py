# -*- coding: utf-8 -*-
# backend/app/bot/bot.py
# =============================================================================
# Назначение кода:
# Телеграм-бот EFHC Bot (Webhook-обработчик без сторонних фреймворков).
# Обеспечивает: установку вебхука, приём update, разбор /start (в т.ч. реферал),
# безопасные ответы (sendMessage), проверку подписки в канале (getChatMember),
# и мягкую идемпотентность по update_id (таблица tg_updates_log, IF NOT EXISTS).
#
# Канон/инварианты:
# • Денежных операций здесь НЕТ. Любая экономика идёт через банковский сервис.
# • Никаких P2P, никаких автодоставок NFT. Только «общение» и запуск WebApp.
# • Идемпотентность: update_id фиксируется в tg_updates_log (UNIQUE).
# • Self-heal: автосоздание таблицы логов, ретраи сетевых вызовов, fallback HTTP.
#
# ИИ-защита/самовосстановление:
# • ensure_webhook(): проверяет/ставит вебхук при старте (несколько попыток).
# • send_message()/get_chat_member(): ретраи с экспоненциальной паузой.
# • process_update(): безопасный парсер; некритичные ошибки не «роняют» цикл.
#
# Запреты:
# • Не изменяет балансы, не инициирует денежные списания/начисления.
# • Не делает автоподтверждений NFT/VIP — только делегирует соответствующим сервисам.
# =============================================================================

from __future__ import annotations

import asyncio
import base64
import json
import os
import random
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

# Конфиг/логгер проекта
from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

# (Опционально) сервис рефералов — используем, если доступен
try:
    from backend.app.services.referral_service import register_referral_link
except Exception:  # pragma: no cover — мягкая деградация, если модуль ещё не готов
    register_referral_link = None

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# -----------------------------------------------------------------------------
# HTTP-клиент: пытаемся использовать httpx; если нет — fallback на urllib
# -----------------------------------------------------------------------------
_httpx = None
try:  # предпочтительно async httpx
    import httpx as _httpx  # type: ignore
except Exception:
    _httpx = None
    import urllib.request  # type: ignore
    import urllib.error  # type: ignore

# -----------------------------------------------------------------------------
# Конфигурация бота (из .env)
# -----------------------------------------------------------------------------
BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "").strip() or getattr(settings, "TELEGRAM_BOT_TOKEN", "")
BOT_API_BASE = f"https://api.telegram.org/bot{BOT_TOKEN}"
WEBHOOK_URL: str = os.getenv("WEBHOOK_URL", "").strip() or getattr(settings, "WEBHOOK_URL", "")
BOT_USERNAME: str = os.getenv("BOT_USERNAME", "").strip() or getattr(settings, "BOT_USERNAME", "EnergySolarGameBot")
FRONTEND_URL: str = os.getenv("FRONTEND_URL", "").strip() or getattr(settings, "FRONTEND_URL", "")
APP_URL: str = os.getenv("APP_URL", "").strip() or getattr(settings, "APP_URL", "")

# Каналы для проверки подписки (по задачам/рекламе). Админ может расширять список.
# Поддерживается форма: @channel_name или числовой chat_id (как строка).
REQUIRED_CHANNELS_CSV = os.getenv("REQUIRED_CHANNELS", "").strip()
REQUIRED_CHANNELS = [c.strip() for c in REQUIRED_CHANNELS_CSV.split(",") if c.strip()] if REQUIRED_CHANNELS_CSV else []

# Ограничитель повторов для сетевых вызовов
DEFAULT_RETRY_ATTEMPTS = 4
DEFAULT_RETRY_BASE_SEC = 0.6  # экспоненциальная пауза 0.6, 1.2, 2.4, ...

# -----------------------------------------------------------------------------
# DDL для мягкой идемпотентности по update_id (без ломки миграций)
# -----------------------------------------------------------------------------
SQL_ENSURE_TG_LOG = f"""
CREATE TABLE IF NOT EXISTS {SCHEMA}.tg_updates_log (
    update_id BIGINT PRIMARY KEY,
    processed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""

# -----------------------------------------------------------------------------
# DTO
# -----------------------------------------------------------------------------

@dataclass
class BotReply:
    chat_id: int
    text: str
    webapp_url: Optional[str] = None  # если хотим выдать кнопку «Открыть приложение»


# =============================================================================
# Публичный API модуля
# =============================================================================

async def ensure_bot_ready(db: AsyncSession) -> None:
    """
    Подготавливает бота: создаёт таблицу tg_updates_log и ставит вебхук.
    Вызывать при старте приложения.
    """
    _ensure_env()  # ранняя проверка токена/URL — логируем, но не «роняем» сервис

    # 1) Таблица идемпотентности update
    await db.execute(text(SQL_ENSURE_TG_LOG))
    await db.commit()

    # 2) Установка вебхука
    await ensure_webhook()


async def ensure_webhook() -> None:
    """
    Проверяет/устанавливает webhook. Несколько попыток с экспоненциальной паузой.
    """
    if not BOT_TOKEN or not WEBHOOK_URL:
        logger.error("bot.ensure_webhook: TELEGRAM_BOT_TOKEN/WEBHOOK_URL не сконфигурированы.")
        return

    payload = {"url": WEBHOOK_URL, "drop_pending_updates": False, "allowed_updates": ["message", "chat_member"]}
    ok = await _tg_call("setWebhook", payload, retry=True)
    if ok and ok.get("ok"):
        logger.info("bot.ensure_webhook: webhook set to %s", WEBHOOK_URL)
    else:
        logger.warning("bot.ensure_webhook: cannot set webhook: %s", ok)


async def process_update(db: AsyncSession, update: Dict[str, Any]) -> None:
    """
    Главная точка входа для обработчика вебхука.
    Делает:
      • идемпотентную фильтрацию по update_id;
      • разбор /start (+реферал);
      • проверку подписки (при необходимости);
      • дружелюбные ответы пользователю.
    """
    # --- идемпотентность по update_id ----------------------------------------
    update_id = _extract_update_id(update)
    if update_id is None:
        logger.debug("bot.process_update: update без update_id, пропущено.")
        return
    if not await _mark_update_once(db, update_id):
        # повтор — уже обработан
        logger.debug("bot.process_update: duplicate update_id=%s ignored", update_id)
        return

    # --- разбор типа апдейта -------------------------------------------------
    message = update.get("message") or {}
    chat_member = update.get("chat_member") or {}

    try:
        if message:
            await _handle_message(db, message)
        elif chat_member:
            # Можно собирать телеметрию о join/leave каналов — пока только лог
            logger.info("bot.process_update: chat_member update received (ignored for now).")
        else:
            logger.debug("bot.process_update: unsupported update shape.")
    except Exception as e:
        logger.exception("bot.process_update: unhandled error: %s", e)


# =============================================================================
# Обработчики сообщений
# =============================================================================

async def _handle_message(db: AsyncSession, message: Dict[str, Any]) -> None:
    chat_id = _get_in(message, "chat.id", int, default=None)
    user_id = _get_in(message, "from.id", int, default=None)
    text = _get_in(message, "text", str, default="").strip()

    if not chat_id or not user_id:
        logger.debug("bot._handle_message: no chat_id/user_id; skip.")
        return

    if text.startswith("/start"):
        # deep-link payload (например: /start ref=12345)
        payload = ""
        parts = text.split(maxsplit=1)
        if len(parts) == 2:
            payload = parts[1].strip()

        # 1) Реферальная метка (опционально)
        await _maybe_register_referral(db, payload=payload, invitee_tg_id=user_id)

        # 2) Проверка подписок (если включено): предупреждаем, но не блокируем
        not_member = await _check_required_channels(user_id=user_id)
        warn_note = ""
        if not_member:
            warn_note = "\n\n⚠️ Для участия в заданиях/рекламе подпишитесь: " + ", ".join(not_member)

        # 3) Кнопка «Открыть приложение» (WebApp)
        btn_url = _compose_webapp_url(user_id=user_id, payload=payload)
        await _reply(BotReply(
            chat_id=chat_id,
            text=(
                "Привет! Это EFHC Bot — веб-приложение учёта энергии и обмена на EFHC.\n"
                "Нажми кнопку, чтобы открыть WebApp и продолжить."
                f"{warn_note}"
            ),
            webapp_url=btn_url
        ))
        return

    # Прочее: простая справка
    if text in {"/help", "help", "помощь"}:
        await _reply(BotReply(
            chat_id=chat_id,
            text=(
                "Команды:\n"
                "• /start — открыть приложение и активировать реферальную метку (если есть)\n"
                "• /help — эта справка\n\n"
                "Все финансовые операции выполняются ТОЛЬКО внутри приложения."
            )
        ))
        return

    # По умолчанию — дружелюбный ответ
    await _reply(BotReply(
        chat_id=chat_id,
        text="Открой приложение — там есть всё необходимое. Используй команду /start."
    ))


# =============================================================================
# Рефералы (мягкая интеграция)
# =============================================================================

async def _maybe_register_referral(db: AsyncSession, *, payload: str, invitee_tg_id: int) -> None:
    """
    Поддерживаем простую схему: /start ref=<tg_id_реферера>
    Если сервис рефералов доступен — регистрируем; ошибки не роняют поток.
    """
    try:
        ref_id = _parse_ref_from_payload(payload)
        if not ref_id:
            return
        if register_referral_link is None:
            logger.info("bot.referral: referral_service ещё не подключён, пропуск.")
            return
        if ref_id == invitee_tg_id:
            logger.info("bot.referral: self-ref ignored (tg_id=%s).", invitee_tg_id)
            return
        await register_referral_link(db, referrer_tg_id=ref_id, invitee_tg_id=invitee_tg_id)
        logger.info("bot.referral: registered ref=%s -> invitee=%s", ref_id, invitee_tg_id)
    except Exception as e:
        logger.warning("bot.referral: failed to register referral: %s", e)


def _parse_ref_from_payload(payload: str) -> Optional[int]:
    """
    Поддерживаем несколько форм:
      • 'ref=12345'
      • 'r12345' (краткая форма)
      • base64('ref=12345')
    """
    if not payload:
        return None
    s = payload.strip()

    # base64?
    try:
        if s.endswith("="):
            decoded = base64.urlsafe_b64decode(s.encode("ascii")).decode("utf-8", "ignore")
            s = decoded.strip()
    except Exception:
        pass

    if s.startswith("ref="):
        try:
            return int(s.split("=", 1)[1])
        except Exception:
            return None
    if s.startswith("r") and s[1:].isdigit():
        try:
            return int(s[1:])
        except Exception:
            return None
    return None


# =============================================================================
# Проверка подписки в каналах (для задач/рекламы)
# =============================================================================

async def _check_required_channels(*, user_id: int) -> list[str]:
    """
    Возвращает список каналов, в которых пользователь НЕ состоит (по данным Telegram).
    Если список пуст — всё хорошо. Ошибки сети не блокируют поток; в таком случае
    считаем, что проверка не пройдена (возвращаем все каналы как «не подтверждены»),
    но только ДОБАВЛЯЕМ предупреждение в приветствии — ничего не ломаем.
    """
    if not REQUIRED_CHANNELS:
        return []

    not_member: list[str] = []
    for channel in REQUIRED_CHANNELS:
        try:
            is_mem = await is_user_member(channel, user_id)
            if not is_mem:
                not_member.append(channel)
        except Exception as e:
            logger.warning("bot.check_channels: can't verify %s for %s: %s", channel, user_id, e)
            # в режиме «жить любой ценой» добавим как непрошедший
            not_member.append(channel)
    return not_member


async def is_user_member(chat_id_or_username: str, user_id: int) -> bool:
    """
    Вызывает getChatMember. Возвращает True, если статус участника «member/admin/creator».
    """
    if not BOT_TOKEN:
        return False
    payload = {"chat_id": chat_id_or_username, "user_id": int(user_id)}
    resp = await _tg_call("getChatMember", payload, retry=True)
    if not resp or not resp.get("ok"):
        return False
    result = resp.get("result", {}) or {}
    status = result.get("status")
    return status in {"member", "administrator", "creator"}


# =============================================================================
# Ответ пользователю
# =============================================================================

def _compose_webapp_url(*, user_id: int, payload: str) -> str:
    """
    Формирует ссылку на WebApp (FRONTEND_URL) с добавлением UTM/реф-метки.
    """
    base = FRONTEND_URL or APP_URL or "https://example.com"
    qs = []
    if user_id:
        qs.append(f"tg={user_id}")
    if payload:
        qs.append(f"start={payload}")
    return base + (("?" + "&".join(qs)) if qs else "")


async def _reply(reply: BotReply) -> None:
    """
    Удобная обёртка для отправки сообщения. При наличии webapp_url добавляем
    кнопу «Открыть приложение».
    """
    if not BOT_TOKEN:
        logger.error("bot._reply: TELEGRAM_BOT_TOKEN не задан.")
        return

    reply_markup = None
    if reply.webapp_url:
        # Клавиатура с одной кнопкой «Открыть приложение»
        reply_markup = {
            "inline_keyboard": [[{"text": "Открыть приложение", "web_app": {"url": reply.webapp_url}}]]
        }

    payload = {
        "chat_id": int(reply.chat_id),
        "text": reply.text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup

    resp = await _tg_call("sendMessage", payload, retry=True)
    if not resp or not resp.get("ok"):
        logger.warning("bot._reply: sendMessage failed: %s", resp)


# =============================================================================
# DB идемпотентность по update_id
# =============================================================================

async def _mark_update_once(db: AsyncSession, update_id: int) -> bool:
    """
    Возвращает True, если update_id встречен впервые (и помечен).
    Возвращает False, если уже есть в tg_updates_log.
    """
    try:
        await db.execute(text(SQL_ENSURE_TG_LOG))
        await db.execute(
            text(
                f"""
                INSERT INTO {SCHEMA}.tg_updates_log (update_id) VALUES (:uid)
                ON CONFLICT (update_id) DO NOTHING
                """
            ),
            {"uid": int(update_id)},
        )
        await db.commit()

        # проверяем, действительно вставилось?
        row = await db.execute(
            text(f"SELECT 1 FROM {SCHEMA}.tg_updates_log WHERE update_id = :uid"),
            {"uid": int(update_id)},
        )
        found = row.fetchone()
        return bool(found)
    except Exception as e:
        # На всякий случай не «роняем» апдейт, но логируем.
        logger.warning("bot._mark_update_once: DB issue, fallback to process anyway: %s", e)
        return True  # лучше обработать, чем потерять


def _extract_update_id(update: Dict[str, Any]) -> Optional[int]:
    """
    Извлекает update_id из корневого объекта Telegram update.
    """
    try:
        val = update.get("update_id")
        if isinstance(val, int):
            return val
        if isinstance(val, str) and val.isdigit():
            return int(val)
    except Exception:
        pass
    return None


# =============================================================================
# Низкоуровневые вызовы Telegram Bot API + ретраи
# =============================================================================

async def _tg_call(method: str, payload: Dict[str, Any], *, retry: bool = False) -> Dict[str, Any]:
    """
    Вызов Telegram Bot API. Если есть httpx — используем асинхронный клиент,
    иначе делаем синхронный fallback через urllib в отдельном потоке.
    retry=True включает экспоненциальные ретраи (до DEFAULT_RETRY_ATTEMPTS).
    """
    url = f"{BOT_API_BASE}/{method}"
    attempts = DEFAULT_RETRY_ATTEMPTS if retry else 1
    delay = DEFAULT_RETRY_BASE_SEC

    for attempt in range(1, attempts + 1):
        try:
            if _httpx:
                async with _httpx.AsyncClient(timeout=20.0) as client:
                    r = await client.post(url, json=payload)
                    r.raise_for_status()
                    return r.json()
            else:
                # sync fallback (urllib) — исполняем в thread pool
                def _sync_call() -> Dict[str, Any]:
                    req = urllib.request.Request(
                        url,
                        data=json.dumps(payload).encode("utf-8"),
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with urllib.request.urlopen(req, timeout=20) as resp:
                        return json.loads(resp.read().decode("utf-8"))
                return await asyncio.to_thread(_sync_call)
        except Exception as e:
            if attempt >= attempts:
                logger.warning("bot._tg_call: method=%s failed after %s attempts: %s", method, attempts, e)
                return {}
            # экспоненциальная пауза с небольшим джиттером
            jitter = random.uniform(0, 0.2)
            await asyncio.sleep(delay + jitter)
            delay *= 2

    return {}


def _ensure_env() -> None:
    """
    Лог-аудит критичных переменных окружения.
    """
    if not BOT_TOKEN:
        logger.error("bot.env: TELEGRAM_BOT_TOKEN is empty — бот не сможет отвечать.")
    if not WEBHOOK_URL:
        logger.warning("bot.env: WEBHOOK_URL пуст — setWebhook будет пропущен.")
    if not FRONTEND_URL and not APP_URL:
        logger.warning("bot.env: нет FRONTEND_URL/APP_URL — кнопка WebApp будет вести на example.com")


# =============================================================================
# Пояснения «для чайника»:
# • Где вебхук?
#   Вы регистрируете HTTP-роут FastAPI (например, POST /webhook), получаете raw update
#   (JSON dict), сессии БД (AsyncSession) и вызываете:
#
#       from backend.app.bot.bot import process_update, ensure_bot_ready
#
#   В on_startup → await ensure_bot_ready(db)        # ставим вебхук, создаём tg_updates_log
#   В обработчике → await process_update(db, update) # парсим апдейт и отвечаем
#
# • Проверка подписки:
#   Укажите переменную окружения REQUIRED_CHANNELS=@your_channel,@another_channel
#   Бот спросит getChatMember и, если пользователь не состоит, добавит предупреждение
#   в приветствии (ничего не ломая). Это нужно для задач/рекламных кампаний.
#
# • Рефералы:
#   /start ref=<tg_id> или /start r12345 или base64('ref=12345'). Если сервис
#   referral_service подключён, запись будет создана. Сам модуль не делает выплат.
#
# • Идемпотентность:
#   tg_updates_log гарантирует, что один и тот же update_id не будет обработан повторно
#   даже при повторной доставке Telegram. Если БД недоступна — мы предпочитаем
#   обработать апдейт (лучше ответить, чем молчать) и зафиксировать проблему в логах.
# =============================================================================
