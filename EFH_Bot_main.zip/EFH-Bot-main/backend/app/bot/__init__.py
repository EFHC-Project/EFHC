# -*- coding: utf-8 -*-
# backend/app/bot/__init__.py
# =============================================================================
# Назначение кода:
# Агрегатор Telegram-бота EFHC Bot. Даёт единый импорт для подсистем бота:
#   from backend.app.bot import bot, keyboards, middlewares, states, texts
#
# Канон / инварианты:
# • Здесь нет сетевых вызовов и запуска long-polling/webhook — только импорт модулей.
# • Пакет должен быть «самолечащимся»: отсутствие части модулей не роняет сервис.
# • Никакой бизнес-логики балансов/денег — только сборка интерфейсных слоёв бота.
#
# ИИ-защиты / самовосстановление:
# • «Мягкие» импорты с логированием: если модуль временно отсутствует, код не падает.
# • Диагностика состояния пакета (ensure_bot_package_sane) и повторная инициализация
#   (ai_recover_imports) без рестарта процесса — для живучести при частичных сбоях.
#
# Запреты:
# • Запуск бота, сетевые соединения, доступ к БД — не здесь.
# • Никаких «TODO/потом». Этот модуль только агрегирует и валидирует окружение.
# =============================================================================

from __future__ import annotations

from importlib import import_module
from typing import Dict, List, Tuple

try:
    # Предпочитаем штатный логгер проекта
    from backend.app.core.logging_core import get_logger
    _log = get_logger(__name__)
except Exception:  # pragma: no cover
    # Фолбэк-логгер (на случай ранней инициализации)
    class _StubLogger:
        def info(self, *a, **k):  # noqa: D401
            """print-fallback info"""
            try:
                print("[bot:init][info]", *a)
            except Exception:
                pass

        def warning(self, *a, **k):
            try:
                print("[bot:init][warn]", *a)
            except Exception:
                pass

        def error(self, *a, **k):
            try:
                print("[bot:init][error]", *a)
            except Exception:
                pass

    _log = _StubLogger()  # type: ignore


# Версия интерфейсного пакета бота (для healthcheck/диагностики)
BOT_PKG_VERSION: str = "v1.0"

# Карта «псевдоним -> полный путь модуля»
_MODULES: Dict[str, str] = {
    "bot": "backend.app.bot.bot",
    "keyboards": "backend.app.bot.keyboards",
    "middlewares": "backend.app.bot.middlewares",
    "states": "backend.app.bot.states",
    "texts": "backend.app.bot.texts",
}

# Реестр успешно импортированных модулей: name -> (module_path, module_obj)
_registry: Dict[str, Tuple[str, object]] = {}

# Публичные символы пакета
__all__: List[str] = [
    "BOT_PKG_VERSION",
    "get_public_bot_exports",
    "ensure_bot_package_sane",
    "ai_recover_imports",
    # ниже заполним реальными модулями (bot, keyboards, …) по мере импорта
]


def _soft_import(alias: str, module_path: str) -> None:
    """
    «Мягкий» импорт подмодуля бота с логированием, без падения сервиса.

    Правила:
      • Успех -> модуль доступен как backend.app.bot.<alias>
      • Неуспех -> логируем warning и продолжаем (самолечение: часть API всё ещё жива)
    """
    if alias in _registry:
        # Уже импортирован ранее — пропускаем
        return
    try:
        mod = import_module(module_path)
        globals()[alias] = mod
        _registry[alias] = (module_path, mod)
        if alias not in __all__:
            __all__.append(alias)
        _log.info("Импортирован модуль бота: %s (%s)", alias, module_path)
    except Exception as e:  # pragma: no cover
        _log.warning("Модуль бота недоступен: %s (%s) — %s", alias, module_path, e)


# Выполняем мягкие импорты всех объявленных подмодулей
for _alias, _path in _MODULES.items():
    _soft_import(_alias, _path)


def get_public_bot_exports() -> Dict[str, object]:
    """
    Диагностика: возвращает словарь публичных экспортов бота и метаданные версии.

    Пример ответа:
    {
      "version": "v1.0",
      "exports": ["bot", "keyboards", "middlewares", "states", "texts"],
      "loaded": {"bot": "backend.app.bot.bot", ...},
      "missing": ["middlewares"]  # если не загрузился
    }
    """
    loaded = {k: v[0] for k, v in _registry.items()}
    expected = set(_MODULES.keys())
    present = set(loaded.keys())
    missing = sorted(expected - present)
    return {
        "version": BOT_PKG_VERSION,
        "exports": sorted([n for n in __all__ if n in expected]),
        "loaded": loaded,
        "missing": missing,
    }


def ai_recover_imports() -> Dict[str, object]:
    """
    ИИ-самовосстановление: пытается переимпортировать отсутствующие модули,
    не затрагивая уже загруженные. Удобно вызывать после «горячей» правки кода.
    """
    recovered: List[str] = []
    for alias, path in _MODULES.items():
        if alias not in _registry:
            _soft_import(alias, path)
            if alias in _registry:
                recovered.append(alias)
    info = get_public_bot_exports()
    if recovered:
        _log.info("Переинициализация модулей бота: восстановлены %s", recovered)
    else:
        _log.info("Переинициализация модулей бота: не требовалась")
    return info


def ensure_bot_package_sane(strict: bool = False) -> bool:
    """
    Быстрая проверка целостности пакета бота.
    • Проверяет присутствие ключевых модулей (bot, keyboards, states, texts).
    • В strict=True требует также middlewares.

    Возвращает True/False. В режиме strict при проблемах логирует error.
    """
    required = {"bot", "keyboards", "states", "texts"}
    if strict:
        required.add("middlewares")

    present = set(_registry.keys())
    missing = required - present
    if missing:
        msg = f"Не хватает модулей бота: {sorted(missing)}"
        if strict:
            _log.error(msg)
        else:
            _log.warning(msg)
        return False
    return True


# =============================================================================
# Пояснения «для чайника»:
# • Для чего этот файл?
#   Чтобы любой код мог импортировать интерфейс бота из одной точки:
#       from backend.app.bot import bot, keyboards, states
#   и не заботиться о порядке импортов и частичных сбоях.
#
# • Что делать, если после обновления кода модуль «пропал»?
#   Вызовите ai_recover_imports() — он переимпортирует отсутствующие части без рестарта.
#
# • Как убедиться, что пакет готов к работе?
#   ensure_bot_package_sane(strict=True) — вернёт False и залогирует ошибку, если не всё загружено.
#
# • Где старт бота, вебхуки и т.п.?
#   Внутри backend/app/bot/bot.py. Здесь мы ничего не запускаем — только агрегируем модули.
# =============================================================================
