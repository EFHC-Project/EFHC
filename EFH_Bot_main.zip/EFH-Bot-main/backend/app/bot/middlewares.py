# -*- coding: utf-8 -*-
# backend/app/bot/middlewares.py
# =============================================================================
# Назначение кода:
# Набор «средних слоёв» (middlewares) для Telegram-бота EFHC, которые
# оборачивают хэндлеры и добавляют ИИ-защиту: дедупликацию апдейтов,
# антиспам/лимитирование запросов, проверку админ-прав, строгость
# идемпотентности (Idempotency Key) для «денежных» действий, безопасное
# логирование и авто-деградацию при ошибках.
#
# Канон/инварианты:
# • Денежные операции выполняются не здесь, а в сервисах («единый банк»).
# • Любые «money-flows» должны быть идемпотентны; для бот-callback'ов
#   допускаем проверку nonce/idk в данных коллбэка.
# • Пользователь никогда не уходит в минус; админ (банк) может.
#
# ИИ-защита / самовосстановление:
# • Дедупликация по update_id (TTL-кэш), чтобы не обрабатывать одно и то же
#   событие при повторной доставке Telegram.
# • Токен-бакет на пользователя: «смягчённое» антиспам-ограничение; при
#   перегрузе — мягкий отказ и продолжение работы бота.
# • Обёртка-охранник tg_guard: перехватывает исключения, пишет логи, не «роняет»
#   процесс, отдаёт пользователю дружелюбные сообщения, если доступна функция
#   отправки (api.send_message).
#
# Запреты:
# • Нет запросов к БД и никакой экономики в этом модуле.
# • Нет прямых вызовов TON/NFT — только инфраструктурные проверки апдейта.
# =============================================================================

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

logger = get_logger(__name__)
settings = get_settings()

# =============================================================================
# Вспомогательные структуры и утилиты
# =============================================================================

@dataclass
class UpdateView:
    """Безопасная «проекция» Telegram update (минимум того, что нам нужно)."""
    update_id: Optional[int]
    user_id: Optional[int]
    chat_id: Optional[int]
    callback_data: Optional[str]
    message_text: Optional[str]

    @staticmethod
    def from_update(u: Dict[str, Any]) -> "UpdateView":
        uid = u.get("update_id")
        user_id = None
        chat_id = None
        cb = None
        txt = None

        if "message" in u and isinstance(u["message"], dict):
            m = u["message"]
            chat_id = (m.get("chat") or {}).get("id")
            user_id = (m.get("from") or {}).get("id")
            txt = m.get("text")

        if "callback_query" in u and isinstance(u["callback_query"], dict):
            c = u["callback_query"]
            if not user_id:
                user_id = (c.get("from") or {}).get("id")
            if not chat_id:
                chat_id = (c.get("message") or {}).get("chat", {}).get("id")
            cb = c.get("data")

        return UpdateView(
            update_id=uid,
            user_id=user_id,
            chat_id=chat_id,
            callback_data=cb,
            message_text=txt,
        )


def parse_idempotency_from_callback(cb: Optional[str]) -> Optional[str]:
    """
    Пытаемся извлечь idempotency-nonce из callback_data.
    Поддерживаем несколько «форм»: "...|idk:<nonce>", "idk=<nonce>", ";idk:<n>".
    """
    if not cb:
        return None
    s = cb.strip()
    markers = ("|idk:", "idk:", "idk=", ";idk:")
    for mk in markers:
        if mk in s:
            try:
                # Берём всё после маркера до следующего разделителя.
                tail = s.split(mk, 1)[1]
                for sep in ("|", ";", ","):
                    if sep in tail:
                        tail = tail.split(sep, 1)[0]
                tail = tail.strip()
                return tail if tail else None
            except Exception:
                return None
    return None


# =============================================================================
# Дедупликация апдейтов (update_id) — TTL-кэш в памяти процесса
# =============================================================================

class Deduplicator:
    """Простой TTL-кэш update_id → deadline, защищённый lock'ом."""

    def __init__(self, ttl_seconds: int = 300, max_size: int = 5000) -> None:
        self._ttl = ttl_seconds
        self._max = max_size
        self._seen: Dict[int, float] = {}
        self._lock = asyncio.Lock()

    async def is_duplicate(self, update_id: Optional[int]) -> bool:
        """True, если уже видели update_id (и TTL не истёк)."""
        if update_id is None:
            return False
        async with self._lock:
            now = time.time()
            # Очистка эволюционная (не на каждом вызове «полная»)
            if len(self._seen) > self._max:
                # Убираем самые старые по простому признаку
                cutoff = now - self._ttl
                self._seen = {k: v for k, v in self._seen.items() if v >= cutoff}
            exp = self._seen.get(update_id)
            if exp and exp >= now:
                return True
            # запоминаем новый id c deadline
            self._seen[update_id] = now + self._ttl
            return False


# =============================================================================
# Токен-бакет (rate limit) — «мягкий» антиспам на пользователя
# =============================================================================

class RateLimiter:
    """
    Токен-бакет с пополнением на интервале.
    capacity: максимум токенов на ключ (user_id).
    refill_per_sec: скорость пополнения (токенов/сек).
    """

    def __init__(self, capacity: int = 5, refill_per_sec: float = 0.5) -> None:
        self.capacity = capacity
        self.refill = refill_per_sec
        self._state: Dict[int, Tuple[float, float]] = {}
        self._lock = asyncio.Lock()

    async def allow(self, key: Optional[int]) -> Tuple[bool, float]:
        """
        Возвращает (ok, wait_sec). Если ok=False — через сколько секунд попробовать.
        """
        if key is None:
            return True, 0.0
        now = time.time()
        async with self._lock:
            tokens, last = self._state.get(key, (self.capacity * 1.0, now))
            # пополняем токены
            tokens = min(self.capacity, tokens + (now - last) * self.refill)
            if tokens >= 1.0:
                tokens -= 1.0
                self._state[key] = (tokens, now)
                return True, 0.0
            # не хватает — сообщаем рекомендуемую задержку до +1 токена
            need = 1.0 - tokens
            wait = max(need / self.refill, 0.1)
            self._state[key] = (tokens, now)
            return False, wait


# =============================================================================
# Декоратор-охранник: tg_guard
# =============================================================================

# Тип API-адаптера, ожидаем минимум метод send_message(chat_id, text)
TGSendAPI = Any  # deliberately loose; см. docstring tg_guard

def tg_guard(
    *,
    dedupe: Optional[Deduplicator] = None,
    limiter: Optional[RateLimiter] = None,
    require_idk: bool = False,
    admin_only: bool = False,
    friendly_errors: bool = True,
) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
    """
    Оборачивает async-хэндлер Telegram:

    Ожидания по сигнатуре оборачиваемой функции:
        async def handler(update: dict, api: TGSendAPI, **ctx) -> Any

    Где:
      • update — Telegram update (dict),
      • api — объект, у которого есть хотя бы coroutine-метод send_message(chat_id, text),
      • **ctx — любые контекстные параметры из вашего bot.py (например, lang).

    Параметры:
      dedupe       — дедупликатор update_id (если None — не используется).
      limiter      — лимитер на пользователя (если None — не используется).
      require_idk  — требовать idk/nonce в callback_data (для «денежных» сценариев).
      admin_only   — ограничить доступ для settings.ADMIN_BANK_TELEGRAM_ID.
      friendly_errors — перехватывать исключения и слать пользователю друж. сообщение.

    Возврат:
      Обёрнутая coroutine, которая применяет описанные проверки и защиту.
    """
    admin_id = None
    try:
        admin_id = int(getattr(settings, "ADMIN_BANK_TELEGRAM_ID", 0) or 0)
    except Exception:
        admin_id = 0

    def _decorator(fn: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        async def _wrapped(update: Dict[str, Any], api: TGSendAPI, **ctx: Any) -> Any:
            uv = UpdateView.from_update(update)

            # 1) Дедупликация по update_id
            if dedupe is not None:
                try:
                    if await dedupe.is_duplicate(uv.update_id):
                        logger.info("tg_guard: duplicate update_id=%s ignored", uv.update_id)
                        return None
                except Exception as e:
                    logger.warning("tg_guard: dedupe check failed: %s", e)

            # 2) Ограничение частоты по user_id
            if limiter is not None:
                try:
                    ok, wait = await limiter.allow(uv.user_id)
                    if not ok:
                        # Мягкий отказ (если есть куда слать)
                        if uv.chat_id and hasattr(api, "send_message"):
                            try:
                                await api.send_message(
                                    chat_id=uv.chat_id,
                                    text=f"Вы слишком часто повторяете действие. Попробуйте через ~{int(wait)} сек.",
                                )
                            except Exception as e:
                                logger.debug("tg_guard: failed to send rate message: %s", e)
                        return None
                except Exception as e:
                    logger.warning("tg_guard: rate-limit failed: %s", e)

            # 3) Доступ только для админа (по необходимости)
            if admin_only:
                if not uv.user_id or uv.user_id != admin_id:
                    logger.info("tg_guard: admin_only rejected for user=%s", uv.user_id)
                    if uv.chat_id and hasattr(api, "send_message"):
                        try:
                            await api.send_message(
                                chat_id=uv.chat_id,
                                text="Доступ запрещён. Эта команда только для администратора.",
                            )
                        except Exception as e:
                            logger.debug("tg_guard: failed to send admin_only message: %s", e)
                    return None

            # 4) Требование Idempotency Key (для денежных действий в callback)
            if require_idk:
                idk = parse_idempotency_from_callback(uv.callback_data)
                if not idk:
                    logger.info("tg_guard: missing idempotency nonce in callback_data")
                    if uv.chat_id and hasattr(api, "send_message"):
                        try:
                            await api.send_message(
                                chat_id=uv.chat_id,
                                text="Техническая защита: отсутствует Idempotency Key. Повторите действие из приложения.",
                            )
                        except Exception as e:
                            logger.debug("tg_guard: failed to send idk message: %s", e)
                    return None
                # прокидываем разобранный ключ в контекст хэндлера
                ctx.setdefault("idempotency_key", idk)

            # 5) Вызываем сам обработчик с защитой от исключений
            try:
                return await fn(update, api, **ctx)
            except asyncio.CancelledError:
                # не заглатываем отмену
                raise
            except Exception as e:
                logger.exception("tg_guard: handler crashed: %s", e)
                if friendly_errors and uv.chat_id and hasattr(api, "send_message"):
                    try:
                        await api.send_message(
                            chat_id=uv.chat_id,
                            text="Временная ошибка. Я уже восстанавливаюсь — попробуйте ещё раз.",
                        )
                    except Exception as e2:
                        logger.debug("tg_guard: failed to send fallback message: %s", e2)
                return None

        return _wrapped

    return _decorator


# =============================================================================
# Готовые экземпляры (можно переиспользовать в bot.py)
# =============================================================================

# Дедупликация апдейтов на 5 минут, до 5k ключей (процесс-локально)
DEFAULT_DEDUP = Deduplicator(ttl_seconds=300, max_size=5000)

# Мягкий лимит: 5 действий «залпом», пополнение 0.5 токена/сек (~1 клик/2 сек стабильно)
DEFAULT_RATE = RateLimiter(capacity=5, refill_per_sec=0.5)


# =============================================================================
# Пояснения «для чайника»:
# • Как использовать в bot.py?
#
#   from backend.app.bot.middlewares import tg_guard, DEFAULT_DEDUP, DEFAULT_RATE
#
#   @tg_guard(dedupe=DEFAULT_DEDUP, limiter=DEFAULT_RATE)
#   async def on_start(update: dict, api: TGApi, **ctx):
#       # безопасный обработчик /start
#       ...
#
#   @tg_guard(dedupe=DEFAULT_DEDUP, limiter=DEFAULT_RATE, require_idk=True)
#   async def on_buy_panel_callback(update: dict, api: TGApi, **ctx):
#       # для денежных действий требуем idempotency-ключ в callback_data:
#       # например: "buy_panel|idk:abc123"
#       idk = ctx["idempotency_key"]  # разобранный ключ от middleware
#       ...
#
#   @tg_guard(dedupe=DEFAULT_DEDUP, limiter=DEFAULT_RATE, admin_only=True)
#   async def on_admin_broadcast(update: dict, api: TGApi, **ctx):
#       # только для ADMIN_BANK_TELEGRAM_ID; остальным — вежливый отказ
#       ...
#
# • Что такое api в сигнатуре?
#   Это ваш тонкий адаптер к Telegram Bot API, у которого есть минимум
#   метод send_message(chat_id, text). В простом случае это объект с этой
#   корутиной, оборачивающей HTTP-вызов Bot API. Middlewares ничего не знают
#   о конкретной библиотеке (aiogram/python-telegram-bot) и остаются независимыми.
#
# • Почему всё в памяти?
#   Это процесс-локальная защита от дубликатов и спама, чтобы не тянуть БД.
#   В многопроцессной схеме допускается параллельная обработка редких
#   повторов, но основной объём шторма фильтруется на уровне каждого воркера.
#
# • Где проверяется «экономика»?
#   Не здесь. Этот модуль только охраняет вход. Все денежные изменения проходят
#   через сервисы (transactions_service и др.) и имеют свою идемпотентность.
# =============================================================================
