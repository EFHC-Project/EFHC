# -*- coding: utf-8 -*-
# backend/app/bot/states.py
# =============================================================================
# Назначение кода:
# Дерево состояний (FSM) и менеджер состояний для Telegram-бота EFHC.
# Позволяет «помнить», на каком шаге находится пользователь (например,
# ожидание доказательства задания, количества билетов лотереи и т. п.).
#
# Канон/инварианты:
# • Денежных операций здесь НЕТ — только навигационная логика бота.
# • Любые реальные списания/начисления выполняются строго в сервисах
#   (transactions_service.py и др.) и только через «банк».
# • Состояние не может «исправлять» балансы и не взаимодействует с TON/NFT.
#
# ИИ-защита / самовосстановление:
# • Две ступени хранения: внешний backend (опционально) и встроенный
#   in-memory fallback. При ошибках внешнего хранилища менеджер не падает —
#   использует локальную память процесса и пытается «догонять» при следующем шаге.
# • TTL для разговорных состояний (автосброс по истечении времени неактивности).
# • Защита от «перегрева»: лимит размера data (серилизуем только JSON-безопасное).
# • Неблокирующий GC (фоновая очистка просроченных ключей).
#
# Запреты:
# • Никаких операций с БД/кошельками/балансами; FSM — только про UI-потоки.
# • Никаких скрытых «commit» действий — любые изменения денег строго вне FSM.
# =============================================================================

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger

logger = get_logger(__name__)
settings = get_settings()

# =============================================================================
# Константы и дефолты (настраиваемые через .env при желании)
# =============================================================================

# TTL разговора: через сколько секунд неактивности состояние будет обнулено.
DEFAULT_STATE_TTL_SECONDS: int = int(getattr(settings, "BOT_STATE_TTL_SECONDS", 15 * 60) or 900)
# Период фоновой уборки просроченных записей
DEFAULT_GC_INTERVAL_SECONDS: int = int(getattr(settings, "BOT_STATE_GC_INTERVAL", 60) or 60)
# Максимум безопасного JSON-payload для data (байт после сериализации)
MAX_STATE_DATA_BYTES: int = int(getattr(settings, "BOT_STATE_DATA_LIMIT", 4096) or 4096)

# =============================================================================
# Набор «канонических» имен состояний (расширяем при необходимости)
# =============================================================================

class BotStates:
    """Строчные константы состояний бота (FSM)."""
    IDLE = "idle"  # нет активного шага

    # Задания (Tasks)
    TASK_AWAIT_PROOF = "task.await_proof"  # ждём от пользователя доказательство выполнения
    TASK_AWAIT_LINK  = "task.await_link"   # ждём ссылку/URL (если задание требует)

    # Магазин/оплаты
    SHOP_AWAIT_MEMO  = "shop.await_memo"   # подсказали формат MEMO, ждём подтверждение/ввод

    # Лотерея
    LOTTERY_AWAIT_TICKETS = "lottery.await_tickets"  # ждём количество билетов

    # Вывод средств
    WITHDRAW_AWAIT_AMOUNT = "withdraw.await_amount"  # ждём сумму EFHC для заявки

    # Админ
    ADMIN_BROADCAST_TEXT = "admin.broadcast_text"    # ждём текст рассылки

# =============================================================================
# Модель состояния (в памяти менеджера/адаптера)
# =============================================================================

@dataclass
class ConversationState:
    """
    Единица состояния диалога пользователя.

    state: строковой код (см. BotStates.*)
    data:  произвольный JSON-совместимый словарь (ограничение размера см. MAX_STATE_DATA_BYTES)
    updated_at: unix time последнего изменения
    expires_at: unix time, после которого запись считается просроченной (GC её чистит)
    """
    state: str = BotStates.IDLE
    data: Dict[str, Any] = field(default_factory=dict)
    updated_at: float = field(default_factory=lambda: time.time())
    expires_at: float = field(default_factory=lambda: time.time() + DEFAULT_STATE_TTL_SECONDS)

    def is_expired(self, now: Optional[float] = None) -> bool:
        now = now or time.time()
        return now >= (self.expires_at or 0)

    def touch(self, ttl: Optional[int] = None) -> None:
        """Обновляет updated_at/expires_at не меняя состояние/данные."""
        now = time.time()
        self.updated_at = now
        self.expires_at = now + (ttl or DEFAULT_STATE_TTL_SECONDS)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "state": self.state,
            "data": self.data,
            "updated_at": self.updated_at,
            "expires_at": self.expires_at,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "ConversationState":
        return ConversationState(
            state=str(d.get("state") or BotStates.IDLE),
            data=dict(d.get("data") or {}),
            updated_at=float(d.get("updated_at") or time.time()),
            expires_at=float(d.get("expires_at") or (time.time() + DEFAULT_STATE_TTL_SECONDS)),
        )

# =============================================================================
# Абстракция backend-хранилища состояний
# =============================================================================

class AbstractStateBackend:
    """
    Базовый контракт для backends хранилища состояний (например, Redis, БД).
    Все методы асинхронны, чтобы не блокировать event loop.
    """

    async def get(self, key: Tuple[int, int]) -> Optional[ConversationState]:  # (user_id, chat_id)
        raise NotImplementedError

    async def set(self, key: Tuple[int, int], value: ConversationState) -> None:
        raise NotImplementedError

    async def clear(self, key: Tuple[int, int]) -> None:
        raise NotImplementedError

    async def cleanup(self) -> int:
        """Опционально: удалить просроченные записи. Возвращает число удалённых."""
        return 0

# -----------------------------------------------------------------------------
# Встроенный in-memory backend (процесс-локальный, с TTL и GC)
# -----------------------------------------------------------------------------

class MemoryStateBackend(AbstractStateBackend):
    def __init__(self) -> None:
        self._store: Dict[Tuple[int, int], ConversationState] = {}
        self._lock = asyncio.Lock()

    async def get(self, key: Tuple[int, int]) -> Optional[ConversationState]:
        async with self._lock:
            st = self._store.get(key)
            if not st:
                return None
            if st.is_expired():
                # мягкая очистка при чтении
                self._store.pop(key, None)
                return None
            return st

    async def set(self, key: Tuple[int, int], value: ConversationState) -> None:
        async with self._lock:
            self._store[key] = value

    async def clear(self, key: Tuple[int, int]) -> None:
        async with self._lock:
            self._store.pop(key, None)

    async def cleanup(self) -> int:
        async with self._lock:
            now = time.time()
            to_del = [k for k, v in self._store.items() if v.is_expired(now)]
            for k in to_del:
                self._store.pop(k, None)
            return len(to_del)

# =============================================================================
# Менеджер состояний с ИИ-самовосстановлением и fallback
# =============================================================================

class StateManager:
    """
    Высокоуровневый API работы с состояниями:
      • безопасные set/get/clear
      • атомарные переходы (transition), ожидающие текущее состояние
      • обновление data с защитой по лимиту
      • фоновый GC
    """

    def __init__(self, backend: Optional[AbstractStateBackend] = None) -> None:
        self._primary = backend  # может быть None (только память)
        self._fallback = MemoryStateBackend()
        self._gc_task: Optional[asyncio.Task] = None
        self._gc_interval = DEFAULT_GC_INTERVAL_SECONDS

    # --------------- утилиты ключей ---------------

    @staticmethod
    def make_key(user_id: int, chat_id: int) -> Tuple[int, int]:
        return (int(user_id), int(chat_id))

    # --------------- низкоуровневые операции ---------------

    async def _get(self, key: Tuple[int, int]) -> Optional[ConversationState]:
        # 1) пытаемся из primary
        if self._primary:
            try:
                st = await self._primary.get(key)
                if st:
                    return st
            except Exception as e:
                logger.warning("StateManager: primary.get failed, fallback used: %s", e)
        # 2) fallback
        return await self._fallback.get(key)

    async def _set(self, key: Tuple[int, int], state: ConversationState) -> None:
        ok_primary = False
        # 1) пытаемся записать в primary
        if self._primary:
            try:
                await self._primary.set(key, state)
                ok_primary = True
            except Exception as e:
                logger.warning("StateManager: primary.set failed, fallback used: %s", e)
        # 2) всегда записываем в fallback (держим «горячую» копию)
        try:
            await self._fallback.set(key, state)
        except Exception as e:
            # Это уже критично: не можем держать даже локально.
            logger.error("StateManager: fallback.set failed: %s", e)
            if ok_primary:
                # хотя бы primary записался — продолжаем
                return
            raise

    async def _clear(self, key: Tuple[int, int]) -> None:
        if self._primary:
            try:
                await self._primary.clear(key)
            except Exception as e:
                logger.warning("StateManager: primary.clear failed: %s", e)
        try:
            await self._fallback.clear(key)
        except Exception as e:
            logger.error("StateManager: fallback.clear failed: %s", e)

    # --------------- высокоуровневый API ---------------

    async def get(self, user_id: int, chat_id: int) -> ConversationState:
        """
        Возвращает актуальное состояние; при отсутствии — IDLE.
        Просроченное состояние автоматически очищается.
        """
        key = self.make_key(user_id, chat_id)
        st = await self._get(key)
        if not st:
            return ConversationState(state=BotStates.IDLE)
        return st

    async def set(
        self,
        user_id: int,
        chat_id: int,
        state: str,
        data: Optional[Dict[str, Any]] = None,
        *, ttl: Optional[int] = None
    ) -> ConversationState:
        """
        Устанавливает состояние и (опц.) data, продлевая TTL.
        """
        data = data or {}
        safe = self._sanitize_data(data)
        st = ConversationState(state=state, data=safe)
        st.touch(ttl)
        await self._set(self.make_key(user_id, chat_id), st)
        return st

    async def clear(self, user_id: int, chat_id: int) -> None:
        """Сбрасывает состояние в IDLE (удаляет запись)."""
        await self._clear(self.make_key(user_id, chat_id))

    async def update_data(
        self, user_id: int, chat_id: int, patch: Dict[str, Any], *, ttl: Optional[int] = None
    ) -> ConversationState:
        """
        Безопасно сливает patch в data активного состояния.
        Не меняет state, только обновляет данные и TTL.
        """
        key = self.make_key(user_id, chat_id)
        st = await self._get(key) or ConversationState()
        merged = dict(st.data or {})
        merged.update(patch or {})
        st.data = self._sanitize_data(merged)
        st.touch(ttl)
        await self._set(key, st)
        return st

    async def transition(
        self,
        user_id: int,
        chat_id: int,
        expected_state: Optional[str],
        next_state: str,
        *, data: Optional[Dict[str, Any]] = None,
        ttl: Optional[int] = None
    ) -> Tuple[bool, ConversationState]:
        """
        Атомарный переход, если текущее состояние совпадает с expected_state.
        Если expected_state=None — переход без проверки (форс).
        Возвращает (ok, новое_состояние). ok=False ─ если ожидание не совпало.
        """
        key = self.make_key(user_id, chat_id)
        st = await self._get(key) or ConversationState()
        if expected_state is not None and st.state != expected_state:
            return False, st
        st.state = next_state
        if data:
            merged = dict(st.data or {})
            merged.update(data)
            st.data = self._sanitize_data(merged)
        st.touch(ttl)
        await self._set(key, st)
        return True, st

    # --------------- служебное ---------------

    async def start_background_gc(self) -> None:
        """
        Запускает фоновую задачу, которая периодически чистит просроченные записи.
        Безопасно вызывать несколько раз — будет только одна задача.
        """
        if self._gc_task and not self._gc_task.done():
            return

        async def _gc_loop():
            while True:
                try:
                    # primary
                    if self._primary:
                        try:
                            removed = await self._primary.cleanup()
                            if removed:
                                logger.debug("StateManager: primary GC removed %s", removed)
                        except Exception as e:
                            logger.debug("StateManager: primary GC failed: %s", e)
                    # fallback
                    try:
                        removed_fb = await self._fallback.cleanup()
                        if removed_fb:
                            logger.debug("StateManager: fallback GC removed %s", removed_fb)
                    except Exception as e:
                        logger.debug("StateManager: fallback GC failed: %s", e)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    logger.debug("StateManager GC loop error: %s", e)
                await asyncio.sleep(self._gc_interval)

        self._gc_task = asyncio.create_task(_gc_loop(), name="bot_state_gc")

    def _sanitize_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Гарантирует JSON-совместимость и лимит размера.
        Если payload превышает MAX_STATE_DATA_BYTES — пробуем компактировать
        (например, удаляя «шумовые» ключи), затем — безопасно усечём.
        """
        safe = dict(data or {})
        try:
            payload = json.dumps(safe, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        except Exception:
            # если не сериализуется, делаем «плоские» строки значений
            flat = {k: (str(v) if not isinstance(v, (str, int, float, bool, type(None))) else v)
                    for k, v in safe.items()}
            safe = flat
            payload = json.dumps(safe, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

        if len(payload) <= MAX_STATE_DATA_BYTES:
            return safe

        # Попытка компактирования: удалим типичные шумовые поля
        noisy_keys = [k for k in safe.keys() if k.lower() in {"debug", "trace", "raw", "extra"}]
        for k in noisy_keys:
            safe.pop(k, None)
        payload = json.dumps(safe, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        if len(payload) <= MAX_STATE_DATA_BYTES:
            return safe

        # Жёсткое усечение значений (оставим только «краткие» строки/числа)
        trimmed: Dict[str, Any] = {}
        for k, v in safe.items():
            if isinstance(v, str):
                # оставим до 256 символов
                trimmed[k] = (v[:255] + "…") if len(v) > 256 else v
            elif isinstance(v, (int, float, bool)) or v is None:
                trimmed[k] = v
            else:
                trimmed[k] = str(v)[:255] + "…"
        payload = json.dumps(trimmed, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        if len(payload) > MAX_STATE_DATA_BYTES:
            # последний барьер — удаляем ключи по одному, пока не влезем
            while trimmed and len(payload) > MAX_STATE_DATA_BYTES:
                trimmed.pop(next(iter(trimmed.keys())), None)
                payload = json.dumps(trimmed, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return trimmed

# =============================================================================
# Фабрика менеджера: можно подставить реальный backend (например, Redis)
# =============================================================================

_global_state_manager: Optional[StateManager] = None

def get_state_manager(backend: Optional[AbstractStateBackend] = None) -> StateManager:
    """
    Возвращает singleton StateManager для процесса. Если передать backend —
    используется он; иначе остаётся только in-memory хранение с fallback.
    """
    global _global_state_manager
    if _global_state_manager is None:
        _global_state_manager = StateManager(backend=backend)
        # Запускаем фоновую очистку сразу (не критично, если вызвать ещё раз)
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # если уже в асинхронном контексте
                loop.create_task(_global_state_manager.start_background_gc())
        except RuntimeError:
            # не в асинхронном контексте — GC стартанёт при первом async-вызове
            pass
    return _global_state_manager

# =============================================================================
# Декораторы-помощники для хэндлеров (упрощают работу с FSM)
# =============================================================================

Handler = Callable[..., Awaitable[Any]]

def require_state(expected: Optional[str]) -> Callable[[Handler], Handler]:
    """
    Гейт для хэндлеров: пропускает только если у пользователя нужное состояние.
    Если expected=None — пропускает всегда (используйте tg_guard для прав/лимитов).
    """
    def _wrap(fn: Handler) -> Handler:
        async def _inner(*args: Any, **kwargs: Any) -> Any:
            # ожидаем сигнатуру handler(update, api, user_id=..., chat_id=..., **ctx)
            user_id = kwargs.get("user_id")
            chat_id = kwargs.get("chat_id")
            if user_id is None or chat_id is None:
                logger.debug("require_state: missing user_id/chat_id in kwargs")
                return await fn(*args, **kwargs)

            sm = get_state_manager()
            st = await sm.get(int(user_id), int(chat_id))
            if expected is not None and st.state != expected:
                logger.debug("require_state: blocked (expected=%s, actual=%s)", expected, st.state)
                return None
            return await fn(*args, **kwargs)
        return _inner  # type: ignore[return-value]
    return _wrap

def advance_state(next_state: str, *, ttl: Optional[int] = None, patch: Optional[Dict[str, Any]] = None) -> Callable[[Handler], Handler]:
    """
    После успешного выполнения хэндлера переводит пользователя в next_state,
    с опциональным обновлением data и продлением TTL.
    """
    def _wrap(fn: Handler) -> Handler:
        async def _inner(*args: Any, **kwargs: Any) -> Any:
            user_id = kwargs.get("user_id")
            chat_id = kwargs.get("chat_id")
            res = await fn(*args, **kwargs)
            if user_id is None or chat_id is None:
                return res
            sm = get_state_manager()
            await sm.set(int(user_id), int(chat_id), next_state, data=patch or {}, ttl=ttl)
            return res
        return _inner  # type: ignore[return-value]
    return _wrap

def clear_state_after(fn: Handler) -> Handler:
    """
    Сбрасывает состояние пользователя в IDLE после успешного выполнения хэндлера.
    Удобно для завершающих шагов (например, «заявка принята»).
    """
    async def _inner(*args: Any, **kwargs: Any) -> Any:
        user_id = kwargs.get("user_id")
        chat_id = kwargs.get("chat_id")
        res = await fn(*args, **kwargs)
        if user_id is not None and chat_id is not None:
            sm = get_state_manager()
            await sm.clear(int(user_id), int(chat_id))
        return res
    return _inner  # type: ignore[return-value]

# =============================================================================
# Пояснения «для чайника»:
# • Что такое FSM и зачем?
#   Когда бот задаёт вопрос и ждёт ответ (например, «Сколько билетов купить?»),
#   нужно запомнить «контекст ожидания». FSM хранит простую метку состояния
#   (например, LOTTERY_AWAIT_TICKETS) и любые данные, нужные следующему шагу.
#
# • Где и как хранится?
#   По умолчанию — в памяти процесса (MemoryStateBackend) + периодическая очистка
#   просроченных записей. Можно подставить внешний backend (Redis и т. п.), реализовав
#   AbstractStateBackend и передав его в get_state_manager(...).
#
# • Самовосстановление:
#   Если внешний backend недоступен, менеджер не падает — пишет в локальную память.
#   При следующем успешном обращении к внешнему хранилищу состояние продолжит жить.
#
# • Безопасность:
#   FSM не делает деньги/TON/NFT. Это «навигация» и удобная память между шагами.
#   Любая экономика — только через сервисы и «банк».
#
# • Как использовать в bot.py?
#   sm = get_state_manager()
#   await sm.set(user_id, chat_id, BotStates.TASK_AWAIT_PROOF, {"task_id": 123})
#   st = await sm.get(user_id, chat_id)
#   if st.state == BotStates.TASK_AWAIT_PROOF:
#       ... читать доказательство и т. д.
# =============================================================================
