# -*- coding: utf-8 -*-
# backend/app/main.py
# =============================================================================
# EFHC Bot — точка входа FastAPI (КАНОН)
# -----------------------------------------------------------------------------
# Что делает этот файл:
#   • Создаёт приложение FastAPI и настраивает CORS.
#   • На старте:
#       - (мягко) проверяет архитектурные запреты system_locks (если модуль есть),
#       - запускает ИИ-агента планировщика входящих TON (check_ton_inbox).
#   • На остановке: корректно гасит агента.
#   • Подключает канонические роуты (если модуль существует — подключим; если нет — просто лог предупредит).
#   • Даёт health-эндпоинты для проверок (в т.ч. снимок банка и очереди логов).
#
# Важно:
#   • Никаких денежных операций здесь нет — все деньги через services/transactions_service.py.
#   • Сетевой доступ к TonAPI здесь не выполняется — это делает integrations/ton_api.py.
#   • «Для чайника»: если модуль какого-то роута ещё не готов, приложение не падает — просто пишет WARNING.
# =============================================================================

from __future__ import annotations

import os
import asyncio
from contextlib import asynccontextmanager
from typing import Optional, Dict, Any, List

from fastapi import FastAPI, APIRouter
from fastapi.middleware.cors import CORSMiddleware

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.database import async_session_maker
from sqlalchemy import text

# Планировщик (ИИ-агент 10-мин ритма «время — триггер»)
from backend.app.scheduler.check_ton_inbox import (
    start_check_ton_inbox_agent,
    stop_check_ton_inbox_agent,
)

logger = get_logger(__name__)
settings = get_settings()

# -----------------------------------------------------------------------------
# CORS: фронтенд/вебхуки из .env
# -----------------------------------------------------------------------------

def _build_cors_origins() -> List[str]:
    origins: List[str] = []
    for name in ("APP_URL", "BACKEND_URL", "FRONTEND_URL", "WEBHOOK_URL"):
        v = getattr(settings, name, None) or os.environ.get(name)
        if v:
            origins.append(str(v))
    # Разрешим localhost для локальной отладки
    origins.extend([
        "http://localhost",
        "http://localhost:3000",
        "http://127.0.0.1",
        "http://127.0.0.1:3000",
    ])
    # Удаляем дубликаты
    return sorted(set(origins))


# -----------------------------------------------------------------------------
# Лайфспан: старт/стоп приложения
# -----------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1) Жёсткие проверки архитектурных запретов (если модуль присутствует)
    try:
        from backend.app.core.system_locks import validate_on_start  # type: ignore
    except Exception:
        logger.warning("system_locks: модуль не найден — пропускаем жёсткие проверки на старте")
    else:
        try:
            await validate_on_start()
            logger.info("system_locks: стартовые проверки канона пройдены")
        except Exception as e:
            # По канону — лучше упасть сразу, чем стартовать в противоречивом состоянии
            logger.exception("system_locks: провал проверки канона на старте: %s", e)
            raise

    # 2) Запуск ИИ-агента планировщика входящих TON
    try:
        await start_check_ton_inbox_agent()
    except Exception as e:
        logger.exception("startup: не удалось запустить агента check_ton_inbox: %s", e)
        # НЕ валим приложение: агент самовосстановится при следующей попытке старта вручную
    yield
    # 3) Корректное завершение агента
    try:
        await stop_check_ton_inbox_agent()
    except Exception as e:
        logger.warning("shutdown: ошибка остановки агента check_ton_inbox: %s", e)


# -----------------------------------------------------------------------------
# Приложение FastAPI
# -----------------------------------------------------------------------------

app = FastAPI(
    title=getattr(settings, "PROJECT_NAME", "EFHC-Bot"),
    version="1.0.0",  # версионирование API — обновляем по мере релизов
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=_build_cors_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------------------------------------------------------
# Безопасное подключение канонических роутов
# -----------------------------------------------------------------------------
# «Для чайника»: если какой-то файл роутов ещё не создан, приложение не упадёт.
# Мы логируем WARNING и идём дальше. Когда файл появится — он подключится.

def _include_router_safe(module_path: str, *, prefix: Optional[str] = None, tags: Optional[list] = None) -> None:
    try:
        mod = __import__(module_path, fromlist=["router"])
        router: APIRouter = getattr(mod, "router")
    except Exception as e:
        logger.warning("router: модуль %s не подключён (%s)", module_path, e)
        return
    app.include_router(router, prefix=prefix or "", tags=tags or [])

# Канон: перечень роутов
_include_router_safe("backend.app.routes.user_routes",     prefix="/user",      tags=["user"])
_include_router_safe("backend.app.routes.panels_routes",   prefix="/panels",    tags=["panels"])
_include_router_safe("backend.app.routes.exchange_routes", prefix="/exchange",  tags=["exchange"])
_include_router_safe("backend.app.routes.shop_routes",     prefix="/shop",      tags=["shop"])
_include_router_safe("backend.app.routes.tasks_routes",    prefix="/tasks",     tags=["tasks"])
_include_router_safe("backend.app.routes.referrals_routes",prefix="/referrals", tags=["referrals"])
_include_router_safe("backend.app.routes.lotteries_routes",prefix="/lotteries", tags=["lotteries"])
_include_router_safe("backend.app.routes.rating_routes",   prefix="/rating",    tags=["rating"])
_include_router_safe("backend.app.routes.withdraw_routes", prefix="/withdraw",  tags=["withdraw"])
_include_router_safe("backend.app.routes.admin_routes",    prefix="/admin",     tags=["admin"])

# -----------------------------------------------------------------------------
# Health / Info эндпоинты (простые и полезные)
# -----------------------------------------------------------------------------

@app.get("/health", tags=["meta"])
async def health() -> Dict[str, Any]:
    """
    Простой health-чек:
      • db_ok — доступна ли БД,
      • bank_balance — текущий баланс Банка (может быть отрицательным по канону),
      • inbox_pending — сколько записей ещё ждут обработки,
      • time — серверное время (UTC).
    """
    db_ok = False
    bank_balance = "0"
    pending = 0
    schema = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

    try:
        async with async_session_maker() as db:
            # лёгкий ping
            await db.execute(text("SELECT 1"))
            db_ok = True

            # баланс банка
            row = await db.execute(text(f"SELECT balance FROM {schema}.bank_state WHERE id=1"))
            r = row.fetchone()
            if r:
                bank_balance = str(r[0])

            # количество не финализированных входящих
            final_statuses = (
                "processed_auto_efhc",
                "paid_pending_manual",
                "ignored_bad_memo",
                "logged_unmatched_wallet_deposit",
                "error_user_not_found",
            )
            q = await db.execute(text(
                f"""
                SELECT COUNT(*)
                  FROM {schema}.ton_inbox_logs
                 WHERE status NOT IN :finals
                   AND (next_retry_at IS NULL OR next_retry_at <= NOW())
                """
            ), {"finals": tuple(final_statuses)})
            pending = int(q.scalar() or 0)

    except Exception as e:
        logger.exception("health: ошибка проверки БД/снимков: %s", e)

    return {
        "ok": db_ok,
        "bank_balance": bank_balance,
        "inbox_pending": pending,
        "time": getattr(__import__("datetime"), "datetime").now(getattr(__import__("datetime"), "timezone").utc).isoformat(),
        "env": getattr(settings, "ENVIRONMENT", "production"),
        "project": getattr(settings, "PROJECT_NAME", "EFHC-Bot"),
    }


@app.get("/version", tags=["meta"])
async def version() -> Dict[str, Any]:
    """
    Быстрый ответ с версией и базовыми URL из конфига — удобно для CI/CD-проверок.
    """
    return {
        "project": getattr(settings, "PROJECT_NAME", "EFHC-Bot"),
        "version": app.version,
        "backend": getattr(settings, "BACKEND_URL", ""),
        "frontend": getattr(settings, "FRONTEND_URL", ""),
        "timezone": getattr(settings, "TIMEZONE", "UTC"),
        "schema": getattr(settings, "DB_SCHEMA_CORE", "efhc_core"),
    }


# -----------------------------------------------------------------------------
# Локальный запуск uvicorn (по желанию; на проде запускается внешним ASGI-сервером)
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.app.main:app",
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
        reload=bool(os.environ.get("DEV_RELOAD", "")),
        log_level="info",
)
