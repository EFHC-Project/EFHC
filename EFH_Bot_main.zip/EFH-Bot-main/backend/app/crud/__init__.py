# -*- coding: utf-8 -*-
# backend/app/crud/__init__.py
# =============================================================================
# Назначение кода:
# Централизованный пакет CRUD-слоя (доступ к данным без бизнес-логики).
# Агрегирует модули, формирует реестр, даёт самодиагностику наличия ключевых
# символов для сервисов/роутов.
#
# Канон/инварианты (важно):
# • Здесь НЕТ денежных операций и пересчёта балансов — только факты БД.
#   Все деньги идут через services/transactions_service.py.
# • Пагинация реализуется курсорами (id ASC), без OFFSET.
# • Идемпотентность — на уровне уникальных индексов + read-through в сервисах.
#
# ИИ-защита/самовосстановление:
# • «Мягкий» импорт: отсутствие отдельного CRUD-модуля не валит весь пакет.
# • CRUD_REGISTRY содержит только успешно загруженные модули;
#   health_check() отчётно показывает недостающие файлы/символы.
#
# Запреты:
# • Не добавлять бизнес-функции/шорткаты для денежных операций.
# • Не дублировать константы/утилиты — они живут в core/config_core.py и deps.py.
# =============================================================================

from __future__ import annotations

import importlib
from typing import Dict, List, Tuple, Optional

# -----------------------------------------------------------------------------
# «Мягкий» импорт CRUD-модулей
# -----------------------------------------------------------------------------

def _try_import(local_module: str) -> Optional[object]:
    """
    Пытается загрузить .<local_module> относительно текущего пакета.
    Возвращает модуль или None (если файла нет/ошибка импорта).
    Никаких исключений наружу — пакет не падает.
    """
    try:
        return importlib.import_module(f".{local_module}", package=__name__)
    except Exception:
        return None


# Карта логических имён → физические файлы
_MODULES_MAP: Dict[str, str] = {
    "user":         "user_crud",
    "transactions": "transactions_crud",
    "panels":       "panels_crud",
    "ranks":        "ranks_crud",
    "referrals":    "referrals_crud",
    "tasks":        "tasks_crud",
    "shop":         "shop_crud",        # может отсутствовать на ранних этапах
    "lottery":      "lottery_crud",
    "orders":       "order_crud",       # единое имя для order_crud.py
    "admin":        "admin_crud",
}

# Загружаем модули «мягко» и складываем в globals() с короткими алиасами
_LOADED: Dict[str, Optional[object]] = {}
for alias, modname in _MODULES_MAP.items():
    module = _try_import(modname)
    _LOADED[alias] = module
    globals()[alias] = module  # чтобы работать как раньше: from backend.app.crud import user, ...

# -----------------------------------------------------------------------------
# Реестр доступных модулей (только успешно загруженные)
# -----------------------------------------------------------------------------
CRUD_REGISTRY: Dict[str, object] = {k: v for k, v in _LOADED.items() if v is not None}

# Формируем __all__: алиасы модулей + утилиты пакета
__all__ = list(CRUD_REGISTRY.keys()) + ["CRUD_REGISTRY", "health_check"]

# -----------------------------------------------------------------------------
# Самопроверка наличия ключевых символов
# -----------------------------------------------------------------------------
def health_check() -> List[Tuple[str, bool, List[str]]]:
    """
    Назначение: вернуть список проверок (module_name, ok, missing_symbols)
    без выбрасывания исключений. Используется при старте сервиса/в админ-панели.

    Мы проверяем наличие «ядровых» символов, которые сервисы обычно ожидают.
    Отсутствие файла -> (ok=False, ["module_not_loaded"]).
    Отсутствие конкретных функций -> (ok=False, ["foo", "bar"]).
    """
    checks: List[Tuple[str, bool, List[str]]] = []

    REQUIRED: Dict[str, List[str]] = {
        # user_crud.py
        "user": ["ensure_user", "get_user_by_telegram", "list_users_cursor"],
        # transactions_crud.py
        "transactions": ["insert_transfer_log_readthrough", "upsert_ton_inbox_readthrough"],
        # panels_crud.py
        "panels": ["create_panel", "lock_active_panels_for_energy", "accrue_generated_kwh"],
        # lottery_crud.py
        "lottery": ["reserve_ticket_idempotent", "set_ticket_status_guarded", "list_public_lotteries"],
        # order_crud.py
        "orders": ["create_order_pending_payment", "mark_paid_by_external", "set_status_guarded"],
        # admin_crud.py
        "admin": ["list_efhc_transfers", "set_ton_log_status_guarded", "set_withdraw_status_guarded"],
        # ranks_crud.py / referrals_crud.py / tasks_crud.py / shop_crud.py — требования могут эволюционировать
        "ranks": [],
        "referrals": [],
        "tasks": [],
        "shop": [],
    }

    for alias in _MODULES_MAP.keys():
        module_obj = _LOADED.get(alias)
        required_symbols = REQUIRED.get(alias, [])
        if module_obj is None:
            checks.append((alias, False, ["module_not_loaded"]))
            continue
        missing = [name for name in required_symbols if not hasattr(module_obj, name)]
        checks.append((alias, len(missing) == 0, missing))

    return checks

# =============================================================================
# Пояснения (для разработчиков/ревью):
# • Мы сохранили прежние короткие алиасы (user, panels, …), но сделали импорт «мягким»:
#   отсутствующий файл CRUD теперь не роняет весь пакет crud.
# • CRUD_REGISTRY содержит только то, что реально загружено — удобно для диагностики и UI.
# • health_check() — мягкая проверка для админки/логов: наглядно видно, какого файла/символа нет.
# • Денежные операции по-прежнему запрещены на CRUD-уровне — только фактические операции БД.
# =============================================================================
