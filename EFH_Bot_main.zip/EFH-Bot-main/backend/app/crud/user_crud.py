# -*- coding: utf-8 -*-
# backend/app/crud/user_crud.py
# =============================================================================
# Назначение кода:
# CRUD-слой для таблицы пользователей (users): безопасное создание/чтение/обновление,
# курсорная пагинация, сервисные выборки под планировщик (VIP-проверка) и админку.
#
# Канон/инварианты (важно):
# • Денежных операций ЗДЕСЬ НЕТ: никакого изменения балансов/обмена/эмиссии.
#   Любые движения EFHC выполняются исключительно через services/transactions_service.py.
# • Пользователь НИКОГДА не должен уходить в минус. Проверки и блокировки покупок —
#   на уровне сервисов. CRUD хранит факты и не изменяет числа.
# • Все списки — только курсорная пагинация по (id ASC), без OFFSET.
#
# ИИ-защита/надёжность:
# • ensure_user(...) использует read-through вставку: on_conflict_do_nothing по telegram_id,
#   затем чтение уже существующей записи — без гонок.
# • Обновления полей (VIP, wallet) детерминированы, с минимальной логикой валидации.
# • Выборки для планировщика (VIP-чек) масштабируемые: курсор, простые фильтры.
#
# Запреты:
# • Никаких «прямых» операций с балансами (main/bonus/available_kwh/total_generated_kwh).
# • Никакого P2P, конвертаций, списаний/начислений — только факты профиля и статусы.
# =============================================================================

from __future__ import annotations

from typing import List, Optional, Tuple

from sqlalchemy import Select, and_, func, or_, select, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger
from backend.app.deps import encode_cursor, decode_cursor
from backend.app.models.user_models import User  # ожидаемые поля: id, telegram_id, username, is_vip, is_active, ton_wallet, balances..., created_at/updated_at

logger = get_logger(__name__)


# =============================================================================
# ВНУТРЕННИЕ ПОМОЩНИКИ (минимум логики, без «магии»)
# =============================================================================

def _apply_user_filters(
    stmt: Select,
    *,
    is_active: Optional[bool] = None,
    is_vip: Optional[bool] = None,
    qtext: Optional[str] = None,
) -> Select:
    """
    Применяем фильтры к выборке пользователей:
      • is_active — активен/нет,
      • is_vip — VIP/нет,
      • qtext — поиск по username ILIKE '%q%' ИЛИ точное совпадение по telegram_id, если q — число.
    """
    conds = []
    if is_active is not None:
        conds.append(User.is_active.is_(bool(is_active)))
    if is_vip is not None:
        conds.append(User.is_vip.is_(bool(is_vip)))
    if qtext:
        q = qtext.strip()
        # Если число — даём шанс точному совпадению по telegram_id.
        if q.isdigit():
            conds.append(or_(func.lower(User.username).like(func.lower(f"%{q}%")), User.telegram_id == int(q)))
        else:
            conds.append(func.lower(User.username).like(func.lower(f"%{q}%")))
    if conds:
        stmt = stmt.where(and_(*conds))
    return stmt


# =============================================================================
# CREATE / READ
# =============================================================================

async def ensure_user(
    db: AsyncSession,
    *,
    telegram_id: int,
    username: Optional[str] = None,
    is_active: bool = True,
) -> User:
    """
    Read-through создание пользователя по telegram_id:
      • Если не существует — создаём,
      • Если существует — сразу возвращаем существующего.
    Без гонок: ON CONFLICT DO NOTHING по UNIQUE(telegram_id), затем SELECT.
    """
    stmt_ins = (
        insert(User)
        .values(
            telegram_id=int(telegram_id),
            username=username,
            is_active=bool(is_active),
        )
        .on_conflict_do_nothing(index_elements=["telegram_id"])
        .returning(User)
    )
    res = await db.execute(stmt_ins)
    row = res.scalar_one_or_none()
    if row:
        return row

    # Уже существует — читаем
    res = await db.execute(select(User).where(User.telegram_id == int(telegram_id)).limit(1))
    exist = res.scalar_one_or_none()
    if not exist:
        # крайне редко: если таблица/индекс не в ожидаемом состоянии
        logger.error("ensure_user: failed to fetch after ON CONFLICT, tg=%s", telegram_id)
        raise RuntimeError("ensure_user: inconsistent state after insert conflict")
    return exist


async def get_user_by_id(db: AsyncSession, *, user_id: int) -> Optional[User]:
    """Вернуть пользователя по внутреннему id или None."""
    res = await db.execute(select(User).where(User.id == int(user_id)))
    return res.scalar_one_or_none()


async def get_user_by_telegram(db: AsyncSession, *, telegram_id: int) -> Optional[User]:
    """Вернуть пользователя по telegram_id или None."""
    res = await db.execute(select(User).where(User.telegram_id == int(telegram_id)).limit(1))
    return res.scalar_one_or_none()


async def get_user_for_update(db: AsyncSession, *, user_id: int) -> Optional[User]:
    """
    Вернуть пользователя «под блокировку» (FOR UPDATE SKIP LOCKED).
    Полезно в сервисах, где требуется атомарная работа с записью пользователя.
    """
    stmt = (
        select(User)
        .where(User.id == int(user_id))
        .with_for_update(skip_locked=True)
    )
    res = await db.execute(stmt)
    return res.scalar_one_or_none()


# =============================================================================
# UPDATE (без денег)
# =============================================================================

async def update_username_if_changed(db: AsyncSession, *, user_id: int, username: Optional[str]) -> Optional[User]:
    """
    Обновить username, если он изменился (без лишних flush).
    Возвращает объект или None, если пользователь не найден.
    """
    res = await db.execute(select(User).where(User.id == int(user_id)))
    obj = res.scalar_one_or_none()
    if not obj:
        return None
    if username is not None and (obj.username or "") != username:
        obj.username = username
        await db.flush()
    return obj


async def set_is_active(db: AsyncSession, *, user_id: int, is_active: bool) -> bool:
    """
    Включить/выключить пользователя (например, блокировка злоупотреблений).
    Возвращает True, если обновлена хотя бы одна запись.
    """
    res = await db.execute(
        update(User).where(User.id == int(user_id)).values(is_active=bool(is_active))
    )
    return res.rowcount > 0


async def set_vip_flag(db: AsyncSession, *, user_id: int, is_vip: bool) -> bool:
    """
    Установить флаг VIP (используется nft_check_service / scheduler.check_vip_nft).
    Денежных эффектов нет; ставка генерации учитывается в energy_service.
    """
    res = await db.execute(
        update(User).where(User.id == int(user_id)).values(is_vip=bool(is_vip))
    )
    return res.rowcount > 0


async def set_ton_wallet(db: AsyncSession, *, user_id: int, ton_wallet: Optional[str]) -> bool:
    """
    Присвоить/сбросить кошелёк TON. Валидация уникальности кошелька предполагается на уровне схемы
    (UNIQUE по ton_wallet NULLS NOT DISTINCT) либо в админ-логике выше.
    Здесь выполняем минимальную проверку формата (пустые строки → NULL).
    """
    wallet = (ton_wallet or "").strip() or None
    res = await db.execute(
        update(User).where(User.id == int(user_id)).values(ton_wallet=wallet)
    )
    return res.rowcount > 0


# =============================================================================
# LIST — курсорная пагинация (id ASC), без OFFSET
# =============================================================================

async def list_users_cursor(
    db: AsyncSession,
    *,
    is_active: Optional[bool] = None,
    is_vip: Optional[bool] = None,
    qtext: Optional[str] = None,
    limit: int = 50,
    next_cursor: Optional[str] = None,
) -> Tuple[List[User], Optional[str]]:
    """
    Вернуть пользователей курсором по (id ASC).
    Аргументы:
      • is_active — фильтр активных,
      • is_vip — фильтр VIP,
      • qtext — поиск по username ILIKE и/или точное совпадение telegram_id, если q — число,
      • limit — 1..200,
      • next_cursor — курсор (id, tie), выдаётся предыдущим вызовом.
    """
    limit = max(1, min(int(limit), 200))

    after_id: Optional[int] = None
    if next_cursor:
        after_id, _ = decode_cursor(next_cursor)

    stmt: Select = select(User)
    stmt = _apply_user_filters(stmt, is_active=is_active, is_vip=is_vip, qtext=qtext)
    if after_id is not None:
        stmt = stmt.where(User.id > after_id)
    stmt = stmt.order_by(User.id.asc()).limit(limit)

    rows = (await db.execute(stmt)).scalars().all()
    nxt = encode_cursor(rows[-1].id, 0) if rows and len(rows) == limit else None
    return list(rows), nxt


# =============================================================================
# ВЫБОРКИ ДЛЯ ПЛАНИРОВЩИКА / ИНТЕГРАЦИЙ
# =============================================================================

async def list_users_with_wallet_cursor(
    db: AsyncSession,
    *,
    limit: int = 500,
    next_cursor: Optional[str] = None,
) -> Tuple[List[User], Optional[str]]:
    """
    Вернуть пользователей с указанным ton_wallet (не NULL), курсор (id ASC).
    Используется в check_vip_nft для пакетной проверки NFT.
    """
    limit = max(1, min(int(limit), 1000))

    after_id: Optional[int] = None
    if next_cursor:
        after_id, _ = decode_cursor(next_cursor)

    stmt: Select = select(User).where(User.ton_wallet.is_not(None))
    if after_id is not None:
        stmt = stmt.where(User.id > after_id)
    stmt = stmt.order_by(User.id.asc()).limit(limit)

    rows = (await db.execute(stmt)).scalars().all()
    nxt = encode_cursor(rows[-1].id, 0) if rows and len(rows) == limit else None
    return list(rows), nxt


async def count_users(db: AsyncSession) -> int:
    """Быстрый счётчик пользователей (для метрик/панели админа)."""
    val = (await db.execute(select(func.count(User.id)))).scalar_one() or 0
    return int(val)


async def count_users_vip(db: AsyncSession) -> int:
    """Сколько пользователей с флагом VIP=true (для отчётности)."""
    val = (await db.execute(select(func.count(User.id)).where(User.is_vip.is_(True)))).scalar_one() or 0
    return int(val)


# =============================================================================
# Пояснения (для разработчиков/ревью):
# • Файл сознательно «тонкий»: CRUD и выборки. Никаких бизнес-правил денег.
# • ensure_user(...) реализует безопасное создание без гонок через ON CONFLICT DO NOTHING.
# • get_user_for_update(...) даёт FOR UPDATE SKIP LOCKED — сервисы могут атомарно работать с записью.
# • list_*_cursor(...) — единый паттерн курсоров на основе (id ASC). Курсор кодируем/декодируем через deps.
# • set_vip_flag / set_ton_wallet — простые апдейты статусов/кошелька, без побочных денежный эффектов.
# • Любые движения EFHC (выплаты, списания, конвертации) должны идти только через банковский сервис.
# =============================================================================
