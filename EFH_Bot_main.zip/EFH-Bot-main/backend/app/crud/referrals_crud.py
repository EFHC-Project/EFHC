# -*- coding: utf-8 -*-
# backend/app/crud/referrals_crud.py
# =============================================================================
# Назначение кода:
# CRUD-слой работы с БД для реферальной системы EFHC:
#   • Связи inviter↔invitee (создание/чтение/переназначение/активация).
#   • Витрины списков «Активные / Неактивные» с курсорной пагинацией (без OFFSET).
#   • Агрегаты для админ-панели (топ инвайтеров, суммы бонусов).
#   • Журнал бонусов рефералов (создание записей, суммирование, «ранговые» маркеры).
#
# Канон/инварианты:
# • «Активным» реферал становится после ПЕРВОЙ покупки панели (факт фиксируется вне этого CRUD,
#   здесь — только хранение флага is_active/activated_at).
# • Денежных операций в CRUD нет. Любые EFHC-движения делает единый банковский сервис.
# • Идемпотентность денег обеспечивается в банковском сервисе; в журнале рефералов можно хранить
#   ссылочные/описательные метаданные (meta) с idempotency_key/tx_id, но CRUD не эмитирует EFHC.
#
# ИИ-защита/самовосстановление:
# • Все списки — только курсорная пагинация по (id ASC) → устойчиво при росте данных.
# • Безопасные апдейты: IntegrityError на UNIQUE → мягко переводим в ValueError с пояснением.
# • Вспомогательные функции «heal» не требуются — этот слой тонкий и детерминированный.
#
# Запреты:
# • Никаких начислений EFHC/списаний — только запись фактов и чтение.
# • Никаких OFFSET-пагинаций — только курсоры.
# =============================================================================

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import List, Optional, Sequence, Tuple

from sqlalchemy import and_, func, select, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger
from backend.app.deps import d8, encode_cursor, decode_cursor
from backend.app.models.user_models import User
from backend.app.models.referral_models import ReferralLink, ReferralBonusLedger
from backend.app.schemas.referral_schemas import BonusRecordCreate

logger = get_logger(__name__)


# =============================================================================
# Связи inviter↔invitee
# =============================================================================

async def create_referral_link(
    db: AsyncSession,
    *,
    inviter_user_id: int,
    invitee_user_id: int,
    note: Optional[str] = None,
) -> ReferralLink:
    """
    Создать связь приглашения. Один invitee может иметь только одного inviter.
    UNIQUE-ограничение защищает от дублей.

    Исключения:
      • ValueError — если связь уже существует или нарушены внешние ключи.
    """
    link = ReferralLink(
        inviter_user_id=inviter_user_id,
        invitee_user_id=invitee_user_id,
        note=note,
    )
    db.add(link)
    try:
        await db.flush()
    except IntegrityError as e:
        await db.rollback()
        raise ValueError("Invitee already has an inviter or invalid IDs") from e
    return link


async def get_referral_link_by_invitee(
    db: AsyncSession,
    *,
    invitee_user_id: int,
) -> Optional[ReferralLink]:
    """
    Вернуть связь по приглашённому пользователю, либо None.
    """
    stmt = select(ReferralLink).where(ReferralLink.invitee_user_id == invitee_user_id).limit(1)
    res = await db.execute(stmt)
    return res.scalars().first()


async def get_referrals_by_inviter(
    db: AsyncSession,
    *,
    inviter_user_id: int,
) -> List[ReferralLink]:
    """
    Вернуть все связи по конкретному пригласившему (без пагинации).
    Используйте курсорные витрины list_*_cursor для UI-списков.
    """
    stmt = select(ReferralLink).where(ReferralLink.inviter_user_id == inviter_user_id).order_by(ReferralLink.id.asc())
    res = await db.execute(stmt)
    return list(res.scalars().all())


async def reassign_inviter(
    db: AsyncSession,
    *,
    invitee_user_id: int,
    new_inviter_user_id: int,
    note: Optional[str] = None,
) -> ReferralLink:
    """
    Переназначить пригласившего для приглашённого. Если связи не было — создаём.
    """
    link = await get_referral_link_by_invitee(db, invitee_user_id=invitee_user_id)
    if link is None:
        return await create_referral_link(
            db,
            inviter_user_id=new_inviter_user_id,
            invitee_user_id=invitee_user_id,
            note=note,
        )
    link.inviter_user_id = new_inviter_user_id
    link.note = note
    db.add(link)
    await db.flush()
    return link


async def activate_referral(
    db: AsyncSession,
    *,
    invitee_user_id: int,
    activation_bonus_hint: Optional[Decimal] = None,
) -> Optional[ReferralLink]:
    """
    Пометить реферала активным (после первой покупки панели).
    Возвращает обновлённую запись или None, если связи нет.

    Внимание: начисление бонусов EFHC делает сервис рефералов/банк. Здесь — только флаг.
    """
    link = await get_referral_link_by_invitee(db, invitee_user_id=invitee_user_id)
    if link is None:
        return None
    if not link.is_active:
        link.is_active = True
        link.activated_at = datetime.now(timezone.utc)
        # activation_bonus_efhc — это информационное поле (для UI/отчетов), деньги — только через банк
        if activation_bonus_hint is not None:
            link.activation_bonus_efhc = d8(activation_bonus_hint)
        db.add(link)
        await db.flush()
    return link


# =============================================================================
# Курсорные витрины «Активные / Неактивные»
# =============================================================================

async def list_active_refs_cursor(
    db: AsyncSession,
    *,
    inviter_user_id: int,
    limit: int = 50,
    next_cursor: Optional[str] = None,
) -> Tuple[List[ReferralLink], Optional[str]]:
    """
    Список активных рефералов (is_active=TRUE) по курсору.
    Курсор кодирует (id ASC). Без OFFSET.
    """
    limit = max(1, min(int(limit), 200))
    after_id: Optional[int] = None
    if next_cursor:
        after_id, _ = decode_cursor(next_cursor)  # используем первый компонент как id

    stmt = select(ReferralLink).where(
        and_(
            ReferralLink.inviter_user_id == inviter_user_id,
            ReferralLink.is_active.is_(True),
            (ReferralLink.id > after_id) if after_id is not None else True,
        )
    ).order_by(ReferralLink.id.asc()).limit(limit)

    res = await db.execute(stmt)
    items: List[ReferralLink] = list(res.scalars().all())
    next_c = encode_cursor(items[-1].id, 0) if items and len(items) == limit else None
    return items, next_c


async def list_inactive_refs_cursor(
    db: AsyncSession,
    *,
    inviter_user_id: int,
    limit: int = 50,
    next_cursor: Optional[str] = None,
) -> Tuple[List[ReferralLink], Optional[str]]:
    """
    Список неактивных рефералов (is_active=FALSE) по курсору.
    Курсор кодирует (id ASC). Без OFFSET.
    """
    limit = max(1, min(int(limit), 200))
    after_id: Optional[int] = None
    if next_cursor:
        after_id, _ = decode_cursor(next_cursor)

    stmt = select(ReferralLink).where(
        and_(
            ReferralLink.inviter_user_id == inviter_user_id,
            ReferralLink.is_active.is_(False),
            (ReferralLink.id > after_id) if after_id is not None else True,
        )
    ).order_by(ReferralLink.id.asc()).limit(limit)

    res = await db.execute(stmt)
    items: List[ReferralLink] = list(res.scalars().all())
    next_c = encode_cursor(items[-1].id, 0) if items and len(items) == limit else None
    return items, next_c


# =============================================================================
# Агрегаты по ссылкам
# =============================================================================

async def count_total_and_active(
    db: AsyncSession,
    *,
    inviter_user_id: int,
) -> Tuple[int, int]:
    """
    Вернуть (total, active) по инвайтеру.
    """
    q_total = select(func.count(ReferralLink.id)).where(ReferralLink.inviter_user_id == inviter_user_id)
    q_active = select(func.count(ReferralLink.id)).where(
        and_(ReferralLink.inviter_user_id == inviter_user_id, ReferralLink.is_active.is_(True))
    )
    total = int((await db.execute(q_total)).scalar_one() or 0)
    active = int((await db.execute(q_active)).scalar_one() or 0)
    return total, active


# =============================================================================
# Журнал бонусов рефералов (НЕ деньги, деньги — только через банк!)
# =============================================================================

async def add_bonus_record(
    db: AsyncSession,
    *,
    payload: BonusRecordCreate,
) -> ReferralBonusLedger:
    """
    Добавить строку в журнал бонусов рефералов.
    Суммы приводятся к Decimal(8) вниз. Денежное начисление EFHC должен сделать банковский сервис.
    """
    rec = ReferralBonusLedger(
        user_id=int(payload.user_id),
        amount_efhc=d8(payload.amount_efhc),
        kind=str(payload.kind),
        meta=payload.meta,
        created_at=datetime.now(timezone.utc),
    )
    db.add(rec)
    await db.flush()
    return rec


async def sum_bonus_for_user(
    db: AsyncSession,
    *,
    user_id: int,
) -> Decimal:
    """
    Вернуть сумму EFHC из журнала бонусов по user_id.
    Это отчётная сумма журнала, она НЕ является балансом (баланс — в users.*balance).
    """
    stmt = select(func.coalesce(func.sum(ReferralBonusLedger.amount_efhc), 0)).where(
        ReferralBonusLedger.user_id == user_id
    )
    val = (await db.execute(stmt)).scalar_one() or 0
    return d8(Decimal(val))


async def has_rank_bonus_paid(
    db: AsyncSession,
    *,
    user_id: int,
    threshold: int,
) -> bool:
    """
    Проверить, выплачивался ли ранговый бонус (по порогу активных рефералов).
    По соглашению, meta содержит «rank_threshold=<N>».
    """
    stmt = select(func.count(ReferralBonusLedger.id)).where(
        and_(
            ReferralBonusLedger.user_id == user_id,
            ReferralBonusLedger.kind == "rank",
            ReferralBonusLedger.meta.ilike(f"%rank_threshold={threshold}%"),
        )
    )
    return (await db.execute(stmt)).scalar_one() > 0


# =============================================================================
# Админские выборки/топы (для витрин)
# =============================================================================

async def admin_top_inviters(
    db: AsyncSession,
    *,
    limit: int = 10,
) -> Sequence:
    """
    Топ по активным рефералам и сумме бонусов.

    SQL-идея:
      • active_subq: count(*) по is_active=TRUE группой по inviter.
      • bonus_subq: sum(amount_efhc) по журналу бонусов (user_id).
      • Объединяем с users для получения username.
    """
    active_subq = (
        select(
            ReferralLink.inviter_user_id.label("uid"),
            func.count(ReferralLink.id).label("active_count"),
        )
        .where(ReferralLink.is_active.is_(True))
        .group_by(ReferralLink.inviter_user_id)
        .subquery()
    )

    bonus_subq = (
        select(
            ReferralBonusLedger.user_id.label("uid"),
            func.coalesce(func.sum(ReferralBonusLedger.amount_efhc), 0).label("bonus_sum"),
        )
        .group_by(ReferralBonusLedger.user_id)
        .subquery()
    )

    stmt = (
        select(
            User.id,
            User.username,
            func.count(ReferralLink.id).label("total_invited"),
            func.coalesce(active_subq.c.active_count, 0).label("active_invited"),
            func.coalesce(bonus_subq.c.bonus_sum, 0).label("total_bonus_efhc"),
        )
        .join(ReferralLink, ReferralLink.inviter_user_id == User.id, isouter=True)
        .join(active_subq, active_subq.c.uid == User.id, isouter=True)
        .join(bonus_subq, bonus_subq.c.uid == User.id, isouter=True)
        .group_by(User.id, User.username, active_subq.c.active_count, bonus_subq.c.bonus_sum)
        .order_by(func.coalesce(active_subq.c.active_count, 0).desc(), func.coalesce(bonus_subq.c.bonus_sum, 0).desc())
        .limit(max(1, min(int(limit), 100)))
    )
    res = await db.execute(stmt)
    return res.all()


# =============================================================================
# Пояснения (для разработчиков/ревью):
# • CRUD не двигает деньги — только хранит факты (связи и журнал бонусов). Любые EFHC-списки/начисления
#   делаются строго банковским сервисом (transactions_service).
# • Витрины списков используют курсорную пагинацию по (id ASC) — надёжно и масштабируемо.
# • list_active_refs_cursor / list_inactive_refs_cursor дают «чистые» выборки для UI «Активные / Неактивные».
# • Активность реферала устанавливается сервисом панелей при первой покупке (здесь только флаг).
# • Админ-топ объединяет активных приглашённых и суммы бонусов из журнала — для дашборда.
# =============================================================================
