# -*- coding: utf-8 -*-
# backend/app/crud/panels_crud.py
# =============================================================================
# Назначение кода:
# CRUD-утилиты уровня БД для сущностей «панелей»:
#   • создание панели пользователю (с канонической ставкой per-sec),
#   • выборка активных / архивных панелей с курсорной пагинацией (без OFFSET),
#   • безопасная блокировка активных панелей для начисления энергии
#     (FOR UPDATE SKIP LOCKED) — чтобы несколько воркеров не спорили,
#   • массовое закрытие/архивация просроченных панелей,
#   • точечное накапливание generated_kwh с округлением вниз до 8 знаков,
#   • сервисные «самовосстановительные» проверки и исправления (ИИ-защита).
#
# Канон/инварианты (важно):
# • Ставки генерации — только per-sec:
#     GEN_PER_SEC_BASE_KWH = 0.00000692
#     GEN_PER_SEC_VIP_KWH  = 0.00000741
#   В БД каждая панель хранит «base_gen_per_sec» — числовое поле (Decimal(8)).
#   VIP-бонус применяется не здесь (это уровень сервисов расчёта энергии).
# • Запрещены любые «суточные» абстракции и пересчёты: только секунды.
# • Денежные/балансовые действия (списания/начисления EFHC) здесь НЕ выполняются —
#   это делает банковский сервис. Панели_crud работает только с данными панелей.
#
# ИИ-защита/самовосстановление:
# • Выборки «на обработку» используют FOR UPDATE SKIP LOCKED.
# • Функции архивирования и reconcile_* аккуратно правят данные без падения.
# • Все числа кВт⋅ч округляются вниз до 8 знаков (через централизованный d8()).
#
# Запреты:
# • Никаких операций EFHC, P2P, обменов и т.п. — только панели.
# • Никаких «дневных» ставок/пересчётов — только per-sec.
# =============================================================================

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import and_, func, select, update, delete
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import aliased

from backend.app.core.config_core import get_settings
from backend.app.core.logging_core import get_logger
from backend.app.deps import (
    d8,                    # Decimal → Decimal с 8 знаками (ROUND_DOWN)
    encode_cursor,         # курсор (created_at,id) → base64
    decode_cursor,         # base64 → (created_at,id)
)
from backend.app.models.panels_models import Panel, PanelArchive

logger = get_logger(__name__)
settings = get_settings()

# Канон per-sec ставок (источник истины — .env / config_core)
GEN_PER_SEC_BASE_KWH = Decimal(str(settings.GEN_PER_SEC_BASE_KWH))
GEN_PER_SEC_VIP_KWH  = Decimal(str(settings.GEN_PER_SEC_VIP_KWH))

# Срок жизни панели по умолчанию (дней)
DEFAULT_PANEL_LIFETIME_DAYS: int = 180

# Максимум активных панелей у пользователя (канон)
MAX_PANELS: int = int(getattr(settings, "MAX_PANELS", 1000) or 1000)


# =============================================================================
# ВСПОМОГАТЕЛЬНОЕ: генерация курсора из записи панели
# -----------------------------------------------------------------------------
def _make_cursor_for_panel(p: Panel) -> str:
    """
    Курсор строим по (created_at, id) — стабильный порядок, без OFFSET.
    """
    return encode_cursor(p.created_at, p.id)


# =============================================================================
# CREATE
# -----------------------------------------------------------------------------
async def create_panel(
    db: AsyncSession,
    *,
    user_id: int,
    base_gen_per_sec: Optional[Decimal] = None,
    lifetime_days: int = DEFAULT_PANEL_LIFETIME_DAYS,
    now: Optional[datetime] = None,
) -> Panel:
    """
    Создаёт новую панель для пользователя.
    • base_gen_per_sec — числовое значение per-sec ставки панели; если None — берём канон GEN_PER_SEC_BASE_KWH.
    • lifetime_days — срок жизни (обычно 180).
    • Генерация на панели начинается с generated_kwh = 0, last_generated_at = now.
    • Лимит MAX_PANELS НЕ проверяется здесь (это обязанность сервисного уровня покупки).
    """
    ts = now or datetime.now(timezone.utc)
    bps = base_gen_per_sec if base_gen_per_sec is not None else GEN_PER_SEC_BASE_KWH

    p = Panel(
        user_id=user_id,
        created_at=ts,
        expires_at=ts + timedelta(days=int(lifetime_days)),
        last_generated_at=ts,
        base_gen_per_sec=d8(bps),  # храним с точностью до 8
        generated_kwh=d8(0),
        is_active=True,
    )
    db.add(p)
    await db.flush()  # получим p.id
    logger.debug("create_panel: user_id=%s panel_id=%s bps=%s", user_id, p.id, p.base_gen_per_sec)
    return p


# =============================================================================
# READ: одна панель, счётчики, лимиты
# -----------------------------------------------------------------------------
async def get_panel(db: AsyncSession, panel_id: int) -> Optional[Panel]:
    """Возвращает панель по id (или None)."""
    res = await db.execute(select(Panel).where(Panel.id == panel_id))
    return res.scalars().first()


async def count_active_by_user(db: AsyncSession, user_id: int) -> int:
    """Считает активные панели пользователя (для проверки лимита на уровне сервисов)."""
    res = await db.execute(
        select(func.count(Panel.id)).where(and_(Panel.user_id == user_id, Panel.is_active.is_(True)))
    )
    return int(res.scalar_one() or 0)


# =============================================================================
# LIST: активные панели пользователя (курсоры без OFFSET)
# -----------------------------------------------------------------------------
async def list_active_by_user_cursor(
    db: AsyncSession,
    *,
    user_id: int,
    limit: int = 50,
    next_cursor: Optional[str] = None,
    asc: bool = False,
) -> Tuple[List[Panel], Optional[str]]:
    """
    Возвращает страницу активных панелей пользователя.
    Пагинация — по курсору (created_at, id), без OFFSET.
    """
    limit = max(1, min(int(limit), 200))

    created_from: Optional[datetime] = None
    id_from: Optional[int] = None
    if next_cursor:
        created_from, id_from = decode_cursor(next_cursor)

    q = select(Panel).where(and_(Panel.user_id == user_id, Panel.is_active.is_(True)))

    if created_from is not None and id_from is not None:
        # курсор: (created_at, id)
        if asc:
            q = q.where(
                (Panel.created_at, Panel.id) > (created_from, id_from)
            )
        else:
            q = q.where(
                (Panel.created_at, Panel.id) < (created_from, id_from)
            )

    # порядок стабилен, курсор построен аналогично
    if asc:
        q = q.order_by(Panel.created_at.asc(), Panel.id.asc())
    else:
        q = q.order_by(Panel.created_at.desc(), Panel.id.desc())

    q = q.limit(limit)
    res = await db.execute(q)
    items: List[Panel] = list(res.scalars().all())

    next_c = _make_cursor_for_panel(items[-1]) if items and len(items) == limit else None
    return items, next_c


# =============================================================================
# LIST: архивные панели пользователя (курсоры без OFFSET)
# -----------------------------------------------------------------------------
async def list_archived_by_user_cursor(
    db: AsyncSession,
    *,
    user_id: int,
    limit: int = 50,
    next_cursor: Optional[str] = None,
    asc: bool = False,
) -> Tuple[List[PanelArchive], Optional[str]]:
    """
    Возвращает страницу архивных панелей пользователя.
    Пагинация — по курсору (archived_at, id), без OFFSET.
    """
    limit = max(1, min(int(limit), 200))
    archived_from: Optional[datetime] = None
    id_from: Optional[int] = None
    if next_cursor:
        archived_from, id_from = decode_cursor(next_cursor)

    q = select(PanelArchive).where(PanelArchive.user_id == user_id)

    if archived_from is not None and id_from is not None:
        if asc:
            q = q.where(
                (PanelArchive.archived_at, PanelArchive.id) > (archived_from, id_from)
            )
        else:
            q = q.where(
                (PanelArchive.archived_at, PanelArchive.id) < (archived_from, id_from)
            )

    if asc:
        q = q.order_by(PanelArchive.archived_at.asc(), PanelArchive.id.asc())
    else:
        q = q.order_by(PanelArchive.archived_at.desc(), PanelArchive.id.desc())

    q = q.limit(limit)
    res = await db.execute(q)
    items: List[PanelArchive] = list(res.scalars().all())

    if items and len(items) == limit:
        last = items[-1]
        next_c = encode_cursor(last.archived_at, last.id)
    else:
        next_c = None

    return items, next_c


# =============================================================================
# LOCK-FETCH: выдача активных панелей для начисления энергии
# -----------------------------------------------------------------------------
async def lock_active_panels_for_energy(
    db: AsyncSession,
    *,
    limit: int = 500,
) -> List[Panel]:
    """
    Возвращает «пакет» активных панелей под обработку начисления энергии,
    блокируя их SKIP LOCKED — чтобы несколько воркеров не обрабатывали
    одни и те же панели.
    Порядок: по id (стабильно).
    """
    limit = max(1, min(int(limit), 2000))
    q = (
        select(Panel)
        .where(Panel.is_active.is_(True))
        .order_by(Panel.id.asc())
        .limit(limit)
        .with_for_update(skip_locked=True)
    )
    res = await db.execute(q)
    panels: List[Panel] = list(res.scalars().all())
    return panels


# =============================================================================
# UPDATE: накапливание энергии по панели
# -----------------------------------------------------------------------------
async def accrue_generated_kwh(
    db: AsyncSession,
    *,
    panel_id: int,
    delta_kwh: Decimal,
    new_last_generated_at: Optional[datetime] = None,
) -> Optional[Panel]:
    """
    Приращивает generated_kwh панели на delta_kwh (>=0) с округлением вниз до 8 знаков
    и обновляет last_generated_at, если передан.
    Возвращает обновлённую панель или None (если не найдена/неактивна).
    """
    if delta_kwh <= 0:
        # ничего не делаем — это не ошибка
        logger.debug("accrue_generated_kwh: skip non-positive delta (panel_id=%s, delta=%s)", panel_id, delta_kwh)
        res = await db.execute(select(Panel).where(Panel.id == panel_id))
        return res.scalars().first()

    res = await db.execute(select(Panel).where(and_(Panel.id == panel_id, Panel.is_active.is_(True))))
    p: Optional[Panel] = res.scalars().first()
    if not p:
        return None

    # вычисляем новое значение
    new_val = d8(Decimal(p.generated_kwh or 0) + Decimal(delta_kwh))
    p.generated_kwh = new_val
    if new_last_generated_at:
        p.last_generated_at = new_last_generated_at
    await db.flush()
    return p


# =============================================================================
# EXPIRE/ARCHIVE: перевод просроченных панелей в архив
# -----------------------------------------------------------------------------
async def close_and_archive_due_panels(
    db: AsyncSession,
    *,
    now: Optional[datetime] = None,
    batch_limit: int = 1000,
) -> int:
    """
    Находит активные панели с истёкшим сроком (expires_at <= now),
    помечает их неактивными и переносит в PanelArchive.
    Возвращает количество переведённых в архив.
    """
    ts = now or datetime.now(timezone.utc)

    # 1) достаём список просроченных активных панелей небольшими пачками
    q = (
        select(Panel)
        .where(and_(Panel.is_active.is_(True), Panel.expires_at <= ts))
        .order_by(Panel.id.asc())
        .limit(max(1, min(int(batch_limit), 5000)))
        .with_for_update(skip_locked=True)
    )
    res = await db.execute(q)
    to_close: List[Panel] = list(res.scalars().all())
    if not to_close:
        return 0

    count = 0
    for p in to_close:
        # ставим флаг
        p.is_active = False
        await db.flush()

        # переносим в архив
        arch = PanelArchive(
            user_id=p.user_id,
            created_at=p.created_at,
            expires_at=p.expires_at,
            archived_at=ts,
            base_gen_per_sec=p.base_gen_per_sec,
            generated_kwh=p.generated_kwh,
            last_generated_at=p.last_generated_at,
            source_panel_id=p.id,
        )
        db.add(arch)
        count += 1

    await db.flush()
    logger.info("close_and_archive_due_panels: archived=%s", count)
    return count


# =============================================================================
# RECONCILE / HEALING: самовосстановительные помощники
# -----------------------------------------------------------------------------
async def reconcile_negative_or_nulls(db: AsyncSession) -> int:
    """
    ИИ-защита: приводит поля generated_kwh к допустимым значениям.
    • Если где-то оказалась отрицательная generated_kwh — поднимаем до 0.
    • last_generated_at NULL — ставим created_at (чтобы не ломать догон).
    Возвращает количество «подлеченных» строк.
    """
    fixed = 0

    # generated_kwh < 0 → 0
    res = await db.execute(
        select(Panel).where(and_(Panel.generated_kwh.isnot(None), Panel.generated_kwh < 0))
    )
    bad_panels: List[Panel] = list(res.scalars().all())
    for p in bad_panels:
        p.generated_kwh = d8(0)
        fixed += 1

    # last_generated_at is NULL → created_at
    res = await db.execute(select(Panel).where(Panel.last_generated_at.is_(None)))
    missing_ts: List[Panel] = list(res.scalars().all())
    for p in missing_ts:
        p.last_generated_at = p.created_at
        fixed += 1

    if fixed:
        await db.flush()
        logger.warning("reconcile_negative_or_nulls: fixed=%s", fixed)
    return fixed


async def reconcile_orphan_archives(db: AsyncSession) -> int:
    """
    ИИ-защита: если вдруг есть неактивные панели (is_active=False) без записи в PanelArchive,
    переносим их в архив, чтобы витрины были согласованы.
    Возвращает число перенесённых.
    """
    # находим «неактивные без архива»
    A = aliased(PanelArchive)
    q = (
        select(Panel)
        .where(Panel.is_active.is_(False))
        .where(~select(A.id).where(A.source_panel_id == Panel.id).exists())
        .order_by(Panel.id.asc())
        .limit(5000)
        .with_for_update(skip_locked=True)
    )
    res = await db.execute(q)
    items: List[Panel] = list(res.scalars().all())
    if not items:
        return 0

    ts = datetime.now(timezone.utc)
    for p in items:
        arch = PanelArchive(
            user_id=p.user_id,
            created_at=p.created_at,
            expires_at=p.expires_at,
            archived_at=ts,
            base_gen_per_sec=p.base_gen_per_sec,
            generated_kwh=p.generated_kwh,
            last_generated_at=p.last_generated_at,
            source_panel_id=p.id,
        )
        db.add(arch)

    await db.flush()
    logger.warning("reconcile_orphan_archives: created archives=%s", len(items))
    return len(items)


# =============================================================================
# ВСПОМОГАТЕЛЬНОЕ: принудительная правка ставки на канон (если понадобится)
# -----------------------------------------------------------------------------
async def force_reset_base_rate_to_canon(
    db: AsyncSession,
    *,
    panel_ids: Sequence[int],
) -> int:
    """
    Опционально: для аварийного исправления панелей, которым ошибочно
    проставили «не каноническую» ставку base_gen_per_sec.
    Здесь просто возвращаем значение на GEN_PER_SEC_BASE_KWH (не VIP!).
    Возвращает число обновлённых строк.
    """
    if not panel_ids:
        return 0
    q = (
        update(Panel)
        .where(Panel.id.in_(list(panel_ids)))
        .values(base_gen_per_sec=d8(GEN_PER_SEC_BASE_KWH))
    )
    res = await db.execute(q)
    n = int(res.rowcount or 0)
    if n:
        await db.flush()
        logger.warning("force_reset_base_rate_to_canon: fixed=%s", n)
    return n


# =============================================================================
# Пояснения (для разработчиков/ревью):
# • list_*_by_user_cursor: курсор формируется по (created_at,id)/(archived_at,id).
#   Это гарантирует стабильный «бесконечный скролл» без OFFSET.
# • lock_active_panels_for_energy: SKIP LOCKED защищает от гонок между воркерами
#   начисления энергии. Обработка идёт пакетами, порядок — id.
# • accrue_generated_kwh: только накапливает кВт⋅ч по панели (Decimal с 8 знаками),
#   никаких операций с EFHC. Обновление балансов пользователя — вне этого модуля.
# • close_and_archive_due_panels: аккуратно снимает флаг активности и создаёт
#   зеркальную запись в PanelArchive (для витрин «Архив»).
# • reconcile_* функции — это ИИ-поддержка целостности, не «ломают» поток, а
#   молча лечат данные и пишут предупреждения в лог.
# =============================================================================
