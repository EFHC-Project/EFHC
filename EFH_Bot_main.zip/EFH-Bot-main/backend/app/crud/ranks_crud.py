# -*- coding: utf-8 -*-
# backend/app/crud/ranks_crud.py
# =============================================================================
# Назначение кода:
# CRUD-утилиты уровня БД для витрин рейтинга EFHC («Я + TOP»):
#   • построение снапшота рейтинга из таблицы users (по total_generated_kwh),
#   • хранение «среза» в таблицах rating_* (без тяжёлых live-запросов в UI),
#   • курсорная пагинация без OFFSET по снапшоту,
#   • вычисление места пользователя (live или по снапшоту),
#   • самовосстановительные помощники (force_refresh, heal) для ИИ-цикла.
#
# Канон/инварианты (важно):
# • Источник рейтинга — только total_generated_kwh (НЕ available_kwh).
# • «Я + TOP»: «Я» показывается один раз (без дублирования), TOP — по убыванию total.
# • Пагинация — только курсорная (created_at,id) или (rank_position,id), без OFFSET.
# • Никаких «суточных» ставок: рейтинг не связан с генерацией per-sec, он агрегат.
#
# ИИ-защита/самовосстановление:
# • Если нет актуального снапшота — можно быстро собрать live-ранг пользователя и TOP.
# • force_refresh пересобирает снапшот атомарно; heal чинит неполный/битый срез.
# • Все суммы кВт⋅ч приводятся к Decimal с 8 знаками (округление вниз).
#
# Запреты:
# • Никаких операций с EFHC/балансами — только чтение/снапшоты рейтинга.
# • Никаких OFFSET-витрин — только курсоры.
# =============================================================================

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import List, Optional, Sequence, Tuple

from sqlalchemy import and_, desc, func, literal_column, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.dialects.postgresql import insert

from backend.app.core.logging_core import get_logger
from backend.app.core.config_core import get_settings
from backend.app.deps import d8, encode_cursor, decode_cursor
from backend.app.models.user_models import User
from backend.app.models.rating_models import (
    RatingSnapshot,
    RatingUserSnapshot,
)

logger = get_logger(__name__)
settings = get_settings()


# =============================================================================
# ВСПОМОГАТЕЛЬНОЕ: курсор для строки снапшота пользователя
# -----------------------------------------------------------------------------
def _cursor_for_snapshot_row(row: RatingUserSnapshot) -> str:
    """
    Курсор стабильный: (rank_position ASC, id ASC) → base64.
    """
    return encode_cursor(row.rank_position, row.id)


# =============================================================================
# READ: получить последний снапшот
# -----------------------------------------------------------------------------
async def get_latest_snapshot(db: AsyncSession) -> Optional[RatingSnapshot]:
    """
    Возвращает последний (по snapshot_at DESC, id DESC) RatingSnapshot.
    """
    q = (
        select(RatingSnapshot)
        .order_by(RatingSnapshot.snapshot_at.desc(), RatingSnapshot.id.desc())
        .limit(1)
    )
    res = await db.execute(q)
    return res.scalars().first()


# =============================================================================
# BUILD: пересобрать снепшот рейтинга из users
# -----------------------------------------------------------------------------
async def build_snapshot_from_users(
    db: AsyncSession,
    *,
    top_size: int = 100,
    note: Optional[str] = None,
    snapshot_at: Optional[datetime] = None,
) -> RatingSnapshot:
    """
    Строит новый снапшот рейтинга:
      1) Создаёт запись RatingSnapshot (пустую).
      2) Выбирает TOP-N пользователей по total_generated_kwh (NULL → 0),
         с детерминированной сортировкой: total DESC, user_id ASC.
      3) Вычисляет позицию (row_number) и массово вставляет в RatingUserSnapshot.
    Возвращает созданный RatingSnapshot.

    Почему row_number: реальные «места» без пропусков (1,2,3…), устойчиво для витрины.
    """
    top_n = max(1, min(int(top_size), 1000))
    ts = snapshot_at or datetime.now(timezone.utc)

    # 1) завести запись снапшота
    snap = RatingSnapshot(snapshot_at=ts, note=note or "", top_size=top_n)
    db.add(snap)
    await db.flush()  # получим snap.id

    # 2) подготовить live выборку с row_number
    # coalesce(total_generated_kwh, 0) как total
    total_expr = func.coalesce(User.total_generated_kwh, Decimal("0"))
    subq = (
        select(
            User.id.label("user_id"),
            User.telegram_id.label("telegram_id"),
            User.username.label("username"),
            total_expr.label("total"),
            func.row_number()
            .over(order_by=(desc(total_expr), User.id.asc()))
            .label("pos"),
        )
        .where(User.is_active.is_(True))  # только активные пользователи
        .subquery()
    )
    q = (
        select(
            subq.c.user_id,
            subq.c.telegram_id,
            subq.c.username,
            subq.c.total,
            subq.c.pos,
        )
        .where(subq.c.pos <= top_n)
        .order_by(subq.c.pos.asc(), subq.c.user_id.asc())
    )
    rows = (await db.execute(q)).all()

    # 3) bulk insert в RatingUserSnapshot
    payload = [
        dict(
            snapshot_id=snap.id,
            user_id=int(r.user_id),
            telegram_id=int(r.telegram_id) if r.telegram_id is not None else None,
            username=r.username,
            total_generated_kwh=d8(r.total),
            rank_position=int(r.pos),
            created_at=ts,
        )
        for r in rows
    ]
    if payload:
        await db.execute(insert(RatingUserSnapshot), payload)
    await db.flush()

    logger.info("build_snapshot_from_users: snap_id=%s items=%s", snap.id, len(payload))
    return snap


# =============================================================================
# HEAL: восстановление битого снапшота (если строк меньше, чем top_size)
# -----------------------------------------------------------------------------
async def heal_snapshot_if_incomplete(
    db: AsyncSession,
    *,
    snapshot: RatingSnapshot,
) -> bool:
    """
    Если снапшот есть, но строк меньше snapshot.top_size — пересобираем.
    Возвращает True, если лечили (пересобирали).
    """
    qcnt = select(func.count(RatingUserSnapshot.id)).where(
        RatingUserSnapshot.snapshot_id == snapshot.id
    )
    count = int((await db.execute(qcnt)).scalar_one() or 0)
    if count >= int(snapshot.top_size or 0):
        return False

    # Пересобрать снепшот: создаём НОВЫЙ, старый оставляем как есть (аудит)!
    await build_snapshot_from_users(
        db,
        top_size=int(snapshot.top_size or 100),
        note=f"heal {snapshot.id}",
        snapshot_at=datetime.now(timezone.utc),
    )
    logger.warning("heal_snapshot_if_incomplete: repaired by new snapshot (old_id=%s)", snapshot.id)
    return True


# =============================================================================
# PAGE: получить страницу TOP по снапшоту (без OFFSET)
# -----------------------------------------------------------------------------
async def list_snapshot_top_cursor(
    db: AsyncSession,
    *,
    snapshot_id: int,
    limit: int = 100,
    next_cursor: Optional[str] = None,
    asc: bool = True,
) -> Tuple[List[RatingUserSnapshot], Optional[str]]:
    """
    Возвращает страницу из RatingUserSnapshot:
      • сортировка по rank_position ASC (стабильно), tiebreaker: id ASC,
      • курсор — (rank_position, id).
    """
    limit = max(1, min(int(limit), 500))

    pos_from: Optional[int] = None
    id_from: Optional[int] = None
    if next_cursor:
        # для простоты используем те же кодеки: первый компонент int (rank), второй int (id)
        pos_from, id_from = decode_cursor(next_cursor)

    q = select(RatingUserSnapshot).where(RatingUserSnapshot.snapshot_id == snapshot_id)

    if pos_from is not None and id_from is not None:
        if asc:
            q = q.where((RatingUserSnapshot.rank_position, RatingUserSnapshot.id) > (pos_from, id_from))
        else:
            q = q.where((RatingUserSnapshot.rank_position, RatingUserSnapshot.id) < (pos_from, id_from))

    if asc:
        q = q.order_by(RatingUserSnapshot.rank_position.asc(), RatingUserSnapshot.id.asc())
    else:
        q = q.order_by(RatingUserSnapshot.rank_position.desc(), RatingUserSnapshot.id.desc())

    q = q.limit(limit)
    res = await db.execute(q)
    items: List[RatingUserSnapshot] = list(res.scalars().all())

    next_c = _cursor_for_snapshot_row(items[-1]) if items and len(items) == limit else None
    return items, next_c


# =============================================================================
# LIVE: вычислить место пользователя «на лету» (без снапшота)
# -----------------------------------------------------------------------------
async def get_user_rank_live(
    db: AsyncSession,
    *,
    user_id: int,
) -> Tuple[int, Decimal]:
    """
    Возвращает детерминированный live-ранг пользователя и его total:
      • total_u = COALESCE(user.total_generated_kwh, 0)
      • rank = 1
               + COUNT(users WHERE total > total_u)
               + COUNT(users WHERE total = total_u AND id < user_id)
    Такая формула избегает тяжёлых оконных функций в больших таблицах и
    даёт стабильный порядок при равенстве total (tiebreaker: id ASC).
    """
    # 1) мой total
    q_me = select(func.coalesce(User.total_generated_kwh, Decimal("0"))).where(User.id == user_id)
    me_total = (await db.execute(q_me)).scalar_one_or_none()
    total_u = d8(me_total or Decimal("0"))

    # 2) сколько строгих больше
    q_gt = select(func.count(User.id)).where(func.coalesce(User.total_generated_kwh, 0) > total_u)
    cnt_gt = int((await db.execute(q_gt)).scalar_one() or 0)

    # 3) сколько равных по total, но с меньшим id (tiebreak)
    q_eq_lt = select(func.count(User.id)).where(
        and_(
            func.coalesce(User.total_generated_kwh, 0) == total_u,
            User.id < user_id,
        )
    )
    cnt_eq_lt = int((await db.execute(q_eq_lt)).scalar_one() or 0)

    rank = 1 + cnt_gt + cnt_eq_lt
    return rank, total_u


# =============================================================================
# SNAPSHOT: получить позицию пользователя из снапшота (если входит в TOP)
# -----------------------------------------------------------------------------
async def get_user_rank_from_snapshot(
    db: AsyncSession,
    *,
    snapshot_id: int,
    user_id: int,
) -> Optional[Tuple[int, Decimal]]:
    """
    Возвращает (rank_position, total) пользователя из снапшота, если он попал в TOP.
    Иначе — None.
    """
    q = select(
        RatingUserSnapshot.rank_position,
        RatingUserSnapshot.total_generated_kwh,
    ).where(
        and_(
            RatingUserSnapshot.snapshot_id == snapshot_id,
            RatingUserSnapshot.user_id == user_id,
        )
    )
    row = (await db.execute(q)).first()
    if not row:
        return None
    return int(row.rank_position), d8(row.total_generated_kwh)


# =============================================================================
# FORCE REFRESH: атомарная пересборка снапшота
# -----------------------------------------------------------------------------
async def force_refresh_snapshot(
    db: AsyncSession,
    *,
    top_size: int = 100,
    note: Optional[str] = None,
) -> RatingSnapshot:
    """
    Полная пересборка нового снапшота. Старые снапшоты не удаляются (аудит).
    """
    snap = await build_snapshot_from_users(
        db,
        top_size=int(top_size),
        note=note or "force_refresh",
        snapshot_at=datetime.now(timezone.utc),
    )
    logger.info("force_refresh_snapshot: new snap_id=%s", snap.id)
    return snap


# =============================================================================
# ВСПОМОГАТЕЛЬНОЕ: список user_id из снапшота (для «Я + TOP» фильтрации)
# -----------------------------------------------------------------------------
async def list_user_ids_in_snapshot(
    db: AsyncSession,
    *,
    snapshot_id: int,
) -> List[int]:
    """
    Возвращает список user_id, присутствующих в TOP снапшота.
    Используется, чтобы не дублировать «Я» при построении «Я + TOP».
    """
    q = select(RatingUserSnapshot.user_id).where(RatingUserSnapshot.snapshot_id == snapshot_id)
    res = await db.execute(q)
    return [int(x) for x, in res.all()]


# =============================================================================
# Пояснения (для разработчиков/ревью):
# • build_snapshot_from_users использует row_number() по total DESC, id ASC,
#   чтобы «места» шли 1..N без пропусков и порядок был детерминированным.
# • list_snapshot_top_cursor — курсорная пагинация по (rank_position,id).
#   Никаких OFFSET — устойчиво и масштабируемо.
# • get_user_rank_live — формула ранга без оконных функций на каждую строку,
#   но с детерминированным tiebreak (id ASC) — быстро и просто.
# • heal_snapshot_if_incomplete и force_refresh_snapshot — кирпичики ИИ-поддержки:
#   если снапшот битый/короткий — собираем новый, старый оставляем в аудите.
# • CRUD-уровень гарантирует только операции с данными рейтинга; «Я + TOP»,
#   слияние витрин без дублирования «Я», ETag/кэш — это уровень services/routes.
# =============================================================================
