# -*- coding: utf-8 -*-
# backend/app/crud/transactions_crud.py
# =============================================================================
# Назначение кода:
# CRUD-слой БД для двух журналов:
#   • efhc_transfers_log — «зеркальная» фиксация всех движений EFHC между Банком и пользователем
#     (ДЕНЬГИ НЕ ДВИГАЕМ! Только запись/чтение фактов для сервисов/отчётности).
#   • ton_inbox_logs — входящие транзакции TON для вотчера (idempotency по tx_hash, статусы, ретраи).
#
# Канон/инварианты:
# • Денежные операции выполняются исключительно в services/transactions_service.py.
# • Здесь НЕТ списаний/начислений. Только работа с журналами/выборками.
# • Идемпотентность:
#     - efhc_transfers_log.idempotency_key имеет UNIQUE.
#     - ton_inbox_logs.tx_hash имеет UNIQUE.
# • Пагинация только курсорная (без OFFSET) по (id ASC).
#
# ИИ-защита/самовосстановление:
# • «Read-through insert»: при конфликте уникальности (idempotency_key/tx_hash) возвращаем уже существующую запись,
#   а не падаем — верхний слой может продолжать как будто операция завершена.
# • Списки «к обработке» выбираются детерминированно (status и next_retry_at), чтобы догонять хвосты.
#
# Запреты:
# • Никаких UPDATE балансов пользователей или Банка.
# • Нельзя выполнять конвертации, покупки, эмиссии — только логи и выборки.
# =============================================================================

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import List, Optional, Sequence, Tuple

from sqlalchemy import Select, and_, func, select, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.logging_core import get_logger
from backend.app.deps import d8, encode_cursor, decode_cursor
from backend.app.models.transactions_models import (
    EfhcTransferLog,   # ожидаемые поля: id, user_id, amount_efhc, direction, balance_type, reason, idempotency_key, created_at
    TonInboxLog,       # ожидаемые поля: id, tx_hash, from_address, to_address, amount, memo, status, next_retry_at, retries_count, last_error, processed_at, created_at, updated_at
)

logger = get_logger(__name__)


# =============================================================================
# EFHC TRANSFERS LOG — insert/get/list/aggregate
# =============================================================================

async def insert_transfer_log_readthrough(
    db: AsyncSession,
    *,
    user_id: int,
    amount_efhc: Decimal,
    direction: str,        # 'credit' | 'debit'
    balance_type: str,     # 'main' | 'bonus'
    reason: str,           # короткий маркер: 'exchange', 'panel_buy', 'admin_issue', 'task_bonus', ...
    idempotency_key: str,  # UNIQUE
) -> EfhcTransferLog:
    """
    Read-through-вставка строки журнала EFHC с защитой от дублей idempotency_key.
    Денежных побочных эффектов нет — это обязанность банковского сервиса.

    Поведение:
      • Успех → возвращаем только что вставленную строку.
      • Конфликт UNIQUE(idempotency_key) → возвращаем существующую строку (как «уже выполнено»).

    Исключения:
      • Любые иные IntegrityError пробрасываются наверх — это действительно неожиданно.
    """
    payload = {
        "user_id": int(user_id),
        "amount_efhc": d8(amount_efhc),
        "direction": str(direction),
        "balance_type": str(balance_type),
        "reason": str(reason),
        "idempotency_key": str(idempotency_key),
        "created_at": datetime.now(timezone.utc),
    }

    stmt = (
        insert(EfhcTransferLog)
        .values(**payload)
        .returning(EfhcTransferLog)
    )
    try:
        res = await db.execute(stmt)
        row = res.scalar_one()
        return row
    except IntegrityError as e:
        # Если конфликт по idempotency_key — читаем уже существующую и отдаём «как есть»
        await db.rollback()
        existing = await get_transfer_by_idempotency(db, idempotency_key=idempotency_key)
        if existing is not None:
            return existing
        # Конфликт не по idempotency_key или запись не найдена — пробрасываем
        raise


async def get_transfer_by_idempotency(db: AsyncSession, *, idempotency_key: str) -> Optional[EfhcTransferLog]:
    """Вернуть запись журнала EFHC по idempotency_key или None."""
    res = await db.execute(
        select(EfhcTransferLog).where(EfhcTransferLog.idempotency_key == str(idempotency_key)).limit(1)
    )
    return res.scalar_one_or_none()


async def list_user_transfers_cursor(
    db: AsyncSession,
    *,
    user_id: int,
    limit: int = 50,
    next_cursor: Optional[str] = None,
    direction: Optional[str] = None,     # 'credit' | 'debit' | None
    balance_type: Optional[str] = None,  # 'main' | 'bonus' | None
    reason: Optional[str] = None,        # фильтр по короткому маркеру причины
) -> Tuple[List[EfhcTransferLog], Optional[str]]:
    """
    Вернуть курсорный список журнала EFHC по пользователю (id ASC). Без OFFSET.
    Возвращает (items, next_cursor). next_cursor=None, если данных больше нет.
    """
    limit = max(1, min(int(limit), 200))

    after_id: Optional[int] = None
    if next_cursor:
        after_id, _ = decode_cursor(next_cursor)

    stmt: Select = select(EfhcTransferLog).where(EfhcTransferLog.user_id == int(user_id))
    if direction:
        stmt = stmt.where(EfhcTransferLog.direction == str(direction))
    if balance_type:
        stmt = stmt.where(EfhcTransferLog.balance_type == str(balance_type))
    if reason:
        stmt = stmt.where(EfhcTransferLog.reason == str(reason))
    if after_id is not None:
        stmt = stmt.where(EfhcTransferLog.id > after_id)
    stmt = stmt.order_by(EfhcTransferLog.id.asc()).limit(limit)

    rows = (await db.execute(stmt)).scalars().all()
    nxt = encode_cursor(rows[-1].id, 0) if rows and len(rows) == limit else None
    return list(rows), nxt


async def aggregates_for_user(db: AsyncSession, *, user_id: int) -> Tuple[Decimal, Decimal, Decimal]:
    """
    Вернуть агрегаты по пользователю:
      total_credit, total_debit, net = (Σ credit, Σ debit, credit - debit).
    Это отчётные величины по журналу; не являются «истиной» балансов — истина в таблице users.
    """
    q_credit = select(func.coalesce(func.sum(EfhcTransferLog.amount_efhc), 0)).where(
        and_(EfhcTransferLog.user_id == int(user_id), EfhcTransferLog.direction == "credit")
    )
    q_debit = select(func.coalesce(func.sum(EfhcTransferLog.amount_efhc), 0)).where(
        and_(EfhcTransferLog.user_id == int(user_id), EfhcTransferLog.direction == "debit")
    )
    credit_val = (await db.execute(q_credit)).scalar_one() or 0
    debit_val = (await db.execute(q_debit)).scalar_one() or 0
    credit = d8(Decimal(credit_val))
    debit = d8(Decimal(debit_val))
    net = d8(credit - debit)
    return credit, debit, net


# =============================================================================
# TON INBOX LOGS — insert/get/list/update (watcher helper)
# =============================================================================

async def upsert_ton_inbox_readthrough(
    db: AsyncSession,
    *,
    tx_hash: str,
    from_address: str,
    to_address: str,
    amount: Decimal,
    memo: Optional[str],
    initial_status: str = "received",
) -> TonInboxLog:
    """
    Read-through upsert по входящей TON-транзакции.
    Поведение:
      • Если tx_hash новый — вставляем received.
      • Если tx_hash уже существует — возвращаем текущую запись (не создаём дубль).

    Примечание:
      • Это не меняет статус «назад» (не откатывает), только вставляет «новую» или читает «старую».
      • Вотчер дальше будет переводить статусы parsed/credited/... через update.
    """
    now = datetime.now(timezone.utc)
    payload = {
        "tx_hash": str(tx_hash),
        "from_address": str(from_address),
        "to_address": str(to_address),
        "amount": d8(amount),
        "memo": memo,
        "status": str(initial_status),
        "retries_count": 0,
        "next_retry_at": None,
        "last_error": None,
        "processed_at": None,
        "created_at": now,
        "updated_at": now,
    }
    stmt = (
        insert(TonInboxLog)
        .values(**payload)
        .on_conflict_do_nothing(index_elements=["tx_hash"])
        .returning(TonInboxLog)
    )
    res = await db.execute(stmt)
    row = res.scalar_one_or_none()
    if row:
        return row
    # уже существует — читаем и возвращаем
    return await get_ton_inbox_by_hash(db, tx_hash=tx_hash)


async def get_ton_inbox_by_hash(db: AsyncSession, *, tx_hash: str) -> Optional[TonInboxLog]:
    """Вернуть запись входящей TON-транзакции по tx_hash или None."""
    res = await db.execute(select(TonInboxLog).where(TonInboxLog.tx_hash == str(tx_hash)).limit(1))
    return res.scalar_one_or_none()


async def set_ton_status(
    db: AsyncSession,
    *,
    tx_hash: str,
    status: str,
    next_retry_at: Optional[datetime] = None,
    last_error: Optional[str] = None,
    processed_at: Optional[datetime] = None,
    retries_inc: bool = False,
) -> Optional[TonInboxLog]:
    """
    Обновить статус записи TON-логов.
    Используется вотчером для переходов received→parsed→credited или error_* с планом ретраев.
    """
    row = await get_ton_inbox_by_hash(db, tx_hash=tx_hash)
    if not row:
        return None
    row.status = str(status)
    row.updated_at = datetime.now(timezone.utc)
    if last_error is not None:
        row.last_error = last_error[:1024]  # ограничим длину на всякий случай
    row.next_retry_at = next_retry_at
    row.processed_at = processed_at if processed_at is not None else row.processed_at
    if retries_inc:
        row.retries_count = int(row.retries_count or 0) + 1
    await db.flush()
    return row


async def list_ton_pending_cursor(
    db: AsyncSession,
    *,
    limit: int = 200,
    next_cursor: Optional[str] = None,
    not_in_statuses: Optional[Sequence[str]] = None,
) -> Tuple[List[TonInboxLog], Optional[str]]:
    """
    Список записей TON, доступных к обработке вотчером:
      • status NOT IN (not_in_statuses) — конечные статусы исключаем,
      • (next_retry_at IS NULL OR next_retry_at <= now()) — по плану ретраев,
      • курсор по (id ASC), без OFFSET.
    """
    limit = max(1, min(int(limit), 500))
    after_id: Optional[int] = None
    if next_cursor:
        after_id, _ = decode_cursor(next_cursor)

    now = datetime.now(timezone.utc)
    stmt: Select = select(TonInboxLog)
    if not_in_statuses:
        stmt = stmt.where(TonInboxLog.status.not_in(list(map(str, not_in_statuses))))
    stmt = stmt.where(
        (TonInboxLog.next_retry_at.is_(None)) | (TonInboxLog.next_retry_at <= now)
    )
    if after_id is not None:
        stmt = stmt.where(TonInboxLog.id > after_id)

    stmt = stmt.order_by(TonInboxLog.id.asc()).limit(limit)
    rows = (await db.execute(stmt)).scalars().all()
    nxt = encode_cursor(rows[-1].id, 0) if rows and len(rows) == limit else None
    return list(rows), nxt


async def list_ton_range_cursor(
    db: AsyncSession,
    *,
    since_created_at: Optional[datetime] = None,
    until_created_at: Optional[datetime] = None,
    limit: int = 200,
    next_cursor: Optional[str] = None,
) -> Tuple[List[TonInboxLog], Optional[str]]:
    """
    Админская выборка за диапазон по created_at с курсором (id ASC).
    Удобно для ручной реконсиляции.
    """
    limit = max(1, min(int(limit), 500))
    after_id: Optional[int] = None
    if next_cursor:
        after_id, _ = decode_cursor(next_cursor)

    stmt: Select = select(TonInboxLog)
    if since_created_at is not None:
        stmt = stmt.where(TonInboxLog.created_at >= since_created_at)
    if until_created_at is not None:
        stmt = stmt.where(TonInboxLog.created_at < until_created_at)
    if after_id is not None:
        stmt = stmt.where(TonInboxLog.id > after_id)
    stmt = stmt.order_by(TonInboxLog.id.asc()).limit(limit)

    rows = (await db.execute(stmt)).scalars().all()
    nxt = encode_cursor(rows[-1].id, 0) if rows and len(rows) == limit else None
    return list(rows), nxt


# =============================================================================
# Метрики/агрегаты для отчётности
# =============================================================================

async def ton_retry_stats(db: AsyncSession) -> Tuple[int, int, int]:
    """
    Вернуть (total, with_errors, waiting_retry):
      total         — всего записей в ton_inbox_logs,
      with_errors   — статус LIKE 'error_%',
      waiting_retry — next_retry_at IS NOT NULL AND next_retry_at > now().
    """
    now = datetime.now(timezone.utc)
    total = (await db.execute(select(func.count(TonInboxLog.id)))).scalar_one() or 0
    with_errors = (await db.execute(
        select(func.count(TonInboxLog.id)).where(TonInboxLog.status.ilike("error_%"))
    )).scalar_one() or 0
    waiting_retry = (await db.execute(
        select(func.count(TonInboxLog.id)).where(
            and_(TonInboxLog.next_retry_at.is_not(None), TonInboxLog.next_retry_at > now)
        )
    )).scalar_one() or 0
    return int(total), int(with_errors), int(waiting_retry)


# =============================================================================
# Пояснения (для разработчиков/ревью):
# • insert_transfer_log_readthrough — атомарный паттерн «вставь/верни существующую» по idempotency_key.
#   Никаких денег тут не двигаем — только журнал. Балансы правит services/transactions_service.py.
# • upsert_ton_inbox_readthrough — аналогично по tx_hash: «вставь/верни» без дублей.
# • list_ton_pending_cursor — базовая выборка для вотчера: НЕ конечные статусы + срок ретрая наступил.
# • Все списки используют курсор по (id ASC), чтобы не блокировать индексы и быть устойчивыми при росте данных.
# • aggregates_for_user — отчётная сводка по журналу EFHC. Истина балансов — в users.*balance.
# =============================================================================
