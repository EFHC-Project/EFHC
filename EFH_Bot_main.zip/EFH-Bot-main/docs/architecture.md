# Архитектура проекта EFHC

---

### Генерация энергии
- Генерация фиксированная, только в секундах:
  - `GEN_PER_SEC_BASE_KWH = 0.00000692` кВт/сек
  - `GEN_PER_SEC_VIP_KWH  = 0.00000741` кВт/сек
- Флаг `VIP` обновляется внешним процессом в 00:00 по наличию NFT.
- Флаг `ACTIVE` включается при первой покупке панели (навсегда).
- Денежная точность — 8 знаков после запятой, округление вниз.
- Лимит панелей: 1000 минус архивные.

---

### Валюта и операции
- Обменник работает только `kWh → EFHC` (1:1). Обратный обмен запрещён.
- Все списания у пользователей всегда идут в банк `BANK_TELEGRAM_ID`.
- Покупка панелей:
  - бонусные EFHC списываются у пользователя → банк.
- Покупка билета лотереи:
  - цена по умолчанию 1 EFHC, списываются обычные EFHC.
- Вывод возможен только в EFHC.
- Пополнения: внешний кошелёк принимает только EFHC jetton.
- TON и USDT используются только для покупок в магазине.

---

### Магазин
- Пользователь может платить: TON, USDT, EFHC.
- VIP NFT выдаётся вручную админом по заявке.
- EFHC-пакеты покупаются за TON/USDT, пользователю начисляется EFHC с банка.
- Каждому товару соответствует `custom_memo`, обязателен для валидации транзакций.
- Заказы:
  - если покупка за EFHC → списываем у пользователя, зачисляем банку.
  - если за TON/USDT → начисляем EFHC пользователю, списываем у банка.

---

### Лог переводов EFHC
- Поля: `from_id`, `to_id`, `amount`, `reason`.
- Причины:
  - `shop_buy_efhc`        — покупка EFHC (банк → user)
  - `shop_panel_bonus`     — списание бонусных EFHC за панели (user → банк)
  - `shop_panel_efhc`      — списание обычных EFHC за панели (user → банк)
  - `exchange_kwh_to_efhc` — обмен kWh→EFHC
  - `withdraw_lock`        — блокировка EFHC при выводе (user → банк)
  - `withdraw_refund`      — возврат при отказе (банк → user)
  - `lottery_ticket_buy`   — покупка билета лотереи
  - `task_reward`          — награда за задание

---

### Реферальные бонусы
- `first_panel` — разовый бонус 0.1 EFHC за 1-ю панель у реферала.
- `threshold` — бонусы за достижение активных рефералов:
  - 10 → 1 EFHC
  - 100 → 10 EFHC
  - 1000 → 100 EFHC
  - 3000 → 300 EFHC
  - 10000 → 1000 EFHC

---

### Cron-задачи
- 00:00 UTC — проверка VIP NFT для всех пользователей.
- 00:30 UTC — начисление kWh по активным панелям.
- 01:00 UTC — архивирование панелей.
- 01:30 UTC — чистка логов и reconcile (проверка за последние 72 часа).

---

### API (основные эндпоинты)
- `POST /api/auth/webapp-init` — авторизация Telegram WebApp.
- `GET /api/user/profile` — профиль, балансы, VIP, кошелёк.
- `GET /api/panels` — список панелей.
- `POST /api/panels/buy` — покупка панелей.
- `POST /api/exchange/convert` — обмен kWh→EFHC.
- `GET /api/rating/global` — глобальный рейтинг.
- `GET /api/rating/referral` — рейтинг рефералов.
- `GET /api/referrals` — дерево рефералов.
- `GET /api/shop/config` — TON/USDT адреса, ссылка на NFT-маркет.
- `POST /api/shop/buy` — создание заказа.
- `POST /api/shop/check-payment` — проверка оплаты.
- `GET /api/admin/*` — банк EFHC, выводы, заказы, логи.

---

### Уровни пользователей
- `1` — Eco Initiate (0 kWh)
- `2` — Hope Bringer (100 kWh)
- `3` — Energy Seeker (300 kWh)
- `4` — Nature's Voice (600 kWh)
- `5` — Earth Ally (1000 kWh)
- `6` — Climate Warrior (2000 kWh)
- `7` — Green Sentinel (3500 kWh)
- `8` — Planet Defender (5000 kWh)
- `9` — Eco Champion (7500 kWh)
- `10` — Planet Saver (10000 kWh)
- `11` — Green Commander (15000 kWh)
- `12` — Guardian of Earth (20000 kWh)
# Architecture documentation
